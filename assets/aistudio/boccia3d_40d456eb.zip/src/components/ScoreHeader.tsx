import React from 'react';
import {
  Team,
  GamePhase,
  MatchType,
  OpponentMode,
  MATCH_CONFIGS,
  EndScoreRecord,
  getEndStarter,
} from '../types';

interface ScoreHeaderProps {
  currentTeam: Team;
  gamePhase: GamePhase;
  redScore: number;
  blueScore: number;
  redBallsLeft: number;
  blueBallsLeft: number;
  selectedBoxNum: number;
  jackStarterTeam: Team;
  matchType: MatchType;
  opponentMode: OpponentMode;
  playerTeam: Team;
  currentEnd?: number;
  totalEnds?: number;
  endScores?: EndScoreRecord[];
  isCpuTurn?: boolean;
  onChangeMatchType: (type: MatchType) => void;
  onChangeOpponentMode?: (mode: OpponentMode) => void;
  onChangePlayerTeam?: (team: Team) => void;
  onFinishMatch: () => void;
  onResetGame: () => void;
}

export const ScoreHeader: React.FC<ScoreHeaderProps> = ({
  currentTeam,
  gamePhase,
  redScore,
  blueScore,
  redBallsLeft,
  blueBallsLeft,
  selectedBoxNum,
  jackStarterTeam,
  matchType,
  opponentMode,
  playerTeam,
  currentEnd = 1,
  totalEnds = 6,
  endScores = [],
  isCpuTurn = false,
  onChangeMatchType,
  onChangeOpponentMode,
  onChangePlayerTeam,
  onFinishMatch,
  onResetGame,
}) => {
  const isRedTurn = currentTeam === 'RED';
  const matchConfig = MATCH_CONFIGS[matchType];
  const endStarterInfo = getEndStarter(matchType, currentEnd);
  const starterBox = endStarterInfo.box;
  const isVsCpu = opponentMode === 'VS_CPU';
  const cpuTeam: Team = playerTeam === 'RED' ? 'BLUE' : 'RED';

  const getPhaseText = () => {
    if (isCpuTurn) {
      return `🤖 PC (${currentTeam === 'RED' ? '赤' : '青'}チーム) が思考・投球中...`;
    }
    switch (gamePhase) {
      case 'JACK_THROW':
        return `⚪ ジャックボール投球 (${jackStarterTeam === 'RED' ? '赤' : '青'}${starterBox}先行)`;
      case 'INITIAL_RED':
        return isVsCpu && playerTeam === 'RED'
          ? '🔴 あなた (赤チーム) の第1投！'
          : '🔴 赤チーム 第1投';
      case 'INITIAL_BLUE':
        return isVsCpu && playerTeam === 'BLUE'
          ? '🔵 あなた (青チーム) の第1投！'
          : '🔵 青チーム 第1投';
      case 'IN_PLAY':
        if (isVsCpu) {
          return currentTeam === playerTeam
            ? `🎯 あなた (${playerTeam === 'RED' ? '赤' : '青'}) の番です！ (ジャックからより遠いため)`
            : `🤖 PC (${cpuTeam === 'RED' ? '赤' : '青'}) の番です (ジャックからより遠いため)`;
        }
        return isRedTurn
          ? '🔴 赤チームの番 (ジャックからより遠いため)'
          : '🔵 青チームの番 (ジャックからより遠いため)';
      case 'MEASURING':
        return '📏 審判員 計測中...';
      case 'END_RESULT':
        return '🏁 エンド終了・得点結果';
      default:
        return '🎮 ゲーム準備完了';
    }
  };

  const matchTypes: { type: MatchType; label: string; icon: string; badge: string }[] = [
    { type: 'TEAM', label: '団体戦 (3人制)', icon: '👥', badge: '①〜⑥ 各2投' },
    { type: 'PAIRS', label: 'ペア戦 (2人制)', icon: '🤝', badge: '②〜⑤ 各3投' },
    { type: 'INDIVIDUAL', label: '個人戦 (1人制)', icon: '👤', badge: '③・④ 各6投' },
  ];

  return (
    <header className="w-full max-w-[1024px] flex flex-col gap-1.5 px-2 py-1">
      {/* Top Bar: Match Format Switcher Tabs & Opponent Mode */}
      <div className="w-full flex flex-wrap items-center justify-between gap-2 px-3 py-1.5 bg-slate-900/90 rounded-2xl border border-white/10 shadow-lg">
        <div className="flex flex-wrap items-center gap-2">
          {/* Match Format Switcher */}
          <div className="flex items-center space-x-1.5">
            <span className="text-xs font-black text-amber-300 flex items-center space-x-1">
              <span>⚔️</span>
              <span className="hidden sm:inline">種目:</span>
            </span>
            <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-xl border border-white/10">
              {matchTypes.map((item) => {
                const isActive = matchType === item.type;
                return (
                  <button
                    key={item.type}
                    type="button"
                    onClick={() => onChangeMatchType(item.type)}
                    className={`px-2.5 sm:px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center space-x-1.5 ${
                      isActive
                        ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/30 scale-102'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800'
                    }`}
                    title={item.badge}
                  >
                    <span>{item.icon}</span>
                    <span className="leading-none">{item.label}</span>
                    <span
                      className={`text-[9px] px-1 py-0.2 rounded font-mono ${
                        isActive ? 'bg-amber-950/80 text-amber-200' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {item.badge}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Opponent Mode & Side Toggle */}
          <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-xl border border-sky-500/30">
            <button
              type="button"
              onClick={() => onChangeOpponentMode && onChangeOpponentMode(isVsCpu ? '2P' : 'VS_CPU')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center space-x-1 ${
                isVsCpu
                  ? 'bg-sky-500/25 text-sky-200 border border-sky-400/50 shadow-sm'
                  : 'bg-slate-800 text-slate-300 hover:text-white'
              }`}
              title="対戦形式（PC対戦 ⇄ 2人対戦）を切り替えます"
            >
              <span>{isVsCpu ? '🤖 PC対戦 (1人)' : '👥 2人対戦 (2P)'}</span>
            </button>

            {isVsCpu && onChangePlayerTeam && (
              <button
                type="button"
                onClick={() => onChangePlayerTeam(playerTeam === 'RED' ? 'BLUE' : 'RED')}
                className={`px-2 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer border flex items-center space-x-1 ${
                  playerTeam === 'RED'
                    ? 'bg-red-950 text-red-200 border-red-500/50 hover:bg-red-900/60'
                    : 'bg-blue-950 text-blue-200 border-blue-500/50 hover:bg-blue-900/60'
                }`}
                title="自分の担当チーム色（赤 ⇄ 青）を切り替えます"
              >
                <span>自分:</span>
                <span className="font-extrabold">{playerTeam === 'RED' ? '🔴 赤' : '🔵 青'}</span>
                <span className="text-[10px] opacity-70">⇄切替</span>
              </button>
            )}
          </div>
        </div>

        {/* Global Action Buttons */}
        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={onResetGame}
            className="text-[11px] font-bold px-3 py-1 rounded-lg bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-600/50 transition-all cursor-pointer shadow-sm flex items-center space-x-1"
            title="試合スコアをリセットし、第1エンドから開始します"
          >
            <span>🔄</span>
            <span>第1エンドからリセット</span>
          </button>
          <button
            type="button"
            onClick={onFinishMatch}
            className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 transition-all cursor-pointer shadow-sm"
          >
            判定 (結果)
          </button>
        </div>
      </div>

      {/* Main Score & Teams Deck */}
      <div className="w-full flex flex-col sm:flex-row justify-between items-center gap-2">
        {/* Red Team Card */}
        <div
          className={`glass-panel rounded-2xl p-2 sm:px-4 flex items-center space-x-3 border-2 transition-all duration-300 w-full sm:w-auto min-w-[210px] ${
            isRedTurn ? 'player-active-red border-red-500' : 'border-red-500/30 opacity-75'
          }`}
        >
          <div className="w-10 h-10 rounded-xl bg-red-500/20 border border-red-500 flex flex-col items-center justify-center font-black font-orbitron text-red-400">
            <span className="text-xs leading-none">RED</span>
            <span className="text-[9px] text-red-200">
              {isVsCpu ? (playerTeam === 'RED' ? 'YOU' : 'CPU') : '1P'}
            </span>
          </div>
          <div className="flex flex-col flex-1">
            <div className="flex items-center justify-between gap-1">
              <span className="text-[11px] font-black uppercase tracking-wider text-red-400 flex items-center space-x-1">
                <span>{isVsCpu ? (playerTeam === 'RED' ? 'あなた (赤)' : 'PC 🤖 (赤)') : 'PLAYER 1 (赤)'}</span>
              </span>
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-red-950/90 border border-red-500/40 text-red-300 font-mono font-bold">
                {isVsCpu && playerTeam === 'BLUE' ? 'AUTO' : 'a / w'}
              </span>
            </div>

            <div className="flex items-baseline justify-between mt-0.5">
              <div className="flex items-baseline space-x-1">
                <span className="text-2xl font-black font-orbitron text-white tracking-wider">
                  {redScore}
                </span>
                <span className="text-[10px] text-slate-400 font-bold">pts</span>
              </div>

              {/* Remaining balls dots */}
              <div className="flex space-x-1 items-center">
                {[...Array(6)].map((_, i) => (
                  <span
                    key={i}
                    className={`w-2.5 h-2.5 rounded-full border ${
                      i < redBallsLeft
                        ? 'bg-red-500 border-red-300 shadow-sm shadow-red-500/50'
                        : 'bg-slate-800 border-slate-700'
                    }`}
                    title={`赤チーム残球: ${redBallsLeft}球`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Center Match Status Badge */}
        <div className="glass-panel rounded-2xl px-4 py-1.5 flex flex-col items-center justify-center border border-white/10 shadow-xl flex-1 max-w-sm">
          {/* End Badge & Live Box Indicator */}
          <div className="flex items-center space-x-1.5 mb-1 flex-wrap justify-center gap-y-1">
            <span className="text-[11px] font-black px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-400/50">
              第 {currentEnd} / {totalEnds} エンド
            </span>
            <span
              className={`text-xs font-black px-2 py-0.5 rounded-md shadow-md transition-all ${
                isRedTurn
                  ? 'bg-red-500 text-white shadow-red-500/40'
                  : 'bg-blue-600 text-white shadow-blue-500/40'
              }`}
            >
              {isCpuTurn
                ? `🤖 PC (${currentTeam === 'RED' ? '赤' : '青'}) 投球`
                : isVsCpu
                ? `🎯 あなたの番 (${currentTeam === 'RED' ? '赤' : '青'})`
                : isRedTurn
                ? '1P 赤組の番'
                : '2P 青組の番'}
            </span>
            <span className="text-[10.5px] font-mono text-slate-300 bg-slate-800 px-1.5 py-0.5 rounded border border-white/10">
              枠: <strong className="text-amber-300 font-black">{`【${selectedBoxNum}】`}</strong>
            </span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 border border-amber-400/30 text-amber-300 font-bold">
              ジャック先攻: {endStarterInfo.team === 'RED' ? `🔴 赤${starterBox}` : `🔵 青${starterBox}`}
            </span>
          </div>

          <div className="text-[11px] text-amber-300 font-bold flex items-center space-x-1 text-center">
            <span>{getPhaseText()}</span>
          </div>

          {/* Mini End Indicators */}
          {totalEnds > 0 && (
            <div className="flex items-center space-x-1 mt-1">
              {Array.from({ length: totalEnds }).map((_, idx) => {
                const endNum = idx + 1;
                const record = endScores.find((r) => r.end === endNum);
                const isCurrent = endNum === currentEnd;
                let bg = 'bg-slate-800 border-slate-700 text-slate-500';
                if (record) {
                  if (record.winner === 'RED') bg = 'bg-red-600/50 border-red-400 text-red-200';
                  else if (record.winner === 'BLUE') bg = 'bg-blue-600/50 border-blue-400 text-blue-200';
                  else bg = 'bg-amber-600/40 border-amber-400 text-amber-200';
                } else if (isCurrent) {
                  bg = 'bg-amber-500 border-amber-300 text-slate-950 font-black animate-pulse';
                }
                return (
                  <span
                    key={idx}
                    className={`text-[9px] px-1.5 py-0.2 rounded border font-mono ${bg}`}
                    title={
                      record
                        ? `第${endNum}E: 赤${record.redPoints} - 青${record.bluePoints}`
                        : `第${endNum}E`
                    }
                  >
                    {endNum}E
                  </span>
                );
              })}
            </div>
          )}
        </div>

        {/* Blue Team Card */}
        <div
          className={`glass-panel rounded-2xl p-2 sm:px-4 flex items-center space-x-3 border-2 transition-all duration-300 w-full sm:w-auto min-w-[210px] ${
            !isRedTurn ? 'player-active-blue border-blue-500' : 'border-blue-500/30 opacity-75'
          }`}
        >
          <div className="flex flex-col flex-1 items-end">
            <div className="flex items-center justify-between w-full gap-1">
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-blue-950/90 border border-blue-500/40 text-blue-300 font-mono font-bold">
                {isVsCpu && playerTeam === 'RED' ? 'AUTO' : '↓ / →'}
              </span>
              <span className="text-[11px] font-black uppercase tracking-wider text-blue-400 flex items-center space-x-1">
                <span>{isVsCpu ? (playerTeam === 'BLUE' ? 'あなた (青)' : 'PC 🤖 (青)') : 'PLAYER 2 (青)'}</span>
              </span>
            </div>

            <div className="flex items-baseline justify-between w-full mt-0.5">
              <div className="flex space-x-1 items-center">
                {[...Array(6)].map((_, i) => (
                  <span
                    key={i}
                    className={`w-2.5 h-2.5 rounded-full border ${
                      i < blueBallsLeft
                        ? 'bg-blue-500 border-blue-300 shadow-sm shadow-blue-500/50'
                        : 'bg-slate-800 border-slate-700'
                    }`}
                    title={`青チーム残球: ${blueBallsLeft}球`}
                  />
                ))}
              </div>

              <div className="flex items-baseline space-x-1">
                <span className="text-2xl font-black font-orbitron text-white tracking-wider">
                  {blueScore}
                </span>
                <span className="text-[10px] text-slate-400 font-bold">pts</span>
              </div>
            </div>
          </div>

          <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-500 flex flex-col items-center justify-center font-black font-orbitron text-blue-400">
            <span className="text-xs leading-none">BLUE</span>
            <span className="text-[9px] text-blue-200">
              {isVsCpu ? (playerTeam === 'BLUE' ? 'YOU' : 'CPU') : '2P'}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};
