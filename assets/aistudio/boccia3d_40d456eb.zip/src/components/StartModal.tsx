import React from 'react';
import { Team, MatchType, OpponentMode, MATCH_CONFIGS } from '../types';

interface StartModalProps {
  onStart: () => void;
  jackStarterTeam?: Team;
  matchType: MatchType;
  onChangeMatchType: (type: MatchType) => void;
  opponentMode: OpponentMode;
  onChangeOpponentMode: (mode: OpponentMode) => void;
  playerTeam: Team;
  onChangePlayerTeam: (team: Team) => void;
}

export const StartModal: React.FC<StartModalProps> = ({
  onStart,
  jackStarterTeam = 'RED',
  matchType,
  onChangeMatchType,
  opponentMode,
  onChangeOpponentMode,
  playerTeam,
  onChangePlayerTeam,
}) => {
  const currentConfig = MATCH_CONFIGS[matchType];
  const starterBoxNum = currentConfig.jackStarterBoxes[jackStarterTeam];
  const starterBoxLabel = `ボックス${['①', '②', '③', '④', '⑤', '⑥'][starterBoxNum - 1]}`;
  const isVsCpu = opponentMode === 'VS_CPU';
  const cpuTeam: Team = playerTeam === 'RED' ? 'BLUE' : 'RED';

  const modes: { type: MatchType; label: string; icon: string; detail: string; ends: string }[] = [
    {
      type: 'TEAM',
      label: '団体戦 (3人制)',
      icon: '👥',
      detail: '全6エンド・ボックス①〜⑥使用・各枠2投',
      ends: '6エンド (①→②→③→④→⑤→⑥)',
    },
    {
      type: 'PAIRS',
      label: 'ペア戦 (2人制)',
      icon: '🤝',
      detail: '全4エンド・ボックス②〜⑤使用・各枠3投',
      ends: '4エンド (②→③→④→⑤)',
    },
    {
      type: 'INDIVIDUAL',
      label: '個人戦 (1人制)',
      icon: '👤',
      detail: '全4エンド・ボックス③・④使用・各枠6投',
      ends: '4エンド (③⇄④)',
    },
  ];

  return (
    <div className="absolute inset-0 bg-slate-950/94 backdrop-blur-md flex flex-col justify-center items-center text-center p-3 sm:p-5 z-50 overflow-y-auto max-h-full">
      <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mb-2 shadow-lg shadow-amber-500/10 animate-bounce">
        <span className="text-3xl">⚪</span>
      </div>

      <h1 className="text-2xl sm:text-3xl font-black font-orbitron text-white mb-1.5 tracking-wide">
        Boccia Master <span className="text-amber-400">ボッチャ対戦</span>
      </h1>
      <p className="text-xs sm:text-sm text-slate-300 max-w-lg mb-3 leading-relaxed">
        パラリンピック正式種目「ボッチャ」のリアル物理シミュレーションゲーム。<br />
        白いジャックボールに自分の色のボールをどれだけ近づけられるかを競う頭脳戦です！
      </p>

      {/* Mode Switcher Tabs */}
      <div className="w-full max-w-xl bg-slate-900/90 p-1.5 rounded-2xl border border-slate-700/80 mb-2.5 shadow-xl">
        <div className="text-[11px] font-bold text-amber-300 mb-1.5 flex items-center justify-center space-x-1">
          <span>🏆</span>
          <span>競技種目を選択 (プレイ中も画面上で切替可能)</span>
        </div>
        <div className="grid grid-cols-3 gap-1.5">
          {modes.map((m) => {
            const isSelected = matchType === m.type;
            return (
              <button
                key={m.type}
                type="button"
                onClick={() => onChangeMatchType(m.type)}
                className={`flex flex-col items-center justify-center py-2 px-2 rounded-xl transition-all cursor-pointer border ${
                  isSelected
                    ? 'bg-amber-500/20 border-amber-400 text-white font-bold shadow-md shadow-amber-500/10 ring-1 ring-amber-400/50'
                    : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                <span className="text-base sm:text-lg mb-0.5">{m.icon}</span>
                <span className="text-xs font-bold leading-tight">{m.label}</span>
                <span className="text-[9.5px] text-amber-300 font-semibold mt-0.5">
                  {m.type === 'TEAM' && '6エンド (各枠2投)'}
                  {m.type === 'PAIRS' && '4エンド (各枠3投)'}
                  {m.type === 'INDIVIDUAL' && '4エンド (各枠6投)'}
                </span>
                <span className="text-[8.5px] text-slate-400 font-mono mt-0.5 hidden sm:block">
                  {m.ends}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Opponent Mode & Player Team Selector */}
      <div className="w-full max-w-xl bg-slate-900/95 p-2 rounded-2xl border border-sky-500/40 mb-3 shadow-xl">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2">
          {/* Opponent Mode Selection */}
          <div className="flex-1 w-full">
            <div className="text-[10px] font-bold text-sky-300 mb-1 flex items-center space-x-1">
              <span>🎮</span>
              <span>対戦相手:</span>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => onChangeOpponentMode('VS_CPU')}
                className={`py-1.5 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer border flex items-center justify-center space-x-1.5 ${
                  isVsCpu
                    ? 'bg-sky-500/25 border-sky-400 text-white shadow-md shadow-sky-500/20 ring-1 ring-sky-400/50'
                    : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:text-slate-200'
                }`}
              >
                <span className="text-sm">🤖</span>
                <span>PCと対戦 (1人)</span>
              </button>
              <button
                type="button"
                onClick={() => onChangeOpponentMode('2P')}
                className={`py-1.5 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer border flex items-center justify-center space-x-1.5 ${
                  !isVsCpu
                    ? 'bg-amber-500/25 border-amber-400 text-white shadow-md shadow-amber-500/20 ring-1 ring-amber-400/50'
                    : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:text-slate-200'
                }`}
              >
                <span className="text-sm">👥</span>
                <span>2人対戦 (2P)</span>
              </button>
            </div>
          </div>

          {/* Color Selection (when VS_CPU is chosen) */}
          {isVsCpu && (
            <div className="flex-1 w-full sm:border-l sm:border-slate-800 sm:pl-3">
              <div className="text-[10px] font-bold text-amber-300 mb-1 flex items-center space-x-1">
                <span>🎨</span>
                <span>あなたのチーム色 (赤または青):</span>
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  onClick={() => onChangePlayerTeam('RED')}
                  className={`py-1.5 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer border flex items-center justify-center space-x-1 ${
                    playerTeam === 'RED'
                      ? 'bg-red-600/30 border-red-400 text-red-200 shadow-md shadow-red-500/20 ring-1 ring-red-400/50'
                      : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:text-red-300'
                  }`}
                >
                  <span>🔴</span>
                  <span>自分: 赤 (1P)</span>
                </button>
                <button
                  type="button"
                  onClick={() => onChangePlayerTeam('BLUE')}
                  className={`py-1.5 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer border flex items-center justify-center space-x-1 ${
                    playerTeam === 'BLUE'
                      ? 'bg-blue-600/30 border-blue-400 text-blue-200 shadow-md shadow-blue-500/20 ring-1 ring-blue-400/50'
                      : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:text-blue-300'
                  }`}
                >
                  <span>🔵</span>
                  <span>自分: 青 (2P)</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Rules & Throwing box breakdown based on selected mode */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-w-xl w-full mb-3 text-left">
        {/* Red Team Info */}
        <div
          className={`glass-panel rounded-xl p-3 border ${
            isVsCpu && playerTeam === 'RED'
              ? 'border-red-400 bg-red-950/30 ring-1 ring-red-400/40'
              : 'border-red-500/40 bg-red-950/20'
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <div className="flex items-center space-x-2">
              <span className="w-6 h-6 rounded bg-red-600 text-white text-xs font-black flex items-center justify-center font-orbitron">
                1P
              </span>
              <strong className="text-xs text-red-300">
                {isVsCpu
                  ? playerTeam === 'RED'
                    ? '赤チーム (あなた)'
                    : '赤チーム (PC 🤖)'
                  : '赤チーム (Player 1)'}
              </strong>
            </div>
            {isVsCpu && (
              <span
                className={`text-[9.5px] px-1.5 py-0.5 rounded font-bold ${
                  playerTeam === 'RED'
                    ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-500/40'
                    : 'bg-purple-500/30 text-purple-300 border border-purple-500/40'
                }`}
              >
                {playerTeam === 'RED' ? '★ あなた' : '🤖 CPU'}
              </span>
            )}
          </div>
          <ul className="text-[11px] text-slate-300 space-y-1">
            <li>
              ・操作：
              {isVsCpu && playerTeam === 'BLUE' ? (
                <span className="text-purple-300 font-bold">PCが自動で思考・投球</span>
              ) : (
                <>
                  キー <code className="bg-red-950 px-1 py-0.5 rounded text-red-300 font-bold font-mono">a / w</code> または <code className="bg-red-950 px-1 py-0.5 rounded text-red-300 font-bold font-mono">↓ / →</code>
                </>
              )}
            </li>
            <li>
              ・使用ボックス：
              <code className="bg-red-950 px-1.5 py-0.5 rounded text-red-300 font-bold">
                {currentConfig.redBoxes.map((b) => `ボックス${['①', '②', '③', '④', '⑤', '⑥'][b - 1]}`).join(' ')}
              </code>
            </li>
            <li>
              ・ボックス制限：<strong className="text-amber-300">各枠 {currentConfig.throwsPerBox}球まで</strong> (計6球)
            </li>
            <li>
              ・先攻時投球：<span className="text-amber-300 font-bold">ボックス{['①', '②', '③', '④', '⑤', '⑥'][currentConfig.jackStarterBoxes.RED - 1]}</span> からジャック投球
            </li>
          </ul>
        </div>

        {/* Blue Team Info */}
        <div
          className={`glass-panel rounded-xl p-3 border ${
            isVsCpu && playerTeam === 'BLUE'
              ? 'border-blue-400 bg-blue-950/30 ring-1 ring-blue-400/40'
              : 'border-blue-500/40 bg-blue-950/20'
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <div className="flex items-center space-x-2">
              <span className="w-6 h-6 rounded bg-blue-600 text-white text-xs font-black flex items-center justify-center font-orbitron">
                2P
              </span>
              <strong className="text-xs text-blue-300">
                {isVsCpu
                  ? playerTeam === 'BLUE'
                    ? '青チーム (あなた)'
                    : '青チーム (PC 🤖)'
                  : '青チーム (Player 2)'}
              </strong>
            </div>
            {isVsCpu && (
              <span
                className={`text-[9.5px] px-1.5 py-0.5 rounded font-bold ${
                  playerTeam === 'BLUE'
                    ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-500/40'
                    : 'bg-purple-500/30 text-purple-300 border border-purple-500/40'
                }`}
              >
                {playerTeam === 'BLUE' ? '★ あなた' : '🤖 CPU'}
              </span>
            )}
          </div>
          <ul className="text-[11px] text-slate-300 space-y-1">
            <li>
              ・操作：
              {isVsCpu && playerTeam === 'RED' ? (
                <span className="text-purple-300 font-bold">PCが自動で思考・投球</span>
              ) : (
                <>
                  キー <code className="bg-blue-950 px-1 py-0.5 rounded text-blue-300 font-bold font-mono">↓ / →</code> または <code className="bg-blue-950 px-1 py-0.5 rounded text-blue-300 font-bold font-mono">a / w</code>
                </>
              )}
            </li>
            <li>
              ・使用ボックス：
              <code className="bg-blue-950 px-1.5 py-0.5 rounded text-blue-300 font-bold">
                {currentConfig.blueBoxes.map((b) => `ボックス${['①', '②', '③', '④', '⑤', '⑥'][b - 1]}`).join(' ')}
              </code>
            </li>
            <li>
              ・ボックス制限：<strong className="text-amber-300">各枠 {currentConfig.throwsPerBox}球まで</strong> (計6球)
            </li>
            <li>
              ・先攻時投球：<span className="text-amber-300 font-bold">ボックス{['①', '②', '③', '④', '⑤', '⑥'][currentConfig.jackStarterBoxes.BLUE - 1]}</span> からジャック投球
            </li>
          </ul>
        </div>
      </div>

      {/* Feature Notices: Ends count & Shifting Jack Starter Box */}
      <div className="glass-panel rounded-xl p-2.5 max-w-xl w-full mb-3 border border-emerald-500/30 text-left bg-emerald-950/20 text-[11px] text-slate-200 space-y-1">
        <div className="font-bold text-emerald-300 flex items-center space-x-1.5">
          <span>🔄</span>
          <span>【公式ボッチャ規則】団体戦6エンド / ペア・個人戦4エンド &amp; 枠シフト</span>
        </div>
        <p className="text-slate-300">
          ・<strong className="text-amber-300">ジャックボール投球ボックスのシフト</strong>：エンドごとに先攻チームと投球枠が順にシフトします（団体戦: ①→②→③→④→⑤→⑥、ペア戦: ②→③→④→⑤、個人戦: ③⇄④）。
        </p>
        <p className="text-slate-300">
          ・ジャックボールを投げたプレイヤーは、そのエンドの<strong className="text-cyan-300">チーム第1球を必ず同じボックスから投球</strong>します。
        </p>
      </div>

      {/* Control Instructions */}
      <div className="glass-panel rounded-xl p-2.5 max-w-xl w-full mb-3.5 border border-amber-500/30 text-left">
        <div className="text-xs font-extrabold text-amber-300 mb-1 flex items-center space-x-1.5">
          <span>🎯</span>
          <span>操作方法 (キーボード または 画面下部のボタン)</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] text-slate-200">
          <div className="bg-slate-900/80 p-1.5 rounded-lg border border-white/5">
            <div className="text-cyan-300 font-bold mb-0.5">1. 枠決定 &amp; ボール保持</div>
            <code className="bg-slate-800 px-1 rounded text-amber-300 font-mono text-[10px]">枠選択後に同時押し</code>
            <p className="text-[10px] text-slate-400 mt-0.5">
              ボックス決定後にキー同時押しで保持。ジャック方向へ自動照準！
            </p>
          </div>
          <div className="bg-slate-900/80 p-1.5 rounded-lg border border-white/5">
            <div className="text-cyan-300 font-bold mb-0.5">2. 投球方向の微調整</div>
            <code className="bg-slate-800 px-1 rounded text-cyan-300 font-mono text-[10px]">片方キー / ◀▶ボタン</code>
            <p className="text-[10px] text-slate-400 mt-0.5">
              保持後は片方キーで微調整。短押し同時押しでボール解放（解除）
            </p>
          </div>
          <div className="bg-slate-900/80 p-1.5 rounded-lg border border-white/5">
            <div className="text-cyan-300 font-bold mb-0.5">3. スローイング</div>
            <code className="bg-slate-800 px-1 rounded text-emerald-400 font-mono text-[10px]">長押し保持 / 投球ボタン</code>
            <p className="text-[10px] text-slate-400 mt-0.5">
              長押しでパワー充電、キーを離してスロー投球！
            </p>
          </div>
        </div>
      </div>

      {/* Start Button */}
      <button
        type="button"
        onClick={onStart}
        className="px-8 py-3 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-400 text-slate-950 font-black text-sm tracking-wider shadow-lg shadow-emerald-500/30 hover:brightness-110 active:scale-95 transition-all cursor-pointer flex items-center space-x-2 border-2 border-transparent"
      >
        <span>{isVsCpu ? '🤖' : '⚪'}</span>
        <span>
          {currentConfig.shortName}で対戦スタート！
          {isVsCpu ? ` (vs PC / 自分: ${playerTeam === 'RED' ? '赤' : '青'})` : ' (2人対戦)'}
        </span>
      </button>
    </div>
  );
};
