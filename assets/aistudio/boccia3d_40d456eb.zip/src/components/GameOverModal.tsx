import React from 'react';
import { MatchScore, OpponentMode, Team, ThrowingBoxNumber } from '../types';
import { pixelDistToMeters } from '../physics';

interface GameOverModalProps {
  score: MatchScore;
  onNextEnd: () => void;
  onResetMatch: () => void;
  nextStarterInfo?: { team: Team; box: ThrowingBoxNumber };
  opponentMode?: OpponentMode;
  playerTeam?: Team;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  onNextEnd,
  onResetMatch,
  nextStarterInfo,
  opponentMode = 'VS_CPU',
  playerTeam = 'RED',
}) => {
  const isMatchOver = score.isMatchOver;
  const isVsCpu = opponentMode === 'VS_CPU';

  // For final match result, determine overall winner by cumulative total score
  const overallWinningTeam =
    score.totalRedScore > score.totalBlueScore
      ? 'RED'
      : score.totalBlueScore > score.totalRedScore
      ? 'BLUE'
      : 'DRAW';

  const endWinningTeam = score.winningTeam;
  const targetWinner = isMatchOver ? overallWinningTeam : endWinningTeam;

  const isRedWinner = targetWinner === 'RED';
  const isBlueWinner = targetWinner === 'BLUE';
  const isDraw = targetWinner === 'DRAW';

  const playerWon = isVsCpu && targetWinner === playerTeam;
  const pcWon = isVsCpu && !isDraw && targetWinner !== playerTeam;

  let winnerTitle = '';
  if (isMatchOver) {
    if (isVsCpu) {
      if (playerWon) {
        winnerTitle = `🏆 総合優勝！ あなたの勝利！ (${playerTeam === 'RED' ? '赤組' : '青組'})`;
      } else if (pcWon) {
        winnerTitle = `🤖 総合優勝！ PC (${playerTeam === 'RED' ? '青組' : '赤組'}) の勝利！`;
      } else {
        winnerTitle = '🤝 総合結果: 引き分け (DRAW)';
      }
    } else {
      winnerTitle = isRedWinner
        ? '🏆 総合優勝！ 🔴 赤チームの勝利！'
        : isBlueWinner
        ? '🏆 総合優勝！ 🔵 青チームの勝利！'
        : '🤝 総合結果: 引き分け (DRAW)';
    }
  } else {
    if (isVsCpu) {
      if (playerWon) {
        winnerTitle = `🎉 あなたの第${score.currentEnd}エンド勝利！ (+${playerTeam === 'RED' ? score.redPoints : score.bluePoints}点)`;
      } else if (pcWon) {
        winnerTitle = `🤖 PCの第${score.currentEnd}エンド勝利 (+${playerTeam === 'RED' ? score.bluePoints : score.redPoints}点)`;
      } else {
        winnerTitle = `第${score.currentEnd}エンド: 引き分け (0点)`;
      }
    } else {
      winnerTitle = isRedWinner
        ? `🔴 赤チーム 第${score.currentEnd}エンド勝利！ (+${score.redPoints}点)`
        : isBlueWinner
        ? `🔵 青チーム 第${score.currentEnd}エンド勝利！ (+${score.bluePoints}点)`
        : `第${score.currentEnd}エンド: 引き分け (0点)`;
    }
  }

  const radiusMeters =
    score.scoringRadius != null ? pixelDistToMeters(score.scoringRadius) : null;

  return (
    <div className="w-full max-w-[1024px] my-2 z-20 pointer-events-auto animate-fade-in">
      <div className="glass-panel rounded-2xl p-3 sm:p-4 border-2 border-amber-500/70 shadow-2xl bg-slate-950/95 flex flex-col gap-3">
        {/* Top Header: End Indicator & Winner Badge */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 border-b border-slate-800 pb-2">
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/50 text-xs font-black font-mono">
              {isMatchOver
                ? `🏁 全${score.totalEnds}エンド終了`
                : `第 ${score.currentEnd} / ${score.totalEnds} エンド終了`}
            </span>
            <span
              className={`text-sm sm:text-base font-black font-orbitron tracking-wide ${
                isRedWinner ? 'text-red-400' : isBlueWinner ? 'text-blue-400' : 'text-amber-400'
              }`}
            >
              {winnerTitle}
            </span>
          </div>

          <div className="text-xs text-slate-300 font-semibold">
            {isMatchOver ? (
              <span className="text-amber-300 font-black">
                最終スコア: 🔴 {score.totalRedScore} - {score.totalBlueScore} 🔵
              </span>
            ) : (
              <span>
                このエンド得点: 🔴 +{score.redPoints}点 / 🔵 +{score.bluePoints}点 (得点球:{' '}
                {score.scoringBallsCount}個)
              </span>
            )}
          </div>
        </div>

        {/* Middle Section: Scores Deck & End History Table */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-3">
          {/* Left: Red Team Score */}
          <div
            className={`flex items-center space-x-3 p-2.5 rounded-xl border transition-all w-full md:w-auto min-w-[210px] ${
              score.totalRedScore >= score.totalBlueScore
                ? 'bg-red-950/60 border-red-500/70 shadow-lg shadow-red-500/20'
                : 'bg-slate-900/60 border-slate-800 opacity-80'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-red-600/30 border border-red-500 flex flex-col items-center justify-center font-black font-orbitron text-red-400">
              <span className="text-xs leading-none">RED</span>
              <span className="text-[9px] text-red-200">
                {isVsCpu ? (playerTeam === 'RED' ? 'YOU' : 'CPU') : '1P'}
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-[11px] font-black text-red-400">
                {isVsCpu ? (playerTeam === 'RED' ? 'あなた (赤)' : 'PC 🤖 (赤)') : '赤チーム (a / w)'}
              </span>
              <div className="flex items-baseline space-x-1.5">
                <span className="text-2xl font-black font-orbitron text-white">
                  {score.totalRedScore}
                </span>
                <span className="text-[10px] text-slate-400">pts</span>
                {!isMatchOver && (
                  <span className="text-xs font-black font-mono text-emerald-400">
                    (+{score.redPoints}点)
                  </span>
                )}
              </div>
              <span className="text-[9.5px] text-slate-400">
                このエンド最近球:{' '}
                {score.closestRedDist !== null ? `${score.closestRedDist}m` : '記録なし'}
              </span>
            </div>
          </div>

          {/* Center: End by End Scoreboard */}
          <div className="flex-1 w-full bg-slate-900/90 rounded-xl p-2 border border-slate-800">
            <div className="text-[10px] font-bold text-amber-300 mb-1 text-center flex items-center justify-center space-x-1">
              <span>📊</span>
              <span>エンド別スコア & ジャック先攻ボックス推移</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-center text-xs">
                <thead>
                  <tr className="text-slate-400 border-b border-slate-800 text-[10px]">
                    <th className="py-1 px-1.5 text-left">チーム</th>
                    {Array.from({ length: score.totalEnds }).map((_, idx) => (
                      <th
                        key={idx}
                        className={`py-1 px-1 font-mono ${
                          idx + 1 === score.currentEnd ? 'text-amber-300 font-bold' : ''
                        }`}
                      >
                        {idx + 1}E
                      </th>
                    ))}
                    <th className="py-1 px-1.5 text-right font-bold text-white">合計</th>
                  </tr>
                </thead>
                <tbody>
                  {/* Red Row */}
                  <tr className="border-b border-slate-800/60 font-mono">
                    <td className="py-1 px-1.5 text-left font-bold text-red-400 text-[11px]">
                      🔴 赤組
                    </td>
                    {Array.from({ length: score.totalEnds }).map((_, idx) => {
                      const endNum = idx + 1;
                      const record = score.endScores?.find((r) => r.end === endNum);
                      const isCurrent = endNum === score.currentEnd;
                      return (
                        <td
                          key={idx}
                          className={`py-1 px-1 ${
                            isCurrent
                              ? 'bg-red-500/20 font-black text-white rounded'
                              : record
                              ? 'text-slate-200'
                              : 'text-slate-600'
                          }`}
                        >
                          {record ? record.redPoints : '-'}
                        </td>
                      );
                    })}
                    <td className="py-1 px-1.5 text-right font-black font-orbitron text-red-400 text-sm">
                      {score.totalRedScore}
                    </td>
                  </tr>

                  {/* Blue Row */}
                  <tr className="font-mono">
                    <td className="py-1 px-1.5 text-left font-bold text-blue-400 text-[11px]">
                      🔵 青組
                    </td>
                    {Array.from({ length: score.totalEnds }).map((_, idx) => {
                      const endNum = idx + 1;
                      const record = score.endScores?.find((r) => r.end === endNum);
                      const isCurrent = endNum === score.currentEnd;
                      return (
                        <td
                          key={idx}
                          className={`py-1 px-1 ${
                            isCurrent
                              ? 'bg-blue-500/20 font-black text-white rounded'
                              : record
                              ? 'text-slate-200'
                              : 'text-slate-600'
                          }`}
                        >
                          {record ? record.bluePoints : '-'}
                        </td>
                      );
                    })}
                    <td className="py-1 px-1.5 text-right font-black font-orbitron text-blue-400 text-sm">
                      {score.totalBlueScore}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Note about scoring zone */}
            <p className="text-[10px] text-slate-400 text-center mt-1.5">
              コート上の金色の<strong className="text-amber-300">「得点圏内サークル」</strong>(相手最近球: {radiusMeters !== null ? `${radiusMeters}m` : '計測'}) 内の球が得点球 (★印) です。
            </p>
          </div>

          {/* Right: Blue Team Score */}
          <div
            className={`flex items-center space-x-3 p-2.5 rounded-xl border transition-all w-full md:w-auto min-w-[210px] ${
              score.totalBlueScore >= score.totalRedScore
                ? 'bg-blue-950/60 border-blue-500/70 shadow-lg shadow-blue-500/20'
                : 'bg-slate-900/60 border-slate-800 opacity-80'
            }`}
          >
            <div className="flex flex-col items-end flex-1">
              <span className="text-[11px] font-black text-blue-400">
                {isVsCpu ? (playerTeam === 'BLUE' ? 'あなた (青)' : 'PC 🤖 (青)') : '青チーム (↓ / →)'}
              </span>
              <div className="flex items-baseline space-x-1.5">
                {!isMatchOver && (
                  <span className="text-xs font-black font-mono text-emerald-400">
                    (+{score.bluePoints}点)
                  </span>
                )}
                <span className="text-2xl font-black font-orbitron text-white">
                  {score.totalBlueScore}
                </span>
                <span className="text-[10px] text-slate-400">pts</span>
              </div>
              <span className="text-[9.5px] text-slate-400">
                このエンド最近球:{' '}
                {score.closestBlueDist !== null ? `${score.closestBlueDist}m` : '記録なし'}
              </span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-blue-600/30 border border-blue-500 flex flex-col items-center justify-center font-black font-orbitron text-blue-400">
              <span className="text-xs leading-none">BLUE</span>
              <span className="text-[9px] text-blue-200">
                {isVsCpu ? (playerTeam === 'BLUE' ? 'YOU' : 'CPU') : '2P'}
              </span>
            </div>
          </div>
        </div>

        {/* Bottom Actions: Next End Button or New Match Button */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-1 border-t border-slate-800">
          {!isMatchOver ? (
            <>
              <button
                type="button"
                onClick={onNextEnd}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-black text-xs sm:text-sm tracking-wider shadow-lg shadow-emerald-500/30 hover:brightness-110 active:scale-95 cursor-pointer flex items-center space-x-2 border-2 border-emerald-400"
              >
                <span>▶️</span>
                <span>
                  第 {score.currentEnd + 1} エンドへ進む
                  {nextStarterInfo && (
                    <span className="ml-1 text-[11px] font-normal opacity-90">
                      (先攻: {nextStarterInfo.team === 'RED' ? '赤' : '青'}・ボックス
                      {nextStarterInfo.box}からジャック投球)
                    </span>
                  )}
                </span>
              </button>

              <button
                type="button"
                onClick={onResetMatch}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs hover:bg-slate-700 hover:text-white transition-all cursor-pointer flex items-center space-x-1"
                title="試合を第1エンドからリセットします"
              >
                <span>🔄</span>
                <span>試合をリセット</span>
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={onResetMatch}
              className="px-8 py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 font-black text-sm tracking-wider shadow-xl shadow-amber-500/30 hover:brightness-110 active:scale-95 cursor-pointer flex items-center space-x-2 border-2 border-amber-300"
            >
              <span>🔄</span>
              <span>新しい試合を開始する (第1エンドから)</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
