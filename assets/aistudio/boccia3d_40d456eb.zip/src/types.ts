export type Team = 'RED' | 'BLUE';

export type OpponentMode = 'VS_CPU' | '2P';

export type BallType = 'JACK' | 'RED' | 'BLUE';

export interface Ball {
  id: string;
  type: BallType;
  ballNumber?: number; // 1-6 for team balls
  boxNumber?: ThrowingBoxNumber; // Which throwing box this ball was launched from
  distFromJack?: number; // Distance in meters from Jack ball
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  mass: number;
  isSettled: boolean;
  isOutOfBounds: boolean;
  invalidNotice?: string;
  colorHex: string;
  lightHex: string;
  darkHex: string;
}

export type ThrowingBoxNumber = 1 | 2 | 3 | 4 | 5 | 6;

export type BoxThrowsRecord = Record<ThrowingBoxNumber, number>;

export type MatchType = 'TEAM' | 'PAIRS' | 'INDIVIDUAL';

export interface MatchTypeConfig {
  type: MatchType;
  name: string;
  shortName: string;
  description: string;
  boxesUsed: ThrowingBoxNumber[];
  redBoxes: ThrowingBoxNumber[];
  blueBoxes: ThrowingBoxNumber[];
  throwsPerBox: number;
  totalEnds: number;
  jackStarterBoxes: {
    RED: ThrowingBoxNumber;
    BLUE: ThrowingBoxNumber;
  };
  endStarters: {
    end: number;
    team: Team;
    box: ThrowingBoxNumber;
  }[];
}

export const MATCH_CONFIGS: Record<MatchType, MatchTypeConfig> = {
  TEAM: {
    type: 'TEAM',
    name: '団体戦 (トリオ / 3人制)',
    shortName: '団体戦',
    description: '全6エンド・ボックス①〜⑥使用・各枠2投',
    boxesUsed: [1, 2, 3, 4, 5, 6],
    redBoxes: [1, 3, 5],
    blueBoxes: [2, 4, 6],
    throwsPerBox: 2,
    totalEnds: 6,
    jackStarterBoxes: { RED: 1, BLUE: 2 },
    endStarters: [
      { end: 1, team: 'RED', box: 1 },
      { end: 2, team: 'BLUE', box: 2 },
      { end: 3, team: 'RED', box: 3 },
      { end: 4, team: 'BLUE', box: 4 },
      { end: 5, team: 'RED', box: 5 },
      { end: 6, team: 'BLUE', box: 6 },
    ],
  },
  PAIRS: {
    type: 'PAIRS',
    name: 'ペア戦 (ダブルス / 2人制)',
    shortName: 'ペア戦',
    description: '全4エンド・ボックス②〜⑤使用・各枠3投',
    boxesUsed: [2, 3, 4, 5],
    redBoxes: [2, 4],
    blueBoxes: [3, 5],
    throwsPerBox: 3,
    totalEnds: 4,
    jackStarterBoxes: { RED: 2, BLUE: 3 },
    endStarters: [
      { end: 1, team: 'RED', box: 2 },
      { end: 2, team: 'BLUE', box: 3 },
      { end: 3, team: 'RED', box: 4 },
      { end: 4, team: 'BLUE', box: 5 },
    ],
  },
  INDIVIDUAL: {
    type: 'INDIVIDUAL',
    name: '個人戦 (シングルス / 1人制)',
    shortName: '個人戦',
    description: '全4エンド・ボックス③・④使用・各枠6投',
    boxesUsed: [3, 4],
    redBoxes: [3],
    blueBoxes: [4],
    throwsPerBox: 6,
    totalEnds: 4,
    jackStarterBoxes: { RED: 3, BLUE: 4 },
    endStarters: [
      { end: 1, team: 'RED', box: 3 },
      { end: 2, team: 'BLUE', box: 4 },
      { end: 3, team: 'RED', box: 3 },
      { end: 4, team: 'BLUE', box: 4 },
    ],
  },
};

export function getEndStarter(
  matchType: MatchType,
  endNumber: number
): { end: number; team: Team; box: ThrowingBoxNumber } {
  const config = MATCH_CONFIGS[matchType];
  const list = config.endStarters;
  const idx = (Math.max(1, endNumber) - 1) % list.length;
  return list[idx];
}

export interface ThrowingBoxConfig {
  number: ThrowingBoxNumber;
  team: Team;
  label: string;
  x: number; // Center x in canvas coords
  y: number; // Center y in canvas coords
  width: number;
  height: number;
  isActiveInMode: boolean;
  playerTitle?: string;
}

export type BallHoldState = 'IDLE' | 'HOLD' | 'CHARGING' | 'ROLLING';

export type GamePhase =
  | 'READY' // Start screen
  | 'JACK_THROW' // Initial Jack throw
  | 'INITIAL_RED' // First red ball
  | 'INITIAL_BLUE' // First blue ball
  | 'IN_PLAY' // Boccia dynamic turn (furthest from Jack throws)
  | 'MEASURING' // Measuring tape animation
  | 'END_RESULT'; // Match or end result screen

export interface EndScoreRecord {
  end: number;
  redPoints: number;
  bluePoints: number;
  winner: Team | 'DRAW';
  starterTeam: Team;
  starterBox: ThrowingBoxNumber;
}

export interface MatchScore {
  currentEnd: number;
  totalEnds: number;
  isMatchOver: boolean;
  endScores: EndScoreRecord[];
  redPoints: number;
  bluePoints: number;
  totalRedScore: number;
  totalBlueScore: number;
  winningTeam: Team | 'DRAW' | null;
  scoringBallsCount: number;
  closestRedDist: number | null;
  closestBlueDist: number | null;
  scoringRadius?: number | null; // Radius of scoring zone circle in canvas pixels
  scoringBallIds?: string[]; // IDs of balls that scored points
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  vy: number;
  text: string;
  color: string;
  alpha: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  alpha: number;
}
