import { Ball, ThrowingBoxConfig, ThrowingBoxNumber, Team, MatchType, MATCH_CONFIGS } from './types';
import { sound } from './sound';

// Court dimensions (in canvas pixel coordinates 1024 x 720)
export const COURT = {
  CANVAS_WIDTH: 1024,
  CANVAS_HEIGHT: 720,

  // Sideline and Endline boundaries
  LEFT: 150,
  RIGHT: 874,
  TOP: 65,
  BOTTOM: 575, // Throwing line (スローイングライン)

  // Throwing box area
  BOX_TOP: 575,
  BOX_BOTTOM: 685,

  // Target Cross (クロスマーク)
  CROSS_X: 512,
  CROSS_Y: 280,
  CROSS_SIZE: 16,

  // V-Line (Jack Invalid Area) vertices
  // Official Boccia rule: V-shaped line with center apex pointing TOWARD the throwing line
  // 3.0m from throwing line at sidelines, 1.5m from throwing line at center
  V_LEFT_Y: 422,
  V_RIGHT_Y: 422,
  V_PEAK_Y: 498,

  // Ball specs
  BALL_RADIUS: 14,
  FRICTION: 0.980, // Natural Boccia ball rolling resistance
  RESTITUTION: 0.76, // Leather sphere clack restitution
  MIN_SPEED_CUTOFF: 0.04,

  // Launch speed parameters (Calibrated so short hold is gentle, long hold reaches far)
  MIN_LAUNCH_SPEED: 1.5, // Soft short roll (barely crosses V-line)
  MAX_LAUNCH_SPEED: 15.84, // Full-power throw (1.2x increased: reaches deeper court)
  MAX_CHARGE_DURATION_MS: 2800, // Speed half for fine timing control (2.8s for 100% power)
};

// Colors for Boccia balls
export const BALL_COLORS = {
  JACK: {
    hex: '#f8fafc',
    light: '#ffffff',
    dark: '#94a3b8',
    name: 'ジャックボール (白)',
  },
  RED: {
    hex: '#ef4444',
    light: '#fca5a5',
    dark: '#991b1b',
    name: '赤ボール',
  },
  BLUE: {
    hex: '#3b82f6',
    light: '#93c5fd',
    dark: '#1e40af',
    name: '青ボール',
  },
};

// Throwing boxes configuration supporting 3 match formats: TEAM, PAIRS, INDIVIDUAL
export function getThrowingBoxes(matchType: MatchType = 'TEAM'): ThrowingBoxConfig[] {
  const boxWidth = (COURT.RIGHT - COURT.LEFT) / 6;
  const boxHeight = COURT.BOX_BOTTOM - COURT.BOX_TOP;
  const boxes: ThrowingBoxConfig[] = [];
  const labels = ['①', '②', '③', '④', '⑤', '⑥'];
  const config = MATCH_CONFIGS[matchType];

  for (let i = 1; i <= 6; i++) {
    const num = i as ThrowingBoxNumber;
    const leftX = COURT.LEFT + (i - 1) * boxWidth;
    const centerX = leftX + boxWidth / 2;
    const centerY = COURT.BOX_TOP + boxHeight / 2;
    const isActive = config.boxesUsed.includes(num);

    let team: Team;
    let playerTitle = '';

    if (matchType === 'INDIVIDUAL') {
      team = num === 3 ? 'RED' : num === 4 ? 'BLUE' : num % 2 === 1 ? 'RED' : 'BLUE';
      if (num === 3) playerTitle = '赤 (1P)';
      else if (num === 4) playerTitle = '青 (2P)';
      else playerTitle = '未使用';
    } else if (matchType === 'PAIRS') {
      team = num === 2 || num === 4 ? 'RED' : num === 3 || num === 5 ? 'BLUE' : num % 2 === 1 ? 'RED' : 'BLUE';
      if (num === 2) playerTitle = '赤1';
      else if (num === 3) playerTitle = '青1';
      else if (num === 4) playerTitle = '赤2';
      else if (num === 5) playerTitle = '青2';
      else playerTitle = '未使用';
    } else {
      // TEAM (団体戦)
      team = num % 2 === 1 ? 'RED' : 'BLUE';
      if (num === 1) playerTitle = '赤1';
      else if (num === 2) playerTitle = '青1';
      else if (num === 3) playerTitle = '赤2';
      else if (num === 4) playerTitle = '青2';
      else if (num === 5) playerTitle = '赤3';
      else if (num === 6) playerTitle = '青3';
    }

    boxes.push({
      number: num,
      team,
      label: labels[i - 1],
      x: centerX,
      y: centerY,
      width: boxWidth,
      height: boxHeight,
      isActiveInMode: isActive,
      playerTitle,
    });
  }
  return boxes;
}

/**
 * Checks if a point (x, y) is inside the Jack Invalid Area (V-Line area)
 */
export function isInJackInvalidArea(x: number, y: number): boolean {
  if (y > COURT.BOTTOM || y < COURT.V_LEFT_Y) {
    return false;
  }
  if (x < COURT.LEFT || x > COURT.RIGHT) {
    return true; // Out of bounds is also invalid for Jack
  }

  let vLineY: number;
  if (x <= COURT.CROSS_X) {
    const t = (x - COURT.LEFT) / (COURT.CROSS_X - COURT.LEFT);
    vLineY = COURT.V_LEFT_Y + t * (COURT.V_PEAK_Y - COURT.V_LEFT_Y);
  } else {
    const t = (x - COURT.CROSS_X) / (COURT.RIGHT - COURT.CROSS_X);
    vLineY = COURT.V_PEAK_Y + t * (COURT.V_RIGHT_Y - COURT.V_PEAK_Y);
  }

  return y >= vLineY;
}

/**
 * Distance between two points in meters (court is 12.5m x 6m in real life)
 */
export function pixelDistToMeters(pxDist: number): number {
  const courtPixelWidth = COURT.RIGHT - COURT.LEFT;
  const metersPerPixel = 6.0 / courtPixelWidth;
  return Number((pxDist * metersPerPixel).toFixed(2));
}

/**
 * Calculate expected roll distance in pixels from initial speed
 */
export function calculateRollDistance(speed: number): number {
  if (speed <= COURT.MIN_SPEED_CUTOFF) return 0;
  // Geometric series sum: speed / (1 - FRICTION)
  return speed / (1 - COURT.FRICTION);
}

/**
 * Resolve ball movement and collisions
 */
export function updateBallPhysics(balls: Ball[]): { hasCollisions: boolean } {
  let anyCollided = false;

  // 1. Move balls and apply rolling friction
  for (const ball of balls) {
    if (ball.isSettled || ball.isOutOfBounds) continue;

    ball.x += ball.vx;
    ball.y += ball.vy;

    ball.vx *= COURT.FRICTION;
    ball.vy *= COURT.FRICTION;

    const speed = Math.hypot(ball.vx, ball.vy);
    if (speed < COURT.MIN_SPEED_CUTOFF) {
      ball.vx = 0;
      ball.vy = 0;
      ball.isSettled = true;
    }

    // Check true out of bounds
    const isPastLeft = ball.x < COURT.LEFT - ball.radius;
    const isPastRight = ball.x > COURT.RIGHT + ball.radius;
    const isPastTop = ball.y < COURT.TOP - ball.radius;
    const isPastRear = ball.y > COURT.BOX_BOTTOM + 25;

    if (isPastLeft || isPastRight || isPastTop || isPastRear) {
      if (!ball.isOutOfBounds) {
        ball.isOutOfBounds = true;
        ball.vx = 0;
        ball.vy = 0;
        ball.isSettled = true;
        sound.playOutOfBounds();

        if (ball.type === 'JACK') {
          // Official rule: if Jack goes out of bounds, replace at center cross
          ball.isOutOfBounds = false;
          ball.x = COURT.CROSS_X;
          ball.y = COURT.CROSS_Y;
          ball.invalidNotice =
            'ジャックボールが枠外に出たため、中央クロスに再配置されました';
        }
      }
    }
  }

  // 2. Ball-to-ball collision resolution
  for (let i = 0; i < balls.length; i++) {
    const b1 = balls[i];
    if (b1.isOutOfBounds) continue;

    for (let j = i + 1; j < balls.length; j++) {
      const b2 = balls[j];
      if (b2.isOutOfBounds) continue;

      const dx = b2.x - b1.x;
      const dy = b2.y - b1.y;
      const dist = Math.hypot(dx, dy);
      const minDist = b1.radius + b2.radius;

      if (dist < minDist && dist > 0.0001) {
        // Overlap correction
        const overlap = (minDist - dist) / 2;
        const nx = dx / dist;
        const ny = dy / dist;

        b1.x -= nx * overlap;
        b1.y -= ny * overlap;
        b2.x += nx * overlap;
        b2.y += ny * overlap;

        // Relative velocity
        const kx = b1.vx - b2.vx;
        const ky = b1.vy - b2.vy;
        const p = (2 * (nx * kx + ny * ky)) / (b1.mass + b2.mass);

        if (nx * kx + ny * ky > 0) {
          const impulse = p * COURT.RESTITUTION;
          b1.vx -= impulse * b2.mass * nx;
          b1.vy -= impulse * b2.mass * ny;
          b2.vx += impulse * b1.mass * nx;
          b2.vy += impulse * b1.mass * ny;

          b1.isSettled = false;
          b2.isSettled = false;

          const relSpeed = Math.hypot(kx, ky);
          sound.playBallClack(relSpeed / 5);
          anyCollided = true;
        }
      }
    }
  }

  return { hasCollisions: anyCollided };
}
