/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Ball,
  Team,
  OpponentMode,
  ThrowingBoxNumber,
  BallHoldState,
  GamePhase,
  MatchScore,
  BoxThrowsRecord,
  MatchType,
  MATCH_CONFIGS,
  EndScoreRecord,
  getEndStarter,
} from './types';
import {
  COURT,
  BALL_COLORS,
  getThrowingBoxes,
  isInJackInvalidArea,
  pixelDistToMeters,
  updateBallPhysics,
} from './physics';
import { sound } from './sound';
import { CourtCanvas } from './components/CourtCanvas';
import { ScoreHeader } from './components/ScoreHeader';
import { BoxSelector } from './components/BoxSelector';
import { ControlsGuide } from './components/ControlsGuide';
import { StartModal } from './components/StartModal';
import { GameOverModal } from './components/GameOverModal';

// Threshold to distinguish a short keyboard press (toggle hold) from long press (charge power)
const SHORT_PRESS_THRESHOLD_MS = 320;

export default function App() {
  // Opponent Mode (VS_CPU: PCと対戦 1人プレイ / 2P: 2人対戦)
  const [opponentMode, setOpponentMode] = useState<OpponentMode>('VS_CPU');
  const opponentModeRef = useRef<OpponentMode>('VS_CPU');
  opponentModeRef.current = opponentMode;

  // Player team in VS_CPU mode (RED: プレイヤーが赤 / BLUE: プレイヤーが青)
  const [playerTeam, setPlayerTeam] = useState<Team>('RED');
  const playerTeamRef = useRef<Team>('RED');
  playerTeamRef.current = playerTeam;

  // CPU team is opposite of human player team
  const cpuTeam: Team = playerTeam === 'RED' ? 'BLUE' : 'RED';
  const cpuTeamRef = useRef<Team>('BLUE');
  cpuTeamRef.current = cpuTeam;

  // Match Type (Team: 3人制 各枠2投 / Pairs: 2人制 各枠3投 / Individual: 1人制 各枠6投)
  const [matchType, setMatchType] = useState<MatchType>('TEAM');
  const matchTypeRef = useRef<MatchType>('TEAM');
  matchTypeRef.current = matchType;

  // Game phase & teams
  const [gamePhase, setGamePhase] = useState<GamePhase>('READY');
  const [currentTeam, setCurrentTeam] = useState<Team>('RED');
  const [jackStarterTeam, setJackStarterTeam] = useState<Team>('RED');
  const [selectedBoxNum, setSelectedBoxNum] = useState<ThrowingBoxNumber>(1);
  const [holdState, setHoldState] = useState<BallHoldState>('IDLE');
  const [turnCount, setTurnCount] = useState<number>(0);

  // Box throws record (tracks throws made per box)
  const [boxThrowsCount, setBoxThrowsCount] = useState<BoxThrowsRecord>({
    1: 0,
    2: 0,
    3: 0,
    4: 0,
    5: 0,
    6: 0,
  });

  // Aiming angle & power charge
  const [aimAngle, setAimAngle] = useState<number>(-Math.PI / 2); // straight forward
  const [chargeRatio, setChargeRatio] = useState<number>(0);

  // Balls on court
  const [balls, setBalls] = useState<Ball[]>([]);
  const [jackBall, setJackBall] = useState<Ball | null>(null);

  // Remaining balls (6 each team across all match formats)
  const [redBallsLeft, setRedBallsLeft] = useState<number>(6);
  const [blueBallsLeft, setBlueBallsLeft] = useState<number>(6);

  // Scores & End Tracking
  const [currentEnd, setCurrentEnd] = useState<number>(1);
  const [endScores, setEndScores] = useState<EndScoreRecord[]>([]);
  const [redScore, setRedScore] = useState<number>(0);
  const [blueScore, setBlueScore] = useState<number>(0);
  const [matchScoreResult, setMatchScoreResult] = useState<MatchScore | null>(null);

  // Referee announcement banner
  const [refereeNotice, setRefereeNotice] = useState<string>(
    '【準備完了】「対戦スタート」または「種目切替」で試合を開始できます。'
  );

  // Refs for real-time 60fps physics & keyboard handling
  const ballsRef = useRef<Ball[]>([]);
  ballsRef.current = balls;
  const jackBallRef = useRef<Ball | null>(null);
  jackBallRef.current = jackBall;
  const currentTeamRef = useRef<Team>('RED');
  currentTeamRef.current = currentTeam;
  const jackStarterTeamRef = useRef<Team>('RED');
  jackStarterTeamRef.current = jackStarterTeam;
  const currentEndRef = useRef<number>(1);
  currentEndRef.current = currentEnd;
  const endScoresRef = useRef<EndScoreRecord[]>([]);
  endScoresRef.current = endScores;
  const selectedBoxRef = useRef<ThrowingBoxNumber>(1);
  selectedBoxRef.current = selectedBoxNum;
  const holdStateRef = useRef<BallHoldState>('IDLE');
  holdStateRef.current = holdState;
  const aimAngleRef = useRef<number>(-Math.PI / 2);
  aimAngleRef.current = aimAngle;
  const chargeRatioRef = useRef<number>(0);
  chargeRatioRef.current = chargeRatio;
  const gamePhaseRef = useRef<GamePhase>('READY');
  gamePhaseRef.current = gamePhase;
  const redBallsLeftRef = useRef<number>(6);
  redBallsLeftRef.current = redBallsLeft;
  const blueBallsLeftRef = useRef<number>(6);
  blueBallsLeftRef.current = blueBallsLeft;
  const boxThrowsRef = useRef<BoxThrowsRecord>(boxThrowsCount);
  boxThrowsRef.current = boxThrowsCount;

  // Cumulative score refs
  const totalRedScoreRef = useRef<number>(0);
  const totalBlueScoreRef = useRef<number>(0);

  // Guard flags
  const isEndEvaluatedRef = useRef<boolean>(false);
  const measuringTimerRef = useRef<NodeJS.Timeout | null>(null);

  // CPU action timers
  const cpuTimeoutsRef = useRef<NodeJS.Timeout[]>([]);

  const clearCpuTimers = useCallback(() => {
    cpuTimeoutsRef.current.forEach((t) => clearTimeout(t));
    cpuTimeoutsRef.current = [];
  }, []);

  // Key tracking & chords buffer
  const rawKeysDownRef = useRef<Set<string>>(new Set());
  const isBothPressedRef = useRef<boolean>(false);
  const bothPressStartRef = useRef<number | null>(null);
  const chargeStartRef = useRef<number | null>(null);

  // Precision aim locking & grace window refs
  const singleKeyDownTimeRef = useRef<number | null>(null);
  const angleSnapshotBeforeChordRef = useRef<number | null>(null);
  const lockedAimAngleRef = useRef<number | null>(null);

  // Pending timer for single key box movement in IDLE state & aim adjustment in HOLD state
  const pendingBoxTimerRef = useRef<{ timer: NodeJS.Timeout; dir: 1 | -1 } | null>(null);
  const pendingAimTimerRef = useRef<{ timer: NodeJS.Timeout; dir: 1 | -1 } | null>(null);
  const justFinishedChordRef = useRef<boolean>(false);
  const chordReleaseTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const ensureAudio = useCallback(() => {
    sound.init();
  }, []);

  // Select Throwing Box (verifies match mode specific throws limit and active boxes)
  const handleSelectBox = useCallback((boxNum: ThrowingBoxNumber) => {
    ensureAudio();
    const config = MATCH_CONFIGS[matchTypeRef.current];
    const isRed = currentTeamRef.current === 'RED';
    const allowed: ThrowingBoxNumber[] = isRed ? config.redBoxes : config.blueBoxes;

    if (!allowed.includes(boxNum)) return;

    // Rule 1: Jack throw must be from the end's designated shifting box
    if (gamePhaseRef.current === 'JACK_THROW') {
      const endStarter = getEndStarter(matchTypeRef.current, currentEndRef.current);
      if (boxNum !== endStarter.box) {
        sound.playOutOfBounds();
        setRefereeNotice(
          `【第${currentEndRef.current}エンド規則】ジャックボールは指定ボックス ${endStarter.box} から投球してください。`
        );
        return;
      }
    }

    // Rule 2: The player/team who threw Jack must throw their first colored ball from that same box
    const isJackStarterNextBall =
      (gamePhaseRef.current === 'INITIAL_RED' && jackStarterTeamRef.current === 'RED') ||
      (gamePhaseRef.current === 'INITIAL_BLUE' && jackStarterTeamRef.current === 'BLUE');
    if (isJackStarterNextBall && jackBallRef.current?.boxNumber && boxNum !== jackBallRef.current.boxNumber) {
      sound.playOutOfBounds();
      setRefereeNotice(
        `【ボッチャ規則】ジャックボールを投球したボックス ${jackBallRef.current.boxNumber} から第1球を投球してください。`
      );
      return;
    }

    const thrown = boxThrowsRef.current[boxNum] || 0;
    if (thrown >= config.throwsPerBox && gamePhaseRef.current !== 'JACK_THROW') {
      sound.playOutOfBounds();
      setRefereeNotice(
        `【投球制限】ボックス ${boxNum} は既に制限の${config.throwsPerBox}球を投げ終えています。他のボックスを選んでください。`
      );
      return;
    }

    setSelectedBoxNum(boxNum);
    selectedBoxRef.current = boxNum;
    sound.playBoxSelect();
  }, [ensureAudio]);

  // Cycle Box for active player among boxes with throws remaining under match limit
  const cycleBox = useCallback((direction: 1 | -1) => {
    // Rule 1: Jack throw must be from the end's designated shifting box
    if (gamePhaseRef.current === 'JACK_THROW') {
      const endStarter = getEndStarter(matchTypeRef.current, currentEndRef.current);
      sound.playOutOfBounds();
      setRefereeNotice(
        `【第${currentEndRef.current}エンド規則】ジャックボールは指定ボックス ${endStarter.box} から投球してください。`
      );
      return;
    }

    // Rule 2: The player/team who threw Jack must throw their first colored ball from that same box
    const isJackStarterNextBall =
      (gamePhaseRef.current === 'INITIAL_RED' && jackStarterTeamRef.current === 'RED') ||
      (gamePhaseRef.current === 'INITIAL_BLUE' && jackStarterTeamRef.current === 'BLUE');
    if (isJackStarterNextBall && jackBallRef.current?.boxNumber) {
      sound.playOutOfBounds();
      setRefereeNotice(
        `【ボッチャ規則】ジャックボールを投球したボックス ${jackBallRef.current.boxNumber} から第1球を投球してください。`
      );
      return;
    }

    const config = MATCH_CONFIGS[matchTypeRef.current];
    const isRed = currentTeamRef.current === 'RED';
    const allAllowed: ThrowingBoxNumber[] = isRed ? config.redBoxes : config.blueBoxes;

    // Filter to boxes that haven't reached throws limit
    const available = allAllowed.filter(
      (b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox
    );
    if (available.length === 0) return;

    const currIdx = available.indexOf(selectedBoxRef.current);
    let nextIdx: number;
    if (currIdx === -1) {
      nextIdx = 0;
    } else {
      nextIdx = currIdx + direction;
      if (nextIdx < 0) nextIdx = available.length - 1;
      if (nextIdx >= available.length) nextIdx = 0;
    }

    handleSelectBox(available[nextIdx]);
  }, [handleSelectBox]);

  // Explicit Prev / Next box buttons
  const handlePrevBox = useCallback(() => {
    cycleBox(-1);
  }, [cycleBox]);

  const handleNextBox = useCallback(() => {
    cycleBox(1);
  }, [cycleBox]);

  // Cancel any pending single-key movements (box cycling or aim adjustments)
  const cancelPendingTimers = useCallback(() => {
    if (pendingBoxTimerRef.current) {
      clearTimeout(pendingBoxTimerRef.current.timer);
      pendingBoxTimerRef.current = null;
    }
    if (pendingAimTimerRef.current) {
      clearTimeout(pendingAimTimerRef.current.timer);
      pendingAimTimerRef.current = null;
    }
  }, []);

  // Align aiming direction towards the Jack ball (or center cross if Jack not thrown yet)
  const alignAimToJack = useCallback(() => {
    ensureAudio();
    const throwingBoxes = getThrowingBoxes(matchTypeRef.current);
    const activeBox =
      throwingBoxes.find((b) => b.number === selectedBoxRef.current) ||
      throwingBoxes[0];
    const startX = activeBox.x;
    const startY = COURT.BOTTOM - COURT.BALL_RADIUS - 4;

    const currentJack =
      jackBallRef.current || ballsRef.current.find((b) => b.type === 'JACK' && !b.isOutOfBounds);

    const targetX = currentJack ? currentJack.x : COURT.CROSS_X;
    const targetY = currentJack ? currentJack.y : COURT.CROSS_Y;

    const dx = targetX - startX;
    const dy = targetY - startY;
    const angleToJack = Math.atan2(dy, dx);
    const clamped = Math.max(-Math.PI * 0.95, Math.min(-Math.PI * 0.05, angleToJack));

    setAimAngle(clamped);
    aimAngleRef.current = clamped;
    lockedAimAngleRef.current = clamped;
    sound.playBoxSelect();
    setRefereeNotice(
      currentJack
        ? '🎯 【ジャック方向照準】ボール移動方向をジャックボールに向けました！'
        : '🎯 【中央クロス照準】ボール移動方向をセンタークロスに向けました！'
    );
  }, [ensureAudio]);

  // Toggle Ball Hold / Release
  const toggleBallHold = useCallback(() => {
    ensureAudio();
    cancelPendingTimers();
    if (holdStateRef.current === 'ROLLING') return;

    const isRed = currentTeamRef.current === 'RED';
    const phase = gamePhaseRef.current;
    const isJack = phase === 'JACK_THROW';

    if (holdStateRef.current === 'HOLD' || holdStateRef.current === 'CHARGING') {
      // Release ball back to IDLE
      setHoldState('IDLE');
      holdStateRef.current = 'IDLE';
      setChargeRatio(0);
      chargeRatioRef.current = 0;
      chargeStartRef.current = null;
      singleKeyDownTimeRef.current = null;
      angleSnapshotBeforeChordRef.current = null;
      lockedAimAngleRef.current = null;
      sound.stopChargingSound();
      sound.playHoldToggle(false);
      setRefereeNotice(
        isJack
          ? '【構え解除】ボックス変更可能。構えるには「ボールを構える」、投球はスローイングボタン！'
          : `【構え解除】${isRed ? '赤チーム' : '青チーム'} ボックス選択中。◀/▶で枠を変更できます。`
      );
    } else {
      // Hold ball (IDLE -> HOLD): ボックス決定後のボール保持タイミングでのみ自動ジャック照準
      alignAimToJack();
      setHoldState('HOLD');
      holdStateRef.current = 'HOLD';
      sound.playHoldToggle(true);
      setRefereeNotice(
        isJack
          ? '【白ジャック球 構え中】◀/▶で方向微調整、長押しまたは投球ボタンでスロー！'
          : `【${isRed ? '赤' : '青'}ボール 構え中】ジャック方向へ照準完了。◀/▶で微調整、長押しで投球！`
      );
    }
  }, [ensureAudio, cancelPendingTimers, alignAimToJack]);

  // Aim adjustments (strictly adjusts angle without forcing HOLD state)
  const handleAimLeft = useCallback(() => {
    ensureAudio();
    setAimAngle((prev) => Math.max(-Math.PI * 0.95, prev - 0.035));
  }, [ensureAudio]);

  const handleAimRight = useCallback(() => {
    ensureAudio();
    setAimAngle((prev) => Math.min(-Math.PI * 0.05, prev + 0.035));
  }, [ensureAudio]);

  // Start Charging Power (usable from both mouse/touch and keyboard)
  const startCharging = useCallback(() => {
    ensureAudio();
    cancelPendingTimers();
    if (holdStateRef.current === 'ROLLING') return;

    setHoldState('CHARGING');
    holdStateRef.current = 'CHARGING';
    lockedAimAngleRef.current = aimAngleRef.current;
    chargeStartRef.current = performance.now();
    sound.startChargingSound();
  }, [ensureAudio, cancelPendingTimers]);

  // Release and Throw Ball with calibrated non-linear power curve
  const releaseAndThrow = useCallback(() => {
    ensureAudio();
    cancelPendingTimers();
    sound.stopChargingSound();

    if (holdStateRef.current === 'ROLLING') return;

    let ratio = chargeRatioRef.current;
    if (ratio < 0.06) {
      ratio = 0.45; // Default reliable toss for quick clicks
    }

    const powerCurve = Math.pow(Math.min(1.0, ratio), 1.55);
    const speed =
      COURT.MIN_LAUNCH_SPEED +
      powerCurve * (COURT.MAX_LAUNCH_SPEED - COURT.MIN_LAUNCH_SPEED);

    const angle = lockedAimAngleRef.current ?? aimAngleRef.current;
    sound.playThrow(powerCurve);

    // Launch position: front edge of the active throwing box
    const throwingBoxes = getThrowingBoxes(matchTypeRef.current);
    const activeBox =
      throwingBoxes.find((b) => b.number === selectedBoxRef.current) ||
      throwingBoxes[0];
    const startX = activeBox.x;
    const startY = COURT.BOTTOM - COURT.BALL_RADIUS - 4;

    const phase = gamePhaseRef.current;
    let thrownBall: Ball;

    if (phase === 'JACK_THROW') {
      // Jack ball (White)
      thrownBall = {
        id: `jack-${Date.now()}`,
        type: 'JACK',
        boxNumber: selectedBoxRef.current,
        x: startX,
        y: startY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: COURT.BALL_RADIUS,
        mass: 0.95,
        isSettled: false,
        isOutOfBounds: false,
        colorHex: BALL_COLORS.JACK.hex,
        lightHex: BALL_COLORS.JACK.light,
        darkHex: BALL_COLORS.JACK.dark,
      };

      setJackBall(thrownBall);
      jackBallRef.current = thrownBall;
      ballsRef.current = [...ballsRef.current, thrownBall];
      setBalls([...ballsRef.current]);
    } else {
      // Regular ball (Red or Blue)
      const config = MATCH_CONFIGS[matchTypeRef.current];
      const team = currentTeamRef.current;
      const num =
        team === 'RED'
          ? 7 - redBallsLeftRef.current
          : 7 - blueBallsLeftRef.current;
      const ballColors = BALL_COLORS[team];
      const boxUsed = selectedBoxRef.current;

      thrownBall = {
        id: `${team}-${num}-${Date.now()}`,
        type: team,
        ballNumber: num,
        boxNumber: boxUsed,
        x: startX,
        y: startY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: COURT.BALL_RADIUS,
        mass: 1.0,
        isSettled: false,
        isOutOfBounds: false,
        colorHex: ballColors.hex,
        lightHex: ballColors.light,
        darkHex: ballColors.dark,
      };

      // Decrement team balls remaining
      if (team === 'RED') {
        setRedBallsLeft((prev) => Math.max(0, prev - 1));
        redBallsLeftRef.current = Math.max(0, redBallsLeftRef.current - 1);
      } else {
        setBlueBallsLeft((prev) => Math.max(0, prev - 1));
        blueBallsLeftRef.current = Math.max(0, blueBallsLeftRef.current - 1);
      }

      // Record this box throw (enforcing match throws limit)
      const currentBoxCount = (boxThrowsRef.current[boxUsed] || 0) + 1;
      const updatedBoxThrows = {
        ...boxThrowsRef.current,
        [boxUsed]: currentBoxCount,
      };
      setBoxThrowsCount(updatedBoxThrows);
      boxThrowsRef.current = updatedBoxThrows;

      ballsRef.current = [...ballsRef.current, thrownBall];
      setBalls([...ballsRef.current]);

      // If current box reached the throws limit, auto-switch to next available box for this team
      if (currentBoxCount >= config.throwsPerBox) {
        const teamBoxes = team === 'RED' ? config.redBoxes : config.blueBoxes;
        const nextAvail = teamBoxes.find((b) => (updatedBoxThrows[b] || 0) < config.throwsPerBox);
        if (nextAvail) {
          setSelectedBoxNum(nextAvail);
          selectedBoxRef.current = nextAvail;
        }
      }
    }

    setHoldState('ROLLING');
    holdStateRef.current = 'ROLLING';
    setChargeRatio(0);
    chargeRatioRef.current = 0;
    chargeStartRef.current = null;
    bothPressStartRef.current = null;
    isBothPressedRef.current = false;
    singleKeyDownTimeRef.current = null;
    angleSnapshotBeforeChordRef.current = null;
    lockedAimAngleRef.current = null;
  }, [ensureAudio, cancelPendingTimers]);

  // Throw with preset direct power
  const throwWithDirectPower = useCallback(
    (presetPower: number) => {
      ensureAudio();
      cancelPendingTimers();
      chargeRatioRef.current = presetPower;
      setChargeRatio(presetPower);
      releaseAndThrow();
    },
    [ensureAudio, cancelPendingTimers, releaseAndThrow]
  );

  // Evaluate scores at end of Boccia end and calculate scoring zone radius & ball IDs
  const evaluateEndResult = useCallback((forceMatchOver = false) => {
    if (isEndEvaluatedRef.current) return;
    isEndEvaluatedRef.current = true;

    if (measuringTimerRef.current) {
      clearTimeout(measuringTimerRef.current);
      measuringTimerRef.current = null;
    }

    setHoldState('IDLE');
    holdStateRef.current = 'IDLE';

    const config = MATCH_CONFIGS[matchTypeRef.current];
    const isMatchOver = forceMatchOver || currentEndRef.current >= config.totalEnds;

    const currentJack = jackBallRef.current;
    const currentBalls = ballsRef.current.filter(
      (b) => b.type !== 'JACK' && !b.isOutOfBounds
    );

    const prevRed = totalRedScoreRef.current;
    const prevBlue = totalBlueScoreRef.current;

    if (!currentJack || currentBalls.length === 0) {
      const endRecord: EndScoreRecord = {
        end: currentEndRef.current,
        redPoints: 0,
        bluePoints: 0,
        winner: 'DRAW',
        starterTeam: jackStarterTeamRef.current,
        starterBox: selectedBoxRef.current,
      };
      const nextEndScores = [...endScoresRef.current, endRecord];
      endScoresRef.current = nextEndScores;
      setEndScores(nextEndScores);

      const overallWinner =
        prevRed > prevBlue ? 'RED' : prevBlue > prevRed ? 'BLUE' : 'DRAW';

      setMatchScoreResult({
        currentEnd: currentEndRef.current,
        totalEnds: config.totalEnds,
        isMatchOver,
        endScores: nextEndScores,
        redPoints: 0,
        bluePoints: 0,
        totalRedScore: prevRed,
        totalBlueScore: prevBlue,
        winningTeam: isMatchOver ? overallWinner : 'DRAW',
        scoringBallsCount: 0,
        closestRedDist: null,
        closestBlueDist: null,
        scoringRadius: null,
        scoringBallIds: [],
      });
      setGamePhase('END_RESULT');
      gamePhaseRef.current = 'END_RESULT';
      sound.playFanfare();
      return;
    }

    const redDists: { ball: Ball; dist: number }[] = [];
    const blueDists: { ball: Ball; dist: number }[] = [];

    currentBalls.forEach((b) => {
      const d = Math.hypot(b.x - currentJack.x, b.y - currentJack.y);
      if (b.type === 'RED') redDists.push({ ball: b, dist: d });
      else if (b.type === 'BLUE') blueDists.push({ ball: b, dist: d });
    });

    redDists.sort((a, b) => a.dist - b.dist);
    blueDists.sort((a, b) => a.dist - b.dist);

    const minRed = redDists.length > 0 ? redDists[0].dist : Infinity;
    const minBlue = blueDists.length > 0 ? blueDists[0].dist : Infinity;

    let redPts = 0;
    let bluePts = 0;
    let winner: Team | 'DRAW' = 'DRAW';
    let scoringRadius: number | null = null;
    const scoringBallIds: string[] = [];

    if (minRed < minBlue) {
      winner = 'RED';
      const scoringBalls = redDists.filter((r) => r.dist < minBlue);
      redPts = scoringBalls.length;
      scoringBalls.forEach((r) => scoringBallIds.push(r.ball.id));
      scoringRadius = minBlue !== Infinity ? minBlue : (scoringBalls[scoringBalls.length - 1]?.dist ?? minRed) + 12;
    } else if (minBlue < minRed) {
      winner = 'BLUE';
      const scoringBalls = blueDists.filter((b) => b.dist < minRed);
      bluePts = scoringBalls.length;
      scoringBalls.forEach((b) => scoringBallIds.push(b.ball.id));
      scoringRadius = minRed !== Infinity ? minRed : (scoringBalls[scoringBalls.length - 1]?.dist ?? minBlue) + 12;
    } else {
      winner = 'DRAW';
      redPts = 0;
      bluePts = 0;
      scoringRadius = minRed !== Infinity ? minRed : null;
    }

    totalRedScoreRef.current += redPts;
    totalBlueScoreRef.current += bluePts;
    setRedScore(totalRedScoreRef.current);
    setBlueScore(totalBlueScoreRef.current);

    const endRecord: EndScoreRecord = {
      end: currentEndRef.current,
      redPoints: redPts,
      bluePoints: bluePts,
      winner,
      starterTeam: jackStarterTeamRef.current,
      starterBox: selectedBoxRef.current,
    };
    const nextEndScores = [...endScoresRef.current, endRecord];
    endScoresRef.current = nextEndScores;
    setEndScores(nextEndScores);

    const overallWinner =
      totalRedScoreRef.current > totalBlueScoreRef.current
        ? 'RED'
        : totalBlueScoreRef.current > totalRedScoreRef.current
        ? 'BLUE'
        : 'DRAW';

    setMatchScoreResult({
      currentEnd: currentEndRef.current,
      totalEnds: config.totalEnds,
      isMatchOver,
      endScores: nextEndScores,
      redPoints: redPts,
      bluePoints: bluePts,
      totalRedScore: totalRedScoreRef.current,
      totalBlueScore: totalBlueScoreRef.current,
      winningTeam: isMatchOver ? overallWinner : winner,
      scoringBallsCount: redPts + bluePts,
      closestRedDist: minRed !== Infinity ? pixelDistToMeters(minRed) : null,
      closestBlueDist: minBlue !== Infinity ? pixelDistToMeters(minBlue) : null,
      scoringRadius,
      scoringBallIds,
    });

    setGamePhase('END_RESULT');
    gamePhaseRef.current = 'END_RESULT';
    sound.playFanfare();

    if (isMatchOver) {
      const winnerLabel =
        overallWinner === 'RED'
          ? '赤チーム'
          : overallWinner === 'BLUE'
          ? '青チーム'
          : '引き分け';
      setRefereeNotice(
        `【全${config.totalEnds}エンド終了・試合終了】最終スコア: 🔴赤 ${totalRedScoreRef.current} - ${totalBlueScoreRef.current} 青🔵 (勝者: ${winnerLabel})`
      );
    } else {
      const nextEnd = currentEndRef.current + 1;
      const nextStarter = getEndStarter(config.type, nextEnd);
      setRefereeNotice(
        `【第${currentEndRef.current}エンド終了】赤 +${redPts}点 / 青 +${bluePts}点。次は第${nextEnd}エンド (ジャック先攻: ${nextStarter.team === 'RED' ? '赤' : '青'}・ボックス${nextStarter.box}) です！`
      );
    }
  }, []);

  // Post-roll phase & turn switching
  const checkTurnAfterRoll = useCallback(() => {
    const phase = gamePhaseRef.current;
    const starterTeam = jackStarterTeamRef.current;
    const jack = jackBallRef.current;
    const config = MATCH_CONFIGS[matchTypeRef.current];

    // 1. Jack Ball throw resolution
    if (phase === 'JACK_THROW') {
      if (jack) {
        if (isInJackInvalidArea(jack.x, jack.y)) {
          // BISFed rule: out of bounds or V-line invalid -> Jack placed on Jack Cross
          jack.x = COURT.CROSS_X;
          jack.y = COURT.CROSS_Y;
          jack.vx = 0;
          jack.vy = 0;
          jack.isOutOfBounds = false;
          jack.invalidNotice = 'ジャック無効エリアのためクロスへ再配置';
          sound.playOutOfBounds();
          setRefereeNotice(
            '【審判判定】ジャックボールが無効エリアのため、センタークロスに再配置しました。'
          );
        } else {
          setRefereeNotice(
            '【審判判定】ジャックボール有効！第1投の投球を開始してください。'
          );
        }
      }

      const endStarter = getEndStarter(config.type, currentEndRef.current);
      const jackBox =
        jack && jack.boxNumber
          ? jack.boxNumber
          : endStarter.box;

      if (starterTeam === 'RED') {
        setGamePhase('INITIAL_RED');
        gamePhaseRef.current = 'INITIAL_RED';
        setCurrentTeam('RED');
        currentTeamRef.current = 'RED';
        const boxToUse =
          (boxThrowsRef.current[jackBox] || 0) < config.throwsPerBox &&
          config.redBoxes.includes(jackBox)
            ? jackBox
            : config.redBoxes.find(
                (b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox
              ) || config.redBoxes[0];
        setSelectedBoxNum(boxToUse);
        selectedBoxRef.current = boxToUse;
      } else {
        setGamePhase('INITIAL_BLUE');
        gamePhaseRef.current = 'INITIAL_BLUE';
        setCurrentTeam('BLUE');
        currentTeamRef.current = 'BLUE';
        const boxToUse =
          (boxThrowsRef.current[jackBox] || 0) < config.throwsPerBox &&
          config.blueBoxes.includes(jackBox)
            ? jackBox
            : config.blueBoxes.find(
                (b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox
              ) || config.blueBoxes[0];
        setSelectedBoxNum(boxToUse);
        selectedBoxRef.current = boxToUse;
      }
      setTurnCount((prev) => prev + 1);
      sound.playTurnSwitch();
      return;
    }

    // 2. Initial Colored Ball throws
    if (phase === 'INITIAL_RED') {
      if (starterTeam === 'RED') {
        setGamePhase('INITIAL_BLUE');
        gamePhaseRef.current = 'INITIAL_BLUE';
        setCurrentTeam('BLUE');
        currentTeamRef.current = 'BLUE';
        const avail = config.blueBoxes.find((b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox) || config.blueBoxes[0];
        setSelectedBoxNum(avail);
        selectedBoxRef.current = avail;
        setRefereeNotice('🔵 青チーム 第1投を投球してください！');
        setTurnCount((prev) => prev + 1);
        sound.playTurnSwitch();
        return;
      }
    }

    if (phase === 'INITIAL_BLUE') {
      if (starterTeam === 'BLUE') {
        setGamePhase('INITIAL_RED');
        gamePhaseRef.current = 'INITIAL_RED';
        setCurrentTeam('RED');
        currentTeamRef.current = 'RED';
        const avail = config.redBoxes.find((b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox) || config.redBoxes[0];
        setSelectedBoxNum(avail);
        selectedBoxRef.current = avail;
        setRefereeNotice('🔴 赤チーム 第1投を投球してください！');
        setTurnCount((prev) => prev + 1);
        sound.playTurnSwitch();
        return;
      }
    }

    // 3. Subsequent Boccia turns: team FURTHEST from Jack throws next
    const rLeft = redBallsLeftRef.current;
    const bLeft = blueBallsLeftRef.current;

    if (rLeft === 0 && bLeft === 0) {
      if (measuringTimerRef.current || isEndEvaluatedRef.current) return;
      setRefereeNotice('【全投球終了】審判員がジャックボールとの距離を精密計測中...');
      setGamePhase('MEASURING');
      gamePhaseRef.current = 'MEASURING';
      measuringTimerRef.current = setTimeout(() => {
        evaluateEndResult();
      }, 1100);
      return;
    }

    if (rLeft === 0) {
      setCurrentTeam('BLUE');
      currentTeamRef.current = 'BLUE';
      const avail = config.blueBoxes.find((b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox) || config.blueBoxes[0];
      setSelectedBoxNum(avail);
      selectedBoxRef.current = avail;
      setGamePhase('IN_PLAY');
      gamePhaseRef.current = 'IN_PLAY';
      setRefereeNotice(`🔵 青組の番 (赤組全球終了 / 青組残球: ${bLeft})`);
      setTurnCount((prev) => prev + 1);
      sound.playTurnSwitch();
      return;
    }

    if (bLeft === 0) {
      setCurrentTeam('RED');
      currentTeamRef.current = 'RED';
      const avail = config.redBoxes.find((b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox) || config.redBoxes[0];
      setSelectedBoxNum(avail);
      selectedBoxRef.current = avail;
      setGamePhase('IN_PLAY');
      gamePhaseRef.current = 'IN_PLAY';
      setRefereeNotice(`🔴 赤組の番 (青組全球終了 / 赤組残球: ${rLeft})`);
      setTurnCount((prev) => prev + 1);
      sound.playTurnSwitch();
      return;
    }

    if (jack) {
      const activeBalls = ballsRef.current.filter(
        (b) => b.type !== 'JACK' && !b.isOutOfBounds
      );

      let minRedDist = Infinity;
      let minBlueDist = Infinity;

      activeBalls.forEach((b) => {
        const d = Math.hypot(b.x - jack.x, b.y - jack.y);
        if (b.type === 'RED' && d < minRedDist) minRedDist = d;
        if (b.type === 'BLUE' && d < minBlueDist) minBlueDist = d;
      });

      let nextTeam: Team = 'RED';
      if (minRedDist < minBlueDist) {
        nextTeam = 'BLUE';
        setRefereeNotice(
          `🔵 青組の番 (距離: ${pixelDistToMeters(minBlueDist)}m ＞ 赤: ${pixelDistToMeters(minRedDist)}m)`
        );
      } else {
        nextTeam = 'RED';
        setRefereeNotice(
          `🔴 赤組の番 (距離: ${pixelDistToMeters(minRedDist)}m ＞ 青: ${pixelDistToMeters(minBlueDist)}m)`
        );
      }

      setCurrentTeam(nextTeam);
      currentTeamRef.current = nextTeam;

      const allowed: ThrowingBoxNumber[] =
        nextTeam === 'RED' ? config.redBoxes : config.blueBoxes;
      const curr = selectedBoxRef.current;
      const currAllowedAndHasRemaining =
        allowed.includes(curr) && (boxThrowsRef.current[curr] || 0) < config.throwsPerBox;

      const targetBox = currAllowedAndHasRemaining
        ? curr
        : allowed.find((b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox) || allowed[0];

      setSelectedBoxNum(targetBox);
      selectedBoxRef.current = targetBox;
      setGamePhase('IN_PLAY');
      gamePhaseRef.current = 'IN_PLAY';
      setTurnCount((prev) => prev + 1);
      sound.playTurnSwitch();
    }
  }, [evaluateEndResult]);

  // Start specified end with shifting Jack starter and match mode
  const startEnd = useCallback(
    (endNumber: number, mode: MatchType = matchTypeRef.current) => {
      ensureAudio();
      cancelPendingTimers();
      clearCpuTimers();

      if (measuringTimerRef.current) {
        clearTimeout(measuringTimerRef.current);
        measuringTimerRef.current = null;
      }
      isEndEvaluatedRef.current = false;

      sound.playWhistle();

      const config = MATCH_CONFIGS[mode];
      const endStarter = getEndStarter(mode, endNumber);
      const starter = endStarter.team;
      const startBox: ThrowingBoxNumber = endStarter.box;

      setCurrentEnd(endNumber);
      currentEndRef.current = endNumber;

      setJackStarterTeam(starter);
      jackStarterTeamRef.current = starter;

      setGamePhase('JACK_THROW');
      gamePhaseRef.current = 'JACK_THROW';
      setCurrentTeam(starter);
      currentTeamRef.current = starter;
      setSelectedBoxNum(startBox);
      selectedBoxRef.current = startBox;

      setHoldState('IDLE');
      holdStateRef.current = 'IDLE';
      setAimAngle(-Math.PI / 2);
      aimAngleRef.current = -Math.PI / 2;
      setChargeRatio(0);
      chargeRatioRef.current = 0;

      singleKeyDownTimeRef.current = null;
      angleSnapshotBeforeChordRef.current = null;
      lockedAimAngleRef.current = null;

      ballsRef.current = [];
      setBalls([]);
      setJackBall(null);
      jackBallRef.current = null;
      setRedBallsLeft(6);
      redBallsLeftRef.current = 6;
      setBlueBallsLeft(6);
      blueBallsLeftRef.current = 6;

      const cleanBoxRecord: BoxThrowsRecord = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0 };
      setBoxThrowsCount(cleanBoxRecord);
      boxThrowsRef.current = cleanBoxRecord;

      setMatchScoreResult(null);

      const starterBoxLabel = `ボックス${['①', '②', '③', '④', '⑤', '⑥'][startBox - 1]}`;
      const isVsCpu = opponentModeRef.current === 'VS_CPU';
      const isPlayerStarter = starter === playerTeamRef.current;
      if (isVsCpu) {
        setRefereeNotice(
          isPlayerStarter
            ? `【第${endNumber}/${config.totalEnds}エンド・${config.shortName}】あなたの番です！${starter === 'RED' ? '赤' : '青'}チーム(${starterBoxLabel})からジャックボール(白)を投球してください！`
            : `【第${endNumber}/${config.totalEnds}エンド・${config.shortName}】PC(${starter === 'RED' ? '赤' : '青'}チーム・${starterBoxLabel})がジャックボール(白)を投球します。`
        );
      } else {
        setRefereeNotice(
          starter === 'RED'
            ? `【第${endNumber}/${config.totalEnds}エンド・${config.shortName}】赤チーム(${starterBoxLabel})からジャックボール(白)を投球してください！`
            : `【第${endNumber}/${config.totalEnds}エンド・${config.shortName}】青チーム(${starterBoxLabel})からジャックボール(白)を投球してください！`
        );
      }
      setTurnCount((prev) => prev + 1);
    },
    [ensureAudio, cancelPendingTimers, clearCpuTimers]
  );

  const handleStartGame = useCallback(() => {
    startEnd(1, matchTypeRef.current);
  }, [startEnd]);

  const handleNextEnd = useCallback(() => {
    const nextEndNum = currentEndRef.current + 1;
    startEnd(nextEndNum, matchTypeRef.current);
  }, [startEnd]);

  // Reset entire match to End 1: resets score, history, and Jack starter to End 1 box
  const handleResetGame = useCallback(() => {
    ensureAudio();
    clearCpuTimers();
    totalRedScoreRef.current = 0;
    totalBlueScoreRef.current = 0;
    setRedScore(0);
    setBlueScore(0);
    endScoresRef.current = [];
    setEndScores([]);

    startEnd(1, matchTypeRef.current);

    const config = MATCH_CONFIGS[matchTypeRef.current];
    const firstStarter = getEndStarter(matchTypeRef.current, 1);
    const starterBoxLabel = `ボックス${['①', '②', '③', '④', '⑤', '⑥'][firstStarter.box - 1]}`;
    setRefereeNotice(
      `【リセット・${config.shortName}】第1エンドから再スタート。ジャック先攻は【${firstStarter.team === 'RED' ? '赤' : '青'}チーム (${starterBoxLabel})】です！`
    );
  }, [ensureAudio, clearCpuTimers, startEnd]);

  // Change Match Type: 団体戦 (6エンド) ⇄ ペア戦 (4エンド) ⇄ 個人戦 (4エンド)
  const handleChangeMatchType = useCallback(
    (newType: MatchType) => {
      ensureAudio();
      clearCpuTimers();
      setMatchType(newType);
      matchTypeRef.current = newType;
      totalRedScoreRef.current = 0;
      totalBlueScoreRef.current = 0;
      setRedScore(0);
      setBlueScore(0);
      endScoresRef.current = [];
      setEndScores([]);

      startEnd(1, newType);

      const config = MATCH_CONFIGS[newType];
      const firstStarter = getEndStarter(newType, 1);
      const starterBoxLabel = `ボックス${['①', '②', '③', '④', '⑤', '⑥'][firstStarter.box - 1]}`;
      setRefereeNotice(
        `【種目切替: ${config.name} (全${config.totalEnds}エンド)】各枠${config.throwsPerBox}投制限。第1エンド先攻は${firstStarter.team === 'RED' ? '赤' : '青'}チーム(${starterBoxLabel})です！`
      );
    },
    [ensureAudio, clearCpuTimers, startEnd]
  );

  // Switch Opponent Mode: PC対戦 (1人) ⇄ 2人対戦 (2P)
  const handleChangeOpponentMode = useCallback(
    (newMode: OpponentMode) => {
      ensureAudio();
      clearCpuTimers();
      setOpponentMode(newMode);
      opponentModeRef.current = newMode;
      sound.playTurnSwitch();
      setTurnCount((prev) => prev + 1);
      setRefereeNotice(
        newMode === 'VS_CPU'
          ? `【対戦モード変更】🤖 PCと対戦 (1人プレイ) に変更しました。(自分: ${playerTeamRef.current === 'RED' ? '赤' : '青'} / PC: ${cpuTeamRef.current === 'RED' ? '赤' : '青'})`
          : '【対戦モード変更】👥 2人対戦 (ローカル) に変更しました。'
      );
    },
    [ensureAudio, clearCpuTimers]
  );

  // Switch Player Team in VS_CPU mode: 赤 ⇄ 青
  const handleChangePlayerTeam = useCallback(
    (newTeam: Team) => {
      ensureAudio();
      clearCpuTimers();
      setPlayerTeam(newTeam);
      playerTeamRef.current = newTeam;
      const newCpu: Team = newTeam === 'RED' ? 'BLUE' : 'RED';
      cpuTeamRef.current = newCpu;
      sound.playTurnSwitch();
      setTurnCount((prev) => prev + 1);
      setRefereeNotice(
        `【チーム色変更】あなたの担当を【${newTeam === 'RED' ? '🔴 赤チーム (1P)' : '🔵 青チーム (2P)'}】に変更しました (PC: ${newCpu === 'RED' ? '赤' : '青'})。`
      );
    },
    [ensureAudio, clearCpuTimers]
  );

  // Manual end match button
  const handleFinishMatch = useCallback(() => {
    ensureAudio();
    clearCpuTimers();
    if (gamePhaseRef.current === 'END_RESULT') return;
    setHoldState('IDLE');
    holdStateRef.current = 'IDLE';
    evaluateEndResult(true);
  }, [ensureAudio, clearCpuTimers, evaluateEndResult]);

  // Autonomous CPU Opponent Engine
  useEffect(() => {
    // If not in VS_CPU mode or match is not active, clean up any timers and return
    if (
      opponentMode !== 'VS_CPU' ||
      gamePhase === 'READY' ||
      gamePhase === 'MEASURING' ||
      gamePhase === 'END_RESULT'
    ) {
      clearCpuTimers();
      return;
    }

    // Check if it is currently the CPU's turn to throw
    const isCpuTurn = currentTeam === cpuTeam;
    if (!isCpuTurn) {
      clearCpuTimers();
      return;
    }

    // Clear any previous CPU timers before starting the new turn's sequence
    clearCpuTimers();

    const timers: NodeJS.Timeout[] = [];

    // Step 1: Thinking & Selecting Box (Delay 550ms)
    const t1 = setTimeout(() => {
      if (
        opponentModeRef.current !== 'VS_CPU' ||
        currentTeamRef.current !== cpuTeamRef.current ||
        gamePhaseRef.current === 'READY' ||
        gamePhaseRef.current === 'END_RESULT'
      ) {
        return;
      }

      const config = MATCH_CONFIGS[matchTypeRef.current];
      const isRedCpu = cpuTeamRef.current === 'RED';
      const allowed = isRedCpu ? config.redBoxes : config.blueBoxes;
      const available = allowed.filter(
        (b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox
      );

      if (available.length === 0) return;

      let chosenBox = available[0];
      const isJackThrow = gamePhaseRef.current === 'JACK_THROW';
      const isNextBallAfterJack =
        (gamePhaseRef.current === 'INITIAL_RED' && jackStarterTeamRef.current === 'RED') ||
        (gamePhaseRef.current === 'INITIAL_BLUE' && jackStarterTeamRef.current === 'BLUE');

      if (isJackThrow) {
        const endStarter = getEndStarter(matchTypeRef.current, currentEndRef.current);
        const starterBox = endStarter.box;
        if (available.includes(starterBox)) {
          chosenBox = starterBox;
        }
      } else if (isNextBallAfterJack) {
        // PC must only throw from the box from which it threw the Jack ball
        const endStarter = getEndStarter(matchTypeRef.current, currentEndRef.current);
        const jackBox =
          jackBallRef.current?.boxNumber || endStarter.box;
        if (available.includes(jackBox)) {
          chosenBox = jackBox;
        }
      } else {
        const currentJack =
          jackBallRef.current || ballsRef.current.find((b) => b.type === 'JACK' && !b.isOutOfBounds);
        const targetX = currentJack ? currentJack.x : COURT.CROSS_X;
        const boxes = getThrowingBoxes(matchTypeRef.current);
        let minDiff = Infinity;
        for (const b of available) {
          const conf = boxes.find((tb) => tb.number === b);
          if (conf) {
            const diff = Math.abs(conf.x - targetX);
            if (diff < minDiff) {
              minDiff = diff;
              chosenBox = b;
            }
          }
        }
      }

      setSelectedBoxNum(chosenBox);
      selectedBoxRef.current = chosenBox;
      sound.playBoxSelect();
      const refereeMsg = isNextBallAfterJack
        ? `🤖 【PC思考】ジャックボールを投球したボックス${chosenBox}から第1球を投球します。`
        : `🤖 【PC思考】${isRedCpu ? '赤' : '青'}チーム(PC)がボックス${chosenBox}を選択しました。`;
      setRefereeNotice(refereeMsg);

      // Step 2: Hold ball & Aim towards Target (Delay 450ms)
      const t2 = setTimeout(() => {
        if (
          opponentModeRef.current !== 'VS_CPU' ||
          currentTeamRef.current !== cpuTeamRef.current
        ) {
          return;
        }

        setHoldState('HOLD');
        holdStateRef.current = 'HOLD';
        sound.playHoldToggle(true);

        const boxes = getThrowingBoxes(matchTypeRef.current);
        const activeBox =
          boxes.find((b) => b.number === selectedBoxRef.current) || boxes[0];
        const startX = activeBox.x;
        const startY = COURT.BOTTOM - COURT.BALL_RADIUS - 4;

        let targetX = COURT.CROSS_X;
        let targetY = COURT.CROSS_Y;

        if (gamePhaseRef.current === 'JACK_THROW') {
          targetX = COURT.CROSS_X + (Math.random() - 0.5) * 100;
          targetY = COURT.CROSS_Y + (Math.random() - 0.5) * 140;
        } else {
          const currentJack =
            jackBallRef.current || ballsRef.current.find((b) => b.type === 'JACK' && !b.isOutOfBounds);
          if (currentJack) {
            targetX = currentJack.x + (Math.random() - 0.5) * 14;
            targetY = currentJack.y + 6 + (Math.random() - 0.5) * 16;
          }
        }

        const dx = targetX - startX;
        const dy = targetY - startY;
        const angle = Math.atan2(dy, dx);
        const clampedAngle = Math.max(-Math.PI * 0.95, Math.min(-Math.PI * 0.05, angle));

        setAimAngle(clampedAngle);
        aimAngleRef.current = clampedAngle;
        lockedAimAngleRef.current = clampedAngle;
        setRefereeNotice(
          `🤖 【PC照準完了】${isRedCpu ? '赤' : '青'}チーム(PC)が狙いを定め、パワーを充電中...`
        );

        // Step 3: Power Charging (Delay 450ms)
        const t3 = setTimeout(() => {
          if (
            opponentModeRef.current !== 'VS_CPU' ||
            currentTeamRef.current !== cpuTeamRef.current
          ) {
            return;
          }

          setHoldState('CHARGING');
          holdStateRef.current = 'CHARGING';
          sound.startChargingSound();

          const dist = Math.hypot(dx, dy);
          const idealSpeed = dist * (1 - COURT.FRICTION); // 0.02
          const curve =
            (idealSpeed - COURT.MIN_LAUNCH_SPEED) /
            (COURT.MAX_LAUNCH_SPEED - COURT.MIN_LAUNCH_SPEED);
          const idealRatio = Math.pow(Math.max(0.04, Math.min(1.0, curve)), 1 / 1.55);
          const noise = (Math.random() - 0.5) * 0.04;
          const finalRatio = Math.max(0.12, Math.min(1.0, idealRatio + noise));

          setChargeRatio(finalRatio);
          chargeRatioRef.current = finalRatio;

          // Step 4: Throw ball (Delay 450ms)
          const t4 = setTimeout(() => {
            sound.stopChargingSound();
            releaseAndThrow();
          }, 450);

          timers.push(t4);
        }, 450);

        timers.push(t3);
      }, 450);

      timers.push(t2);
    }, 550);

    timers.push(t1);
    cpuTimeoutsRef.current = timers;

    return () => {
      timers.forEach((t) => clearTimeout(t));
    };
  }, [turnCount, opponentMode, currentTeam, cpuTeam, gamePhase, releaseAndThrow, clearCpuTimers]);

  // Main 60 FPS Physics loop & charge ramp
  useEffect(() => {
    let animId: number;

    const loop = () => {
      // 1. Long-press check when both keys are held (transition to CHARGING after SHORT_PRESS_THRESHOLD_MS)
      if (isBothPressedRef.current && bothPressStartRef.current !== null) {
        const pressDuration = performance.now() - bothPressStartRef.current;
        if (pressDuration >= SHORT_PRESS_THRESHOLD_MS) {
          if (holdStateRef.current === 'HOLD') {
            setHoldState('CHARGING');
            holdStateRef.current = 'CHARGING';
            lockedAimAngleRef.current = aimAngleRef.current;
            chargeStartRef.current = performance.now();
            sound.startChargingSound();
          } else if (holdStateRef.current === 'IDLE') {
            // If held long directly from IDLE, align to Jack and begin charging
            alignAimToJack();
            setHoldState('CHARGING');
            holdStateRef.current = 'CHARGING';
            lockedAimAngleRef.current = aimAngleRef.current;
            chargeStartRef.current = performance.now();
            sound.playHoldToggle(true);
            sound.startChargingSound();
          }
        }
      }

      // 2. Charge ramp when in CHARGING state (Speed halved: 2800ms cycle for comfortable timing)
      if (holdStateRef.current === 'CHARGING' && chargeStartRef.current !== null) {
        const elapsed = performance.now() - chargeStartRef.current;
        const CHARGE_CYCLE_MS = 2800; // 以前の1400msから2倍（速度1/2）にしてタイミングをとりやすくする
        const normalized = (elapsed % (CHARGE_CYCLE_MS * 2)) / CHARGE_CYCLE_MS;
        const ratio = normalized <= 1.0 ? normalized : 2.0 - normalized;
        const clamped = Math.max(0.05, Math.min(1.0, ratio));
        setChargeRatio(clamped);
        chargeRatioRef.current = clamped;
        sound.updateChargingSound(clamped);
      }

      // 3. Physics simulation when ball is ROLLING
      if (holdStateRef.current === 'ROLLING') {
        updateBallPhysics(ballsRef.current);
        const nextBalls = ballsRef.current;
        const currentJack = nextBalls.find((b) => b.type === 'JACK') || null;
        jackBallRef.current = currentJack;

        const anyRolling = nextBalls.some((b) => !b.isSettled && !b.isOutOfBounds);

        setBalls([...nextBalls]);
        setJackBall(currentJack ? { ...currentJack } : null);

        if (!anyRolling) {
          // All balls settled!
          setHoldState('IDLE');
          holdStateRef.current = 'IDLE';
          checkTurnAfterRoll();
        }
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [checkTurnAfterRoll]);

  // Keyboard Event Handlers (2-Key Simplex & Aim Locking)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore text input fields
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) return;

      ensureAudio();
      const key = e.key;

      if (key === 'Enter' || key === ' ') {
        if (gamePhaseRef.current === 'READY') {
          handleStartGame();
          e.preventDefault();
          return;
        }
      }

      // Lock human keyboard input when it is the PC's turn in VS_CPU mode
      if (
        opponentModeRef.current === 'VS_CPU' &&
        currentTeamRef.current === cpuTeamRef.current
      ) {
        return;
      }

      // Escape key cancels hold back to box selection
      if (key === 'Escape' || key === 'Esc') {
        if (holdStateRef.current === 'HOLD' || holdStateRef.current === 'CHARGING') {
          toggleBallHold();
          e.preventDefault();
          return;
        }
      }

      // Both players can use their respective keys at all times:
      // Red Player: 'a'/'A' (Left/Prev) and 'w'/'W' (Right/Next)
      // Blue Player: 'ArrowDown' (Left/Prev) and 'ArrowRight' (Right/Next)
      const isRed1 = key === 'a' || key === 'A';
      const isRed2 = key === 'w' || key === 'W';
      const isBlue1 = key === 'ArrowDown';
      const isBlue2 = key === 'ArrowRight';

      const isKey1 = isRed1 || isBlue1;
      const isKey2 = isRed2 || isBlue2;

      if (!isKey1 && !isKey2) return;
      e.preventDefault();

      // If already chord-pressed or actively charging, ignore key repeats to prevent any aim drift
      if (isBothPressedRef.current || holdStateRef.current === 'CHARGING') {
        return;
      }

      // Continuous aim adjustment for held single key
      if (e.repeat) {
        if (holdStateRef.current === 'HOLD') {
          cancelPendingTimers();
          if (isKey1) {
            const next = Math.max(-Math.PI * 0.95, aimAngleRef.current - 0.025);
            setAimAngle(next);
            aimAngleRef.current = next;
          }
          if (isKey2) {
            const next = Math.min(-Math.PI * 0.05, aimAngleRef.current + 0.025);
            setAimAngle(next);
            aimAngleRef.current = next;
          }
        }
        return;
      }

      const activeKeys = rawKeysDownRef.current;
      activeKeys.add(key);

      const hasRed1 = activeKeys.has('a') || activeKeys.has('A');
      const hasRed2 = activeKeys.has('w') || activeKeys.has('W');
      const hasBlue1 = activeKeys.has('ArrowDown');
      const hasBlue2 = activeKeys.has('ArrowRight');

      const isChord =
        (hasRed1 && hasRed2) ||
        (hasBlue1 && hasBlue2) ||
        ((hasRed1 || hasBlue1) && (hasRed2 || hasBlue2));

      if (isChord) {
        // BOTH keys pressed simultaneously (chord formed)
        cancelPendingTimers();

        if (!isBothPressedRef.current) {
          isBothPressedRef.current = true;
          bothPressStartRef.current = performance.now();
          justFinishedChordRef.current = false;
          // ボックス決定後のキー同時押しによるボール保持(IDLE時)のみ自動でジャックボール方向に向ける
          if (holdStateRef.current === 'IDLE') {
            alignAimToJack();
          } else {
            // ボール保持中は現在の調整済み角度をそのまま維持
            lockedAimAngleRef.current = aimAngleRef.current;
          }
        }
      } else {
        // Single key pressed: schedule action after 110ms grace period so simultaneous press doesn't drift
        singleKeyDownTimeRef.current = performance.now();
        angleSnapshotBeforeChordRef.current = aimAngleRef.current;
        cancelPendingTimers();

        const dir: 1 | -1 = isKey1 ? -1 : 1;

        if (holdStateRef.current === 'IDLE') {
          // Schedule box movement if chord doesn't form within 110ms
          const timer = setTimeout(() => {
            if (!isBothPressedRef.current && holdStateRef.current === 'IDLE') {
              cycleBox(dir);
            }
            pendingBoxTimerRef.current = null;
          }, 110);
          pendingBoxTimerRef.current = { timer, dir };
        } else if (holdStateRef.current === 'HOLD') {
          // Schedule aim adjustment if chord doesn't form within 110ms
          const timer = setTimeout(() => {
            if (!isBothPressedRef.current && holdStateRef.current === 'HOLD') {
              const next =
                dir === -1
                  ? Math.max(-Math.PI * 0.95, aimAngleRef.current - 0.025)
                  : Math.min(-Math.PI * 0.05, aimAngleRef.current + 0.025);
              setAimAngle(next);
              aimAngleRef.current = next;
            }
            pendingAimTimerRef.current = null;
          }, 110);
          pendingAimTimerRef.current = { timer, dir };
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      // Lock human keyboard input when it is the PC's turn in VS_CPU mode
      if (
        opponentModeRef.current === 'VS_CPU' &&
        currentTeamRef.current === cpuTeamRef.current
      ) {
        return;
      }

      const key = e.key;

      const isRed1 = key === 'a' || key === 'A';
      const isRed2 = key === 'w' || key === 'W';
      const isBlue1 = key === 'ArrowDown';
      const isBlue2 = key === 'ArrowRight';

      const isCurrentKey1 = isRed1 || isBlue1;
      const isCurrentKey2 = isRed2 || isBlue2;

      if (!isCurrentKey1 && !isCurrentKey2) return;

      const activeKeys = rawKeysDownRef.current;
      activeKeys.delete(key);
      if (isRed1) { activeKeys.delete('a'); activeKeys.delete('A'); }
      if (isRed2) { activeKeys.delete('w'); activeKeys.delete('W'); }

      const wasBothPressed = isBothPressedRef.current;

      if (wasBothPressed) {
        const pressDuration = bothPressStartRef.current
          ? performance.now() - bothPressStartRef.current
          : 0;

        cancelPendingTimers();
        isBothPressedRef.current = false;
        bothPressStartRef.current = null;
        singleKeyDownTimeRef.current = null;

        // Shield against trailing key release from the chord
        justFinishedChordRef.current = true;
        if (chordReleaseTimeoutRef.current) clearTimeout(chordReleaseTimeoutRef.current);
        chordReleaseTimeoutRef.current = setTimeout(() => {
          justFinishedChordRef.current = false;
        }, 220);

        // 短い同時押し（320ms未満）: ボールの保持(IDLE->HOLD)と解放(HOLD->IDLE)を確実に切り替える
        if (pressDuration < SHORT_PRESS_THRESHOLD_MS) {
          if (holdStateRef.current === 'CHARGING') {
            sound.stopChargingSound();
          }
          toggleBallHold();
        } else {
          // 長押し（320ms以上）: パワーチャージ投球を実行
          releaseAndThrow();
        }
      } else {
        // If a chord was just released, do NOT process this keyup as a single key action!
        if (justFinishedChordRef.current) {
          return;
        }

        // Single key tap release: if pending timer was still waiting, apply exactly 1 notch now
        if (holdStateRef.current === 'HOLD') {
          if (pendingAimTimerRef.current) {
            const dir = pendingAimTimerRef.current.dir;
            cancelPendingTimers();
            const next =
              dir === -1
                ? Math.max(-Math.PI * 0.95, aimAngleRef.current - 0.02)
                : Math.min(-Math.PI * 0.05, aimAngleRef.current + 0.02);
            setAimAngle(next);
            aimAngleRef.current = next;
          }
        } else if (holdStateRef.current === 'IDLE') {
          if (pendingBoxTimerRef.current) {
            const dir = pendingBoxTimerRef.current.dir;
            cancelPendingTimers();
            cycleBox(dir);
          }
        }
        singleKeyDownTimeRef.current = null;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      cancelPendingTimers();
      if (chordReleaseTimeoutRef.current) clearTimeout(chordReleaseTimeoutRef.current);
    };
  }, [
    ensureAudio,
    handleStartGame,
    cycleBox,
    cancelPendingTimers,
    toggleBallHold,
    alignAimToJack,
    releaseAndThrow,
  ]);

  const currentMatchConfig = MATCH_CONFIGS[matchType];
  const nextEnd = currentEnd + 1;
  const nextEndStarter = getEndStarter(matchType, nextEnd);
  const nextStarterInfo = currentEnd < currentMatchConfig.totalEnds ? nextEndStarter : undefined;

  const isCpuTurn =
    opponentMode === 'VS_CPU' &&
    currentTeam === cpuTeam &&
    gamePhase !== 'READY' &&
    gamePhase !== 'MEASURING' &&
    gamePhase !== 'END_RESULT';

  return (
    <div className="w-screen min-h-screen flex flex-col justify-between items-center bg-slate-950 text-slate-100 overflow-x-hidden p-1 sm:p-3 select-none">
      {/* Top Header with Mode Tabs, Live Score & Controls */}
      <ScoreHeader
        currentTeam={currentTeam}
        gamePhase={gamePhase}
        redScore={redScore}
        blueScore={blueScore}
        redBallsLeft={redBallsLeft}
        blueBallsLeft={blueBallsLeft}
        selectedBoxNum={selectedBoxNum}
        jackStarterTeam={jackStarterTeam}
        matchType={matchType}
        opponentMode={opponentMode}
        playerTeam={playerTeam}
        currentEnd={currentEnd}
        totalEnds={currentMatchConfig.totalEnds}
        endScores={endScores}
        isCpuTurn={isCpuTurn}
        onChangeMatchType={handleChangeMatchType}
        onChangeOpponentMode={handleChangeOpponentMode}
        onChangePlayerTeam={handleChangePlayerTeam}
        onFinishMatch={handleFinishMatch}
        onResetGame={handleResetGame}
      />

      {/* Main Game Court Container */}
      <main className="relative w-full max-w-[1024px] my-1 flex flex-col items-center">
        {/* Referee Notice Banner */}
        <div className="w-full flex flex-col sm:flex-row justify-between items-center px-4 py-1.5 mb-1 bg-slate-900/95 rounded-xl border border-slate-800 text-xs shadow-md gap-1">
          <div className="flex items-center space-x-2">
            <span className="text-amber-400">📢</span>
            <span className="font-semibold text-slate-200">{refereeNotice}</span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={handleResetGame}
              className="text-[11px] font-bold px-3 py-1 rounded-lg bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-600/50 transition-all cursor-pointer shadow-sm flex items-center space-x-1"
              title="試合スコアをリセットし、第1エンドから開始します"
            >
              <span>🔄</span>
              <span>第1エンドからリセット</span>
            </button>
            <button
              type="button"
              onClick={handleFinishMatch}
              className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 transition-all cursor-pointer"
            >
              試合終了 (判定)
            </button>
          </div>
        </div>

        {/* Court Canvas with Scoring Zone Circle & live vertical meters on outer sides */}
        <CourtCanvas
          balls={balls}
          selectedBoxNum={selectedBoxNum}
          currentTeam={currentTeam}
          holdState={holdState}
          aimAngle={aimAngle}
          chargeRatio={chargeRatio}
          jackBall={jackBall}
          isJackThrow={gamePhase === 'JACK_THROW'}
          boxThrowsCount={boxThrowsCount}
          jackStarterTeam={jackStarterTeam}
          gamePhase={gamePhase}
          matchScoreResult={matchScoreResult}
          matchType={matchType}
          onSelectBox={handleSelectBox}
        />

        {/* Start Modal with 3 Game Mode & Opponent Selector */}
        {gamePhase === 'READY' && (
          <StartModal
            onStart={handleStartGame}
            jackStarterTeam={jackStarterTeam}
            matchType={matchType}
            onChangeMatchType={handleChangeMatchType}
            opponentMode={opponentMode}
            onChangeOpponentMode={handleChangeOpponentMode}
            playerTeam={playerTeam}
            onChangePlayerTeam={handleChangePlayerTeam}
          />
        )}
      </main>

      {/* End Result Score Display (Positioned BELOW the court so it NEVER hides court balls!) */}
      {gamePhase === 'END_RESULT' && matchScoreResult && (
        <GameOverModal
          score={matchScoreResult}
          onNextEnd={handleNextEnd}
          onResetMatch={handleResetGame}
          nextStarterInfo={nextStarterInfo}
          opponentMode={opponentMode}
          playerTeam={playerTeam}
        />
      )}

      {/* Bottom Controls & Box Selector Area (Active during play) */}
      {gamePhase !== 'END_RESULT' && (
        <footer className="w-full max-w-[1024px] flex flex-col lg:flex-row items-center justify-between gap-2 z-10">
          {/* Throwing Box Selector with match-specific throw limits & active boxes */}
          <BoxSelector
            selectedBoxNum={selectedBoxNum}
            currentTeam={currentTeam}
            holdState={holdState}
            boxThrowsCount={boxThrowsCount}
            matchType={matchType}
            onSelectBox={handleSelectBox}
          />

          {/* Operations Guide Banner & Context-Sensitive Throwing Deck */}
          <ControlsGuide
            currentTeam={currentTeam}
            holdState={holdState}
            chargeRatio={chargeRatio}
            selectedBoxNum={selectedBoxNum}
            boxThrowsCount={boxThrowsCount}
            aimAngle={aimAngle}
            matchType={matchType}
            opponentMode={opponentMode}
            playerTeam={playerTeam}
            isCpuTurn={isCpuTurn}
            isJackThrow={gamePhase === 'JACK_THROW'}
            onToggleHold={toggleBallHold}
            onPrevBox={handlePrevBox}
            onNextBox={handleNextBox}
            onAimLeft={handleAimLeft}
            onAimRight={handleAimRight}
            onAlignToJack={alignAimToJack}
            onStartCharge={startCharging}
            onReleaseCharge={releaseAndThrow}
            onDirectThrow={throwWithDirectPower}
          />
        </footer>
      )}
    </div>
  );
}
