export type Team = 'RED' | 'BLUE';

export type BallType = 'JACK' | 'RED' | 'BLUE';

export interface Ball {
  id: string;
  type: BallType;
  ballNumber?: number; // 1-6 for team balls
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  mass: number;
  isSettled: boolean;
  isOutOfBounds: boolean;
  invalidNotice?: string;
  colorHex: string;
  lightHex: string;
  darkHex: string;
}

export type ThrowingBoxNumber = 1 | 2 | 3 | 4 | 5 | 6;

export interface ThrowingBoxConfig {
  number: ThrowingBoxNumber;
  team: Team;
  label: string;
  x: number; // Center x in canvas coords
  y: number; // Center y in canvas coords
  width: number;
  height: number;
}

export type BallHoldState = 'IDLE' | 'HOLD' | 'CHARGING' | 'ROLLING';

export type GamePhase =
  | 'READY' // Start screen
  | 'JACK_THROW' // Initial Jack throw (by Red)
  | 'INITIAL_RED' // First red ball
  | 'INITIAL_BLUE' // First blue ball
  | 'IN_PLAY' // Boccia dynamic turn (furthest from Jack throws)
  | 'MEASURING' // Measuring tape animation
  | 'END_RESULT'; // Match result screen

export interface MatchScore {
  redPoints: number;
  bluePoints: number;
  totalRedScore: number;
  totalBlueScore: number;
  winningTeam: Team | 'DRAW' | null;
  scoringBallsCount: number;
  closestRedDist: number | null;
  closestBlueDist: number | null;
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  vy: number;
  text: string;
  color: string;
  alpha: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  alpha: number;
}
