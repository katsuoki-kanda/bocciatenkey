/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Ball,
  Team,
  ThrowingBoxNumber,
  BallHoldState,
  GamePhase,
  MatchScore,
} from './types';
import {
  COURT,
  BALL_COLORS,
  getThrowingBoxes,
  isInJackInvalidArea,
  pixelDistToMeters,
  updateBallPhysics,
} from './physics';
import { sound } from './sound';
import { CourtCanvas } from './components/CourtCanvas';
import { ScoreHeader } from './components/ScoreHeader';
import { BoxSelector } from './components/BoxSelector';
import { ControlsGuide } from './components/ControlsGuide';
import { StartModal } from './components/StartModal';
import { GameOverModal } from './components/GameOverModal';

// Threshold to distinguish a short press (toggle hold/release) from a long hold (charge power)
const SHORT_PRESS_THRESHOLD_MS = 320;

export default function App() {
  // Game state
  const [gamePhase, setGamePhase] = useState<GamePhase>('READY');
  const [currentTeam, setCurrentTeam] = useState<Team>('RED');
  const [selectedBoxNum, setSelectedBoxNum] = useState<ThrowingBoxNumber>(1);
  const [holdState, setHoldState] = useState<BallHoldState>('IDLE');

  // Aiming angle & power charge
  const [aimAngle, setAimAngle] = useState<number>(-Math.PI / 2); // straight forward
  const [chargeRatio, setChargeRatio] = useState<number>(0);

  // Balls on the court
  const [balls, setBalls] = useState<Ball[]>([]);
  const [jackBall, setJackBall] = useState<Ball | null>(null);

  // Remaining balls (6 each)
  const [redBallsLeft, setRedBallsLeft] = useState<number>(6);
  const [blueBallsLeft, setBlueBallsLeft] = useState<number>(6);

  // Scores
  const [redScore, setRedScore] = useState<number>(0);
  const [blueScore, setBlueScore] = useState<number>(0);
  const [matchScoreResult, setMatchScoreResult] = useState<MatchScore | null>(null);

  // Referee announcement banner
  const [refereeNotice, setRefereeNotice] = useState<string>('ゲームへようこそ！');

  // Refs for real-time 60fps physics & keyboard handling
  const ballsRef = useRef<Ball[]>([]);
  ballsRef.current = balls;

  const jackBallRef = useRef<Ball | null>(null);
  jackBallRef.current = jackBall;

  const currentTeamRef = useRef<Team>('RED');
  currentTeamRef.current = currentTeam;

  const selectedBoxRef = useRef<ThrowingBoxNumber>(1);
  selectedBoxRef.current = selectedBoxNum;

  const holdStateRef = useRef<BallHoldState>('IDLE');
  holdStateRef.current = holdState;

  const aimAngleRef = useRef<number>(-Math.PI / 2);
  aimAngleRef.current = aimAngle;

  const chargeRatioRef = useRef<number>(0);
  chargeRatioRef.current = chargeRatio;

  const gamePhaseRef = useRef<GamePhase>('READY');
  gamePhaseRef.current = gamePhase;

  const redBallsLeftRef = useRef<number>(6);
  redBallsLeftRef.current = redBallsLeft;

  const blueBallsLeftRef = useRef<number>(6);
  blueBallsLeftRef.current = blueBallsLeft;

  // Cumulative score refs to prevent duplicate score addition loops
  const totalRedScoreRef = useRef<number>(0);
  const totalBlueScoreRef = useRef<number>(0);

  // Guard flags to ensure evaluation happens strictly ONCE per end
  const isEndEvaluatedRef = useRef<boolean>(false);
  const measuringTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Key tracking & chords buffer
  const rawKeysDownRef = useRef<Set<string>>(new Set());
  const isBothPressedRef = useRef<boolean>(false);
  const bothPressStartRef = useRef<number | null>(null);
  const chargeStartRef = useRef<number | null>(null);

  // Precision aim locking & grace window refs to completely prevent course drift on chord press
  const singleKeyDownTimeRef = useRef<number | null>(null);
  const angleSnapshotBeforeChordRef = useRef<number | null>(null);
  const lockedAimAngleRef = useRef<number | null>(null);

  // Pending timer for single key box movement in IDLE state (to prevent accidental movement during chord skew)
  const pendingBoxTimerRef = useRef<{ timer: NodeJS.Timeout; dir: 1 | -1 } | null>(null);

  const ensureAudio = useCallback(() => {
    sound.init();
  }, []);

  // Select Throwing Box
  const handleSelectBox = useCallback((boxNum: ThrowingBoxNumber) => {
    ensureAudio();
    setSelectedBoxNum(boxNum);
    sound.playBoxSelect();
  }, [ensureAudio]);

  // Cycle Box for active player
  const cycleBox = useCallback((direction: 1 | -1) => {
    const isRed = currentTeamRef.current === 'RED';
    const allowed: ThrowingBoxNumber[] = isRed ? [1, 3, 5] : [2, 4, 6];
    const currIdx = allowed.indexOf(selectedBoxRef.current);
    let nextIdx = currIdx + direction;
    if (nextIdx < 0) nextIdx = allowed.length - 1;
    if (nextIdx >= allowed.length) nextIdx = 0;
    handleSelectBox(allowed[nextIdx]);
  }, [handleSelectBox]);

  // Cancel any pending single-key box movement
  const cancelPendingBoxTimer = useCallback(() => {
    if (pendingBoxTimerRef.current) {
      clearTimeout(pendingBoxTimerRef.current.timer);
      pendingBoxTimerRef.current = null;
    }
  }, []);

  // Toggle Ball Hold / Release:
  // - If IDLE -> sets HOLD (ボール保持 / 構え)
  // - If HOLD or CHARGING -> sets IDLE (ボールを離す / ボックス選択へ戻る)
  const toggleBallHold = useCallback(() => {
    ensureAudio();
    cancelPendingBoxTimer();
    if (holdStateRef.current === 'ROLLING') return;

    const isRed = currentTeamRef.current === 'RED';

    if (holdStateRef.current === 'HOLD' || holdStateRef.current === 'CHARGING') {
      // Release ball back to IDLE
      setHoldState('IDLE');
      holdStateRef.current = 'IDLE';
      setChargeRatio(0);
      chargeStartRef.current = null;
      singleKeyDownTimeRef.current = null;
      angleSnapshotBeforeChordRef.current = null;
      lockedAimAngleRef.current = null;
      sound.stopChargingSound();
      sound.playHoldToggle(false);
      setRefereeNotice(
        isRed
          ? '🔴 1P赤組 ボールを離しました (a / w でボックス選択可能、短押しで再保持)'
          : '🔵 2P青組 ボールを離しました (↓ / → でボックス選択可能、短押しで再保持)'
      );
    } else {
      // Hold ball
      setHoldState('HOLD');
      holdStateRef.current = 'HOLD';
      sound.playHoldToggle(true);
      setRefereeNotice(
        isRed
          ? '🔴 1P赤組 ボール保持中 (a / w で狙い、短押しで離す、同時長押しでスロー)'
          : '🔵 2P青組 ボール保持中 (↓ / → で狙い、短押しで離す、同時長押しでスロー)'
      );
    }
  }, [ensureAudio, cancelPendingBoxTimer]);

  // Aim adjustments
  const aimLeft = useCallback(() => {
    setAimAngle((prev) => Math.max(-Math.PI * 0.95, prev - 0.04));
  }, []);

  const aimRight = useCallback(() => {
    setAimAngle((prev) => Math.min(-Math.PI * 0.05, prev + 0.04));
  }, []);

  // Start Charging Power (e.g. from mouse/touch button or after long hold)
  const startCharging = useCallback(() => {
    ensureAudio();
    cancelPendingBoxTimer();
    if (holdStateRef.current === 'ROLLING') return;
    setHoldState('CHARGING');
    holdStateRef.current = 'CHARGING';
    lockedAimAngleRef.current = aimAngleRef.current;
    chargeStartRef.current = performance.now();
    sound.startChargingSound();
  }, [ensureAudio, cancelPendingBoxTimer]);

  // Release and Throw Ball with calibrated non-linear power curve
  const releaseAndThrow = useCallback(() => {
    ensureAudio();
    cancelPendingBoxTimer();
    sound.stopChargingSound();

    const rawRatio = Math.max(0.03, chargeRatioRef.current);
    // Non-linear power curve: requires longer hold to reach far distances
    const powerCurve = Math.pow(rawRatio, 1.55);
    const speed =
      COURT.MIN_LAUNCH_SPEED +
      powerCurve * (COURT.MAX_LAUNCH_SPEED - COURT.MIN_LAUNCH_SPEED);

    // Strictly use the locked aim angle to prevent any course drift during key release
    const angle = lockedAimAngleRef.current ?? aimAngleRef.current;

    sound.playThrow(powerCurve);

    // Launch position: from the front edge of the active throwing box
    const throwingBoxes = getThrowingBoxes();
    const activeBox =
      throwingBoxes.find((b) => b.number === selectedBoxRef.current) ||
      throwingBoxes[0];
    const startX = activeBox.x;
    const startY = COURT.BOTTOM - COURT.BALL_RADIUS - 4; // Right at throwing line

    const phase = gamePhaseRef.current;
    let thrownBall: Ball;

    if (phase === 'JACK_THROW') {
      // Jack ball (White)
      thrownBall = {
        id: `jack-${Date.now()}`,
        type: 'JACK',
        x: startX,
        y: startY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: COURT.BALL_RADIUS,
        mass: 0.95,
        isSettled: false,
        isOutOfBounds: false,
        colorHex: BALL_COLORS.JACK.hex,
        lightHex: BALL_COLORS.JACK.light,
        darkHex: BALL_COLORS.JACK.dark,
      };
      setJackBall(thrownBall);
      ballsRef.current = [...ballsRef.current, thrownBall];
      setBalls([...ballsRef.current]);
    } else {
      // Regular ball (Red or Blue)
      const team = currentTeamRef.current;
      const num =
        team === 'RED'
          ? 7 - redBallsLeftRef.current
          : 7 - blueBallsLeftRef.current;
      const ballColors = BALL_COLORS[team];

      thrownBall = {
        id: `${team}-${num}-${Date.now()}`,
        type: team,
        ballNumber: num,
        x: startX,
        y: startY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: COURT.BALL_RADIUS,
        mass: 1.0,
        isSettled: false,
        isOutOfBounds: false,
        colorHex: ballColors.hex,
        lightHex: ballColors.light,
        darkHex: ballColors.dark,
      };

      if (team === 'RED') {
        setRedBallsLeft((prev) => Math.max(0, prev - 1));
      } else {
        setBlueBallsLeft((prev) => Math.max(0, prev - 1));
      }

      ballsRef.current = [...ballsRef.current, thrownBall];
      setBalls([...ballsRef.current]);
    }

    setHoldState('ROLLING');
    holdStateRef.current = 'ROLLING';
    setChargeRatio(0);
    chargeStartRef.current = null;
    bothPressStartRef.current = null;
    isBothPressedRef.current = false;
    singleKeyDownTimeRef.current = null;
    angleSnapshotBeforeChordRef.current = null;
    lockedAimAngleRef.current = null;
  }, [ensureAudio, cancelPendingBoxTimer]);

  // Evaluate scores at end of Boccia end - strictly executed ONCE
  const evaluateEndResult = useCallback(() => {
    if (isEndEvaluatedRef.current) return;
    isEndEvaluatedRef.current = true;

    if (measuringTimerRef.current) {
      clearTimeout(measuringTimerRef.current);
      measuringTimerRef.current = null;
    }

    setHoldState('IDLE');
    holdStateRef.current = 'IDLE';

    const currentJack = jackBallRef.current;
    const currentBalls = ballsRef.current.filter(
      (b) => b.type !== 'JACK' && !b.isOutOfBounds
    );

    const prevRed = totalRedScoreRef.current;
    const prevBlue = totalBlueScoreRef.current;

    if (!currentJack || currentBalls.length === 0) {
      setMatchScoreResult({
        redPoints: 0,
        bluePoints: 0,
        totalRedScore: prevRed,
        totalBlueScore: prevBlue,
        winningTeam: 'DRAW',
        scoringBallsCount: 0,
        closestRedDist: null,
        closestBlueDist: null,
      });
      setGamePhase('END_RESULT');
      sound.playFanfare();
      return;
    }

    const redDists: number[] = [];
    const blueDists: number[] = [];

    currentBalls.forEach((b) => {
      const d = Math.hypot(b.x - currentJack.x, b.y - currentJack.y);
      if (b.type === 'RED') redDists.push(d);
      else if (b.type === 'BLUE') blueDists.push(d);
    });

    redDists.sort((a, b) => a - b);
    blueDists.sort((a, b) => a - b);

    const minRed = redDists.length > 0 ? redDists[0] : Infinity;
    const minBlue = blueDists.length > 0 ? blueDists[0] : Infinity;

    let redPts = 0;
    let bluePts = 0;
    let winner: Team | 'DRAW' = 'DRAW';

    if (minRed < minBlue) {
      winner = 'RED';
      redPts = redDists.filter((d) => d < minBlue).length;
    } else if (minBlue < minRed) {
      winner = 'BLUE';
      bluePts = blueDists.filter((d) => d < minRed).length;
    }

    const newRedTotal = prevRed + redPts;
    const newBlueTotal = prevBlue + bluePts;
    totalRedScoreRef.current = newRedTotal;
    totalBlueScoreRef.current = newBlueTotal;

    setRedScore(newRedTotal);
    setBlueScore(newBlueTotal);

    setMatchScoreResult({
      redPoints: redPts,
      bluePoints: bluePts,
      totalRedScore: newRedTotal,
      totalBlueScore: newBlueTotal,
      winningTeam: winner,
      scoringBallsCount: Math.max(redPts, bluePts),
      closestRedDist: minRed < Infinity ? pixelDistToMeters(minRed) : null,
      closestBlueDist: minBlue < Infinity ? pixelDistToMeters(minBlue) : null,
    });

    setGamePhase('END_RESULT');
    sound.playFanfare();
  }, []);

  // Turn settled logic
  const handleTurnSettled = useCallback(() => {
    const phase = gamePhaseRef.current;
    const jack = jackBallRef.current;

    // Reset hold state to IDLE upon settlement
    setHoldState('IDLE');
    holdStateRef.current = 'IDLE';

    if (phase === 'JACK_THROW') {
      if (jack) {
        if (isInJackInvalidArea(jack.x, jack.y) || jack.isOutOfBounds) {
          jack.x = COURT.CROSS_X;
          jack.y = COURT.CROSS_Y;
          jack.vx = 0;
          jack.vy = 0;
          jack.isSettled = true;
          jack.isOutOfBounds = false;
          setRefereeNotice(
            '⚠️ ジャックが無効エリアのため、中央クロスに再配置されました！'
          );
        } else {
          setRefereeNotice(
            '⚪ ジャック配置完了！ 1P赤組の第1投(赤ボール)です。'
          );
        }
      }

      setGamePhase('INITIAL_RED');
      setCurrentTeam('RED');
      setSelectedBoxNum(1);
      sound.playTurnSwitch();
      return;
    }

    if (phase === 'INITIAL_RED') {
      setGamePhase('INITIAL_BLUE');
      setCurrentTeam('BLUE');
      setSelectedBoxNum(2);
      setRefereeNotice('🔵 2P青組の第1投(青ボール)です。白球に近づけましょう！');
      sound.playTurnSwitch();
      return;
    }

    // Subsequent Boccia turns: team FURTHEST from Jack throws next
    const rLeft = redBallsLeftRef.current;
    const bLeft = blueBallsLeftRef.current;

    if (rLeft === 0 && bLeft === 0) {
      if (measuringTimerRef.current || isEndEvaluatedRef.current) return;
      setRefereeNotice('🏁 全球投球完了！ 審判員による計測を行います。');
      setGamePhase('MEASURING');
      measuringTimerRef.current = setTimeout(() => {
        evaluateEndResult();
      }, 1100);
      return;
    }

    if (rLeft === 0) {
      setCurrentTeam('BLUE');
      setSelectedBoxNum((prev) => ([2, 4, 6].includes(prev) ? prev : 2));
      setGamePhase('IN_PLAY');
      setRefereeNotice(`🔵 赤組球切れ！ 青組の連続投球です (残り${bLeft}球)`);
      sound.playTurnSwitch();
      return;
    }

    if (bLeft === 0) {
      setCurrentTeam('RED');
      setSelectedBoxNum((prev) => ([1, 3, 5].includes(prev) ? prev : 1));
      setGamePhase('IN_PLAY');
      setRefereeNotice(`🔴 青組球切れ！ 赤組の連続投球です (残り${rLeft}球)`);
      sound.playTurnSwitch();
      return;
    }

    if (jack) {
      const activeBalls = ballsRef.current.filter(
        (b) => b.type !== 'JACK' && !b.isOutOfBounds
      );
      let minRedDist = Infinity;
      let minBlueDist = Infinity;

      activeBalls.forEach((b) => {
        const d = Math.hypot(b.x - jack.x, b.y - jack.y);
        if (b.type === 'RED' && d < minRedDist) minRedDist = d;
        if (b.type === 'BLUE' && d < minBlueDist) minBlueDist = d;
      });

      let nextTeam: Team = 'RED';
      if (minRedDist < minBlueDist) {
        nextTeam = 'BLUE';
        setRefereeNotice(
          `🔵 青組の番 (距離: ${pixelDistToMeters(minBlueDist)}m ＞ 赤: ${pixelDistToMeters(minRedDist)}m)`
        );
      } else {
        nextTeam = 'RED';
        setRefereeNotice(
          `🔴 赤組の番 (距離: ${pixelDistToMeters(minRedDist)}m ＞ 青: ${pixelDistToMeters(minBlueDist)}m)`
        );
      }

      setCurrentTeam(nextTeam);
      const allowed: ThrowingBoxNumber[] =
        nextTeam === 'RED' ? [1, 3, 5] : [2, 4, 6];
      setSelectedBoxNum((prev) => (allowed.includes(prev) ? prev : allowed[0]));
      setGamePhase('IN_PLAY');
      sound.playTurnSwitch();
    }
  }, [evaluateEndResult]);

  // Start new match / end
  const handleStartGame = useCallback(() => {
    ensureAudio();
    cancelPendingBoxTimer();

    if (measuringTimerRef.current) {
      clearTimeout(measuringTimerRef.current);
      measuringTimerRef.current = null;
    }
    isEndEvaluatedRef.current = false;

    sound.playWhistle();

    setGamePhase('JACK_THROW');
    setCurrentTeam('RED');
    setSelectedBoxNum(1);
    setHoldState('IDLE');
    holdStateRef.current = 'IDLE';
    setAimAngle(-Math.PI / 2);
    setChargeRatio(0);
    singleKeyDownTimeRef.current = null;
    angleSnapshotBeforeChordRef.current = null;
    lockedAimAngleRef.current = null;
    ballsRef.current = [];
    setBalls([]);
    setJackBall(null);
    setRedBallsLeft(6);
    setBlueBallsLeft(6);
    setMatchScoreResult(null);
    setRefereeNotice(
      '【第1投】赤チームはジャックボール(白)をVライン奥へ投球してください！'
    );
  }, [ensureAudio, cancelPendingBoxTimer]);

  // Reset entire match
  const handleResetGame = useCallback(() => {
    ensureAudio();
    totalRedScoreRef.current = 0;
    totalBlueScoreRef.current = 0;
    setRedScore(0);
    setBlueScore(0);
    handleStartGame();
  }, [ensureAudio, handleStartGame]);

  // Manual end match button
  const handleFinishMatch = useCallback(() => {
    ensureAudio();
    if (gamePhaseRef.current === 'END_RESULT') return;
    setHoldState('IDLE');
    holdStateRef.current = 'IDLE';
    evaluateEndResult();
  }, [ensureAudio, evaluateEndResult]);

  // Main 60fps game loop
  useEffect(() => {
    let animationFrameId: number;

    const tick = () => {
      const keys = rawKeysDownRef.current;
      const isRedTurn = currentTeamRef.current === 'RED';

      const isRedKey1 = keys.has('KeyA') || keys.has('Keya');
      const isRedKey2 = keys.has('KeyW') || keys.has('Keyw');
      const isBlueKey1 = keys.has('ArrowDown');
      const isBlueKey2 = keys.has('ArrowRight');

      const isCurrentKey1 = isRedTurn ? isRedKey1 : isBlueKey1;
      const isCurrentKey2 = isRedTurn ? isRedKey2 : isBlueKey2;

      // 1. Check if both keys are held long enough (>= SHORT_PRESS_THRESHOLD_MS) to start charging
      if (isBothPressedRef.current && bothPressStartRef.current !== null) {
        const pressDuration = performance.now() - bothPressStartRef.current;
        if (pressDuration >= SHORT_PRESS_THRESHOLD_MS) {
          // Both keys have been held long: enter CHARGING state!
          if (holdStateRef.current !== 'CHARGING') {
            setHoldState('CHARGING');
            holdStateRef.current = 'CHARGING';
            lockedAimAngleRef.current = aimAngleRef.current;
            chargeStartRef.current = performance.now();
            sound.startChargingSound();
          }

          if (chargeStartRef.current !== null) {
            const chargeElapsed = performance.now() - chargeStartRef.current;
            const ratio = Math.min(1.0, chargeElapsed / COURT.MAX_CHARGE_DURATION_MS);
            setChargeRatio(ratio);
            sound.updateChargingSound(ratio);
          }
        }
      }

      // 2. Smooth Aim turning while holding single key in HOLD state
      // (With 120ms grace window to prevent any course drift when both keys are pressed!)
      const isAiming = holdStateRef.current === 'HOLD';
      const isChordOrCharging =
        isBothPressedRef.current ||
        holdStateRef.current === 'CHARGING' ||
        holdStateRef.current === 'ROLLING';

      if (isAiming && !isChordOrCharging) {
        const onlyOneKey =
          (isCurrentKey1 && !isCurrentKey2) || (isCurrentKey2 && !isCurrentKey1);

        if (onlyOneKey && singleKeyDownTimeRef.current !== null) {
          const singleKeyDuration = performance.now() - singleKeyDownTimeRef.current;

          // Only rotate aim after single key has been held > 120ms!
          // This ensures that when the user presses both keys (with ~20-80ms finger skew), the aim NEVER drifts!
          if (singleKeyDuration > 120) {
            if (isCurrentKey1) {
              // Key 1 turns left
              setAimAngle((prev) => Math.max(-Math.PI * 0.95, prev - 0.022));
            }
            if (isCurrentKey2) {
              // Key 2 turns right
              setAimAngle((prev) => Math.min(-Math.PI * 0.05, prev + 0.022));
            }
            // Keep snapshot updated as the aim intentionally changes
            angleSnapshotBeforeChordRef.current = aimAngleRef.current;
          }
        }
      }

      // 3. Physics update while balls are rolling
      if (holdStateRef.current === 'ROLLING') {
        const currentBalls = ballsRef.current;
        updateBallPhysics(currentBalls);

        // Keep React state in sync
        setBalls([...currentBalls]);

        const allSettled = currentBalls.every(
          (b) => b.isSettled || b.isOutOfBounds
        );
        if (allSettled) {
          setHoldState('IDLE');
          holdStateRef.current = 'IDLE';
          handleTurnSettled();
        }
      }

      animationFrameId = requestAnimationFrame(tick);
    };

    animationFrameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animationFrameId);
  }, [handleTurnSettled]);

  // Dual-Player Keyboard Handling (Red: a / w, Blue: ↓ / →)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        ['ArrowDown', 'ArrowRight', 'ArrowUp', 'ArrowLeft', 'Space'].includes(
          e.code
        ) ||
        ['ArrowDown', 'ArrowRight'].includes(e.key)
      ) {
        e.preventDefault();
      }

      if (e.repeat) return;
      ensureAudio();

      rawKeysDownRef.current.add(e.code);

      const hasRedBoth =
        (rawKeysDownRef.current.has('KeyA') ||
          rawKeysDownRef.current.has('Keya')) &&
        (rawKeysDownRef.current.has('KeyW') ||
          rawKeysDownRef.current.has('Keyw'));
      const hasBlueBoth =
        rawKeysDownRef.current.has('ArrowDown') &&
        rawKeysDownRef.current.has('ArrowRight');

      // Start/Restart shortcut from modal
      if (
        gamePhaseRef.current === 'READY' ||
        gamePhaseRef.current === 'END_RESULT'
      ) {
        if (hasRedBoth || hasBlueBoth) {
          handleStartGame();
        }
        return;
      }

      if (holdStateRef.current === 'ROLLING') return;

      const isRedTurn = currentTeamRef.current === 'RED';
      const isRedKey1 = e.code === 'KeyA' || e.key.toLowerCase() === 'a';
      const isRedKey2 = e.code === 'KeyW' || e.key.toLowerCase() === 'w';
      const isBlueKey1 = e.code === 'ArrowDown' || e.key === 'ArrowDown';
      const isBlueKey2 = e.code === 'ArrowRight' || e.key === 'ArrowRight';

      const isCurrentKey1 = isRedTurn ? isRedKey1 : isBlueKey1;
      const isCurrentKey2 = isRedTurn ? isRedKey2 : isBlueKey2;

      if (!isCurrentKey1 && !isCurrentKey2) return;

      const keys = rawKeysDownRef.current;
      const activeKey1Down = isRedTurn
        ? keys.has('KeyA') || keys.has('Keya')
        : keys.has('ArrowDown');
      const activeKey2Down = isRedTurn
        ? keys.has('KeyW') || keys.has('Keyw')
        : keys.has('ArrowRight');

      // Check if BOTH keys are now pressed
      if (activeKey1Down && activeKey2Down) {
        cancelPendingBoxTimer();

        // Restore snapshot angle if there was any tiny drift during single key onset
        if (angleSnapshotBeforeChordRef.current !== null) {
          setAimAngle(angleSnapshotBeforeChordRef.current);
          aimAngleRef.current = angleSnapshotBeforeChordRef.current;
        }
        lockedAimAngleRef.current = aimAngleRef.current;
        singleKeyDownTimeRef.current = null;

        if (!isBothPressedRef.current) {
          isBothPressedRef.current = true;
          bothPressStartRef.current = performance.now();
        }
      } else {
        // Only ONE key was pressed:
        if (holdStateRef.current === 'HOLD') {
          // If first single key pressed, snapshot current angle and record time
          if (singleKeyDownTimeRef.current === null) {
            angleSnapshotBeforeChordRef.current = aimAngleRef.current;
            singleKeyDownTimeRef.current = performance.now();
          }
        } else if (holdStateRef.current === 'IDLE') {
          cancelPendingBoxTimer();
          const dir = isCurrentKey1 ? -1 : 1;
          const timer = setTimeout(() => {
            cycleBox(dir);
            pendingBoxTimerRef.current = null;
          }, 140);
          pendingBoxTimerRef.current = { timer, dir };
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (
        ['ArrowDown', 'ArrowRight', 'ArrowUp', 'ArrowLeft', 'Space'].includes(
          e.code
        ) ||
        ['ArrowDown', 'ArrowRight'].includes(e.key)
      ) {
        e.preventDefault();
      }

      rawKeysDownRef.current.delete(e.code);

      if (
        gamePhaseRef.current === 'READY' ||
        gamePhaseRef.current === 'END_RESULT'
      ) {
        return;
      }

      const isRedTurn = currentTeamRef.current === 'RED';
      const isRedKey1 = e.code === 'KeyA' || e.key.toLowerCase() === 'a';
      const isRedKey2 = e.code === 'KeyW' || e.key.toLowerCase() === 'w';
      const isBlueKey1 = e.code === 'ArrowDown' || e.key === 'ArrowDown';
      const isBlueKey2 = e.code === 'ArrowRight' || e.key === 'ArrowRight';

      const isCurrentKey1 = isRedTurn ? isRedKey1 : isBlueKey1;
      const isCurrentKey2 = isRedTurn ? isRedKey2 : isBlueKey2;

      if (!isCurrentKey1 && !isCurrentKey2) return;

      const wasBoth = isBothPressedRef.current;
      const pressDuration = bothPressStartRef.current
        ? performance.now() - bothPressStartRef.current
        : 0;

      if (wasBoth) {
        cancelPendingBoxTimer();
        isBothPressedRef.current = false;
        bothPressStartRef.current = null;
        singleKeyDownTimeRef.current = null;

        if (holdStateRef.current === 'CHARGING') {
          // Release and Throw!
          releaseAndThrow();
        } else if (pressDuration < SHORT_PRESS_THRESHOLD_MS) {
          // Short simultaneous press (< 320ms): Toggle ball hold/release!
          toggleBallHold();
        } else {
          // Held longer than 320ms: throw with charged power
          releaseAndThrow();
        }
      } else {
        // Single key was released
        if (holdStateRef.current === 'HOLD' && singleKeyDownTimeRef.current !== null) {
          const duration = performance.now() - singleKeyDownTimeRef.current;
          // If very quick tap (< 120ms) with no second key, apply a small micro-step nudge
          if (duration < 120 && !isBothPressedRef.current) {
            if (isCurrentKey1) setAimAngle((prev) => Math.max(-Math.PI * 0.95, prev - 0.015));
            if (isCurrentKey2) setAimAngle((prev) => Math.min(-Math.PI * 0.05, prev + 0.015));
          }
          singleKeyDownTimeRef.current = null;
        }

        if (pendingBoxTimerRef.current && holdStateRef.current === 'IDLE') {
          const dir = pendingBoxTimerRef.current.dir;
          cancelPendingBoxTimer();
          cycleBox(dir);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      cancelPendingBoxTimer();
    };
  }, [
    ensureAudio,
    handleStartGame,
    cycleBox,
    cancelPendingBoxTimer,
    toggleBallHold,
    releaseAndThrow,
  ]);

  return (
    <div className="w-screen min-h-screen flex flex-col justify-between items-center bg-slate-950 text-slate-100 overflow-x-hidden p-2 sm:p-4 select-none">
      {/* Top Header */}
      <ScoreHeader
        currentTeam={currentTeam}
        gamePhase={gamePhase}
        redScore={redScore}
        blueScore={blueScore}
        redBallsLeft={redBallsLeft}
        blueBallsLeft={blueBallsLeft}
        selectedBoxNum={selectedBoxNum}
        onFinishMatch={handleFinishMatch}
        onResetGame={handleResetGame}
      />

      {/* Main Game Court Container */}
      <main className="relative w-full max-w-[1024px] my-1 flex flex-col items-center">
        {/* Referee Notice Banner */}
        <div className="w-full flex justify-between items-center px-4 py-1.5 mb-1 bg-slate-900/90 rounded-xl border border-slate-800 text-xs shadow-md">
          <div className="flex items-center space-x-2">
            <span className="text-amber-400">📢</span>
            <span className="font-semibold text-slate-200">{refereeNotice}</span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={handleFinishMatch}
              className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 transition-all cursor-pointer"
            >
              🏁 対戦終了
            </button>
            <button
              type="button"
              onClick={handleResetGame}
              className="text-[11px] font-semibold px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 border border-white/10 hover:bg-slate-700 transition-all cursor-pointer"
            >
              🔄 リセット
            </button>
          </div>
        </div>

        {/* Court Canvas */}
        <CourtCanvas
          balls={balls}
          selectedBoxNum={selectedBoxNum}
          currentTeam={currentTeam}
          holdState={holdState}
          aimAngle={aimAngle}
          chargeRatio={chargeRatio}
          jackBall={jackBall}
          isJackThrow={gamePhase === 'JACK_THROW'}
        />

        {/* Start Modal */}
        {gamePhase === 'READY' && <StartModal onStart={handleStartGame} />}

        {/* Game Over Modal */}
        {gamePhase === 'END_RESULT' && matchScoreResult && (
          <GameOverModal score={matchScoreResult} onRestart={handleStartGame} />
        )}
      </main>

      {/* Bottom Controls & Box Selector Area */}
      <footer className="w-full max-w-[1024px] flex flex-col lg:flex-row items-center justify-between gap-2 z-10">
        {/* Throwing Box Selector (Replaces color palette in slingpair2b) */}
        <BoxSelector
          selectedBoxNum={selectedBoxNum}
          currentTeam={currentTeam}
          holdState={holdState}
          onSelectBox={handleSelectBox}
        />

        {/* Operations Guide Banner & Action controls */}
        <ControlsGuide
          currentTeam={currentTeam}
          holdState={holdState}
          chargeRatio={chargeRatio}
          isJackThrow={gamePhase === 'JACK_THROW'}
          onToggleHold={toggleBallHold}
          onAimLeft={aimLeft}
          onAimRight={aimRight}
          onStartCharge={startCharging}
          onReleaseCharge={releaseAndThrow}
        />
      </footer>
    </div>
  );
}
