import React from 'react';
import { BallHoldState, Team } from '../types';

interface ControlsGuideProps {
  currentTeam: Team;
  holdState: BallHoldState;
  chargeRatio: number;
  isJackThrow?: boolean;
  onToggleHold: () => void;
  onAimLeft: () => void;
  onAimRight: () => void;
  onStartCharge: () => void;
  onReleaseCharge: () => void;
}

export const ControlsGuide: React.FC<ControlsGuideProps> = ({
  currentTeam,
  holdState,
  chargeRatio,
  isJackThrow = false,
  onToggleHold,
  onAimLeft,
  onAimRight,
  onStartCharge,
  onReleaseCharge,
}) => {
  const isRed = currentTeam === 'RED';
  const themeBorder = isJackThrow
    ? 'border-white/60 shadow-white/10'
    : isRed
    ? 'border-red-500/50'
    : 'border-blue-500/50';
  const themeText = isJackThrow ? 'text-white' : isRed ? 'text-red-400' : 'text-blue-400';

  const key1 = isRed ? 'a' : '↓';
  const key2 = isRed ? 'w' : '→';
  const bothKeys = isRed ? 'a + w' : '↓ + →';

  const ballLabel = isJackThrow ? '⚪ ジャック(白)' : 'ボール';

  return (
    <div className="w-full max-w-[1024px] flex flex-col md:flex-row items-center justify-between gap-3 px-2 py-1">
      {/* Operation Guide Banner (slingpair2b turnGuideBanner style) */}
      <div
        className={`glass-panel rounded-xl px-4 py-2.5 border ${themeBorder} flex flex-col sm:flex-row items-center justify-between gap-3 w-full flex-1 shadow-lg`}
      >
        <div className="flex items-start space-x-2.5">
          <span className="text-xl mt-0.5">{isJackThrow ? '⚪' : '🎮'}</span>
          <div className="flex flex-col text-[11px] leading-tight">
            <div className="flex items-center space-x-2 mb-1">
              <strong className={`${themeText} font-bold text-xs`}>
                {isJackThrow
                  ? '【Player 1: 赤組 (ジャックボール投球: 白)】'
                  : `【${isRed ? 'Player 1: 赤組' : 'Player 2: 青組'} のキー操作】`}
              </strong>
              <span className="bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded text-[10px] font-mono border border-white/10">
                {holdState === 'IDLE'
                  ? 'ボックス選択中'
                  : holdState === 'HOLD'
                  ? `${ballLabel}保持中・方向調整 (短押しで離す)`
                  : holdState === 'CHARGING'
                  ? 'パワーチャージ中！'
                  : 'ボール転がり中'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-slate-300">
              <div className="flex items-center space-x-1">
                <code className="bg-slate-800 px-1 py-0.5 rounded text-amber-300 font-mono text-[10px]">
                  {bothKeys} 短押し
                </code>
                <span>：{ballLabel}保持 / 離して箱選択へ</span>
              </div>
              <div className="flex items-center space-x-1">
                <code className="bg-slate-800 px-1 py-0.5 rounded text-cyan-300 font-mono text-[10px]">
                  {key1} または {key2}
                </code>
                <span>：方向選択 (待機時は箱)</span>
              </div>
              <div className="flex items-center space-x-1">
                <code className="bg-slate-800 px-1 py-0.5 rounded text-emerald-400 font-mono text-[10px]">
                  {bothKeys} 同時長押し
                </code>
                <span>：スロー (長いほど強勢)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Real-time interactive control buttons for Touch / Mouse users */}
        <div className="flex items-center space-x-2">
          {/* Hold / Release button */}
          <button
            type="button"
            disabled={holdState === 'ROLLING'}
            onClick={onToggleHold}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
              holdState === 'HOLD' || holdState === 'CHARGING'
                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/30'
                : 'glass-button text-slate-200 border-white/20 hover:text-white'
            }`}
            title={`${bothKeys} の短い同時押し`}
          >
            {holdState === 'HOLD' || holdState === 'CHARGING'
              ? `${ballLabel}離す (${bothKeys})`
              : `${ballLabel}保持 (${bothKeys})`}
          </button>

          {/* Aim Left */}
          <button
            type="button"
            disabled={holdState === 'IDLE' || holdState === 'ROLLING'}
            onClick={onAimLeft}
            className="glass-button px-2.5 py-1.5 rounded-lg text-xs font-bold text-slate-200 border border-white/20 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
            title={`${key1}キー`}
          >
            ◀ 左 ({key1})
          </button>

          {/* Aim Right */}
          <button
            type="button"
            disabled={holdState === 'IDLE' || holdState === 'ROLLING'}
            onClick={onAimRight}
            className="glass-button px-2.5 py-1.5 rounded-lg text-xs font-bold text-slate-200 border border-white/20 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
            title={`${key2}キー`}
          >
            右 ({key2}) ▶
          </button>

          {/* Hold to throw button */}
          <div className="relative">
            <button
              type="button"
              disabled={holdState === 'IDLE' || holdState === 'ROLLING'}
              onMouseDown={onStartCharge}
              onMouseUp={onReleaseCharge}
              onMouseLeave={() => {
                if (holdState === 'CHARGING') onReleaseCharge();
              }}
              onTouchStart={(e) => {
                e.preventDefault();
                onStartCharge();
              }}
              onTouchEnd={(e) => {
                e.preventDefault();
                onReleaseCharge();
              }}
              className={`px-4 py-1.5 rounded-lg text-xs font-black tracking-wide transition-all border cursor-pointer select-none ${
                holdState === 'CHARGING'
                  ? 'bg-gradient-to-r from-red-500 to-amber-500 text-white border-white scale-105 shadow-lg shadow-red-500/50'
                  : 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 border-emerald-400 hover:brightness-110'
              } disabled:opacity-30 disabled:cursor-not-allowed`}
              title={`${bothKeys} を長押し保持してスロー`}
            >
              {holdState === 'CHARGING'
                ? `投球蓄電 (${Math.round(chargeRatio * 100)}%)`
                : `スロー長押し (${bothKeys})`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
