import React from 'react';
import { ThrowingBoxNumber, Team, BallHoldState } from '../types';

interface BoxSelectorProps {
  selectedBoxNum: ThrowingBoxNumber;
  currentTeam: Team;
  holdState: BallHoldState;
  onSelectBox: (boxNum: ThrowingBoxNumber) => void;
}

export const BoxSelector: React.FC<BoxSelectorProps> = ({
  selectedBoxNum,
  currentTeam,
  holdState,
  onSelectBox,
}) => {
  const isRedTurn = currentTeam === 'RED';
  const allowedBoxes: ThrowingBoxNumber[] = isRedTurn ? [1, 3, 5] : [2, 4, 6];
  const allBoxes: { num: ThrowingBoxNumber; label: string; team: Team }[] = [
    { num: 1, label: '①', team: 'RED' },
    { num: 2, label: '②', team: 'BLUE' },
    { num: 3, label: '③', team: 'RED' },
    { num: 4, label: '④', team: 'BLUE' },
    { num: 5, label: '⑤', team: 'RED' },
    { num: 6, label: '⑥', team: 'BLUE' },
  ];

  const keyHint = isRedTurn ? 'a / w' : '↓ / →';

  return (
    <div className="glass-panel rounded-2xl px-4 py-2.5 flex flex-col items-center gap-1.5 border border-white/10 shadow-2xl pointer-events-auto">
      <div className="flex items-center justify-between w-full text-[10px] font-extrabold uppercase tracking-widest text-slate-400">
        <span>スローイングボックス選択</span>
        <span className="text-[9px] text-amber-300 font-mono">
          {isRedTurn ? '赤(1P): ① ③ ⑤' : '青(2P): ② ④ ⑥'}
        </span>
      </div>

      <div className="flex items-center space-x-2">
        {allBoxes.map((box) => {
          const isSelected = selectedBoxNum === box.num;
          const isAllowed = allowedBoxes.includes(box.num);
          const isRed = box.team === 'RED';

          return (
            <button
              key={box.num}
              type="button"
              disabled={!isAllowed || holdState === 'ROLLING'}
              onClick={() => onSelectBox(box.num)}
              className={`box-btn w-9 h-9 sm:w-10 sm:h-10 rounded-xl font-black font-orbitron text-sm relative flex flex-col items-center justify-center border-2 transition-all cursor-pointer ${
                isSelected
                  ? isRed
                    ? 'active bg-red-600 text-white border-white shadow-lg shadow-red-500/50'
                    : 'active bg-blue-600 text-white border-white shadow-lg shadow-blue-500/50'
                  : isAllowed
                  ? isRed
                    ? 'bg-red-950/70 border-red-500/60 text-red-300 hover:bg-red-900/80 hover:border-red-400'
                    : 'bg-blue-950/70 border-blue-500/60 text-blue-300 hover:bg-blue-900/80 hover:border-blue-400'
                  : 'bg-slate-900/60 border-slate-800 text-slate-600 opacity-40 cursor-not-allowed'
              }`}
              title={`ボックス ${box.label} (${box.team === 'RED' ? '赤' : '青'})`}
            >
              <span>{box.label}</span>
              <span className="text-[7px] -mt-1 font-sans">
                {isRed ? '赤' : '青'}
              </span>
            </button>
          );
        })}
      </div>

      <div className="text-[9px] text-slate-400 flex items-center space-x-1.5 mt-0.5">
        <span className="bg-slate-800 px-1 py-0.5 rounded text-amber-300 font-mono font-bold">
          {keyHint}
        </span>
        <span>キーでもボックスを切り替え可能 (待機中)</span>
      </div>
    </div>
  );
};
