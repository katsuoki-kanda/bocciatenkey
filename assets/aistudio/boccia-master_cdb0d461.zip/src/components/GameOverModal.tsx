import React from 'react';
import { MatchScore } from '../types';

interface GameOverModalProps {
  score: MatchScore;
  onRestart: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({ score, onRestart }) => {
  const isRedWinner = score.winningTeam === 'RED';
  const isBlueWinner = score.winningTeam === 'BLUE';

  return (
    <div className="absolute inset-0 bg-slate-950/92 backdrop-blur-lg flex flex-col justify-center items-center text-center p-6 z-50">
      <div
        className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-3 shadow-lg animate-bounce border ${
          isRedWinner
            ? 'bg-red-500/20 border-red-500/50 shadow-red-500/20'
            : isBlueWinner
            ? 'bg-blue-500/20 border-blue-500/50 shadow-blue-500/20'
            : 'bg-amber-500/20 border-amber-500/50 shadow-amber-500/20'
        }`}
      >
        <span className="text-3xl">🏆</span>
      </div>

      <h2
        className={`text-3xl md:text-4xl font-black font-orbitron mb-1 tracking-wide ${
          isRedWinner ? 'text-red-400' : isBlueWinner ? 'text-blue-400' : 'text-amber-400'
        }`}
      >
        {isRedWinner
          ? 'RED TEAM (1P 赤組) の勝利！'
          : isBlueWinner
          ? 'BLUE TEAM (2P 青組) の勝利！'
          : '同点！ 引き分け (DRAW)'}
      </h2>

      <p className="text-xs text-slate-300 mb-5">
        {isRedWinner
          ? `赤チームが +${score.redPoints} 点を獲得しました！`
          : isBlueWinner
          ? `青チームが +${score.bluePoints} 点を獲得しました！`
          : '両者互角のスーパーショットでした！'}
      </p>

      {/* Score panel */}
      <div className="glass-panel rounded-2xl p-5 mb-6 w-full max-w-md space-y-4 border border-white/10 shadow-2xl">
        <div className="flex justify-around items-center">
          {/* Red summary */}
          <div className="flex flex-col items-center">
            <span className="text-xs font-bold text-red-400">1P 赤組 (a / w)</span>
            <span className="text-4xl font-black font-orbitron text-red-300">
              {score.totalRedScore}
            </span>
            <span className="text-[10px] text-slate-400 mt-1">
              最接近: {score.closestRedDist !== null ? `${score.closestRedDist}m` : '記録なし'}
            </span>
          </div>

          <span className="text-2xl font-black text-slate-600 font-orbitron">VS</span>

          {/* Blue summary */}
          <div className="flex flex-col items-center">
            <span className="text-xs font-bold text-blue-400">2P 青組 (↓ / →)</span>
            <span className="text-4xl font-black font-orbitron text-blue-300">
              {score.totalBlueScore}
            </span>
            <span className="text-[10px] text-slate-400 mt-1">
              最接近: {score.closestBlueDist !== null ? `${score.closestBlueDist}m` : '記録なし'}
            </span>
          </div>
        </div>

        <div className="h-px bg-slate-800" />

        <div className="text-left bg-slate-900/60 p-3 rounded-xl border border-white/5 text-[11px] text-slate-300 space-y-1">
          <div className="font-bold text-amber-300 mb-1">【得点判定ルール】</div>
          <div>
            ジャックボール(白)に最も近い球を持つチームが得点権を獲得します。
          </div>
          <div>
            相手チームの一番近い球よりも内側にある自チームの球の数がエンド得点になります。
          </div>
        </div>
      </div>

      {/* Restart Button */}
      <button
        type="button"
        onClick={onRestart}
        className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-black text-xs sm:text-sm tracking-wider shadow-lg shadow-emerald-500/25 transition-all flex items-center space-x-2 border-2 border-transparent hover:brightness-110 active:scale-95 cursor-pointer"
      >
        <span className="text-base">🔄</span>
        <span>もう一度対戦する ( 1P: a+w または 2P: ↓+→ でも可 )</span>
      </button>
    </div>
  );
};
