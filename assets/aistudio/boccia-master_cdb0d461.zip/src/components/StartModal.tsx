import React from 'react';

interface StartModalProps {
  onStart: () => void;
}

export const StartModal: React.FC<StartModalProps> = ({ onStart }) => {
  return (
    <div className="absolute inset-0 bg-slate-950/92 backdrop-blur-md flex flex-col justify-center items-center text-center p-4 sm:p-6 z-50 overflow-y-auto">
      <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mb-3 shadow-lg shadow-amber-500/10 animate-bounce">
        <span className="text-3xl">⚪</span>
      </div>

      <h1 className="text-2xl sm:text-3xl md:text-4xl font-black font-orbitron text-white mb-2 tracking-wide">
        Boccia Master <span className="text-amber-400">ボッチャ対戦</span>
      </h1>
      <p className="text-xs sm:text-sm text-slate-300 max-w-lg mb-5 leading-relaxed">
        パラリンピック正式種目「ボッチャ」のリアル物理シミュレーションゲーム。<br />
        白いジャックボールに自分の色のボールをどれだけ近づけられるかを競う頭脳戦です！
      </p>

      {/* Rules & Throwing box breakdown */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-xl w-full mb-4 text-left">
        {/* Red Team Info */}
        <div className="glass-panel rounded-xl p-3 border border-red-500/40">
          <div className="flex items-center space-x-2 mb-1.5">
            <span className="w-6 h-6 rounded bg-red-600 text-white text-xs font-black flex items-center justify-center font-orbitron">
              1P
            </span>
            <strong className="text-xs text-red-300">赤ボール組 (Player 1)</strong>
          </div>
          <ul className="text-[11px] text-slate-300 space-y-1">
            <li>
              ・操作キー：<code className="bg-red-950 px-1 py-0.5 rounded text-red-300 font-bold font-mono">a / w</code>
            </li>
            <li>
              ・スローイングボックス：<code className="bg-red-950 px-1 py-0.5 rounded text-red-300 font-bold">① ③ ⑤</code>
            </li>
            <li>・先行：第1投でジャックボール(白)を投球</li>
            <li>・持ち球：赤ボール 6球</li>
          </ul>
        </div>

        {/* Blue Team Info */}
        <div className="glass-panel rounded-xl p-3 border border-blue-500/40">
          <div className="flex items-center space-x-2 mb-1.5">
            <span className="w-6 h-6 rounded bg-blue-600 text-white text-xs font-black flex items-center justify-center font-orbitron">
              2P
            </span>
            <strong className="text-xs text-blue-300">青ボール組 (Player 2)</strong>
          </div>
          <ul className="text-[11px] text-slate-300 space-y-1">
            <li>
              ・操作キー：<code className="bg-blue-950 px-1 py-0.5 rounded text-blue-300 font-bold font-mono">↓ / →</code>
            </li>
            <li>
              ・スローイングボックス：<code className="bg-blue-950 px-1 py-0.5 rounded text-blue-300 font-bold">② ④ ⑥</code>
            </li>
            <li>・後攻：相手の投球後に第1投目を投球</li>
            <li>・持ち球：青ボール 6球</li>
          </ul>
        </div>
      </div>

      {/* Control Instructions */}
      <div className="glass-panel rounded-xl p-3.5 max-w-xl w-full mb-5 border border-amber-500/30 text-left">
        <div className="text-xs font-extrabold text-amber-300 mb-2 flex items-center space-x-1.5">
          <span>🎯</span>
          <span>操作方法 (赤: a / w, 青: ↓ / →)</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] text-slate-200">
          <div className="bg-slate-900/80 p-2 rounded-lg border border-white/5">
            <div className="text-cyan-300 font-bold mb-1">1. ボール保持 (構え)</div>
            <code className="bg-slate-800 px-1 rounded text-amber-300 font-mono">短く同時押し</code>
            <p className="text-[10px] text-slate-400 mt-1">
              1Pは <kbd className="text-slate-200">a+w</kbd>、2Pは <kbd className="text-slate-200">↓+→</kbd> を短押しで構えます。
            </p>
          </div>
          <div className="bg-slate-900/80 p-2 rounded-lg border border-white/5">
            <div className="text-cyan-300 font-bold mb-1">2. 方向選択 / ボックス</div>
            <code className="bg-slate-800 px-1 rounded text-cyan-300 font-mono">片方のキー</code>
            <p className="text-[10px] text-slate-400 mt-1">
              構え中は左右狙い、待機中はボックスを切り替えます。
            </p>
          </div>
          <div className="bg-slate-900/80 p-2 rounded-lg border border-white/5">
            <div className="text-cyan-300 font-bold mb-1">3. スロー (投球)</div>
            <code className="bg-slate-800 px-1 rounded text-emerald-400 font-mono">同時長押し保持</code>
            <p className="text-[10px] text-slate-400 mt-1">
              保持時間が長いほど勢いが増して遠くへ飛びます！
            </p>
          </div>
        </div>
      </div>

      {/* Start Button */}
      <button
        type="button"
        onClick={onStart}
        className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-black text-sm tracking-wider shadow-lg shadow-emerald-500/30 hover:brightness-110 active:scale-95 transition-all cursor-pointer flex items-center space-x-2 border-2 border-transparent"
      >
        <span>⚪</span>
        <span>対戦スタート ( 1P: a+w または 2P: ↓+→ でも可 )</span>
      </button>
    </div>
  );
};
