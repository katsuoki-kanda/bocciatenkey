import React from 'react';
import { Team, GamePhase } from '../types';

interface ScoreHeaderProps {
  currentTeam: Team;
  gamePhase: GamePhase;
  redScore: number;
  blueScore: number;
  redBallsLeft: number;
  blueBallsLeft: number;
  selectedBoxNum: number;
  onFinishMatch: () => void;
  onResetGame: () => void;
}

export const ScoreHeader: React.FC<ScoreHeaderProps> = ({
  currentTeam,
  gamePhase,
  redScore,
  blueScore,
  redBallsLeft,
  blueBallsLeft,
  selectedBoxNum,
  onFinishMatch,
  onResetGame,
}) => {
  const isRedTurn = currentTeam === 'RED';

  const getPhaseText = () => {
    switch (gamePhase) {
      case 'JACK_THROW':
        return '⚪ ジャックボール投球 (白)';
      case 'INITIAL_RED':
        return '🔴 赤チーム 第1投';
      case 'INITIAL_BLUE':
        return '🔵 青チーム 第1投';
      case 'IN_PLAY':
        return isRedTurn ? '🔴 赤チームの番 (ジャックからより遠いため)' : '🔵 青チームの番 (ジャックからより遠いため)';
      case 'MEASURING':
        return '📏 審判員 計測中...';
      case 'END_RESULT':
        return '🏁 エンド終了・結果発表';
      default:
        return '🎮 ゲーム準備完了';
    }
  };

  return (
    <header className="w-full max-w-[1024px] flex flex-col sm:flex-row justify-between items-center gap-3 px-2 py-1">
      {/* Red Team Card (Player 1: a / w) */}
      <div
        className={`glass-panel rounded-2xl p-3 sm:px-4 flex items-center space-x-3.5 border-2 transition-all duration-300 w-full sm:w-auto min-w-[210px] ${
          isRedTurn ? 'player-active-red border-red-500' : 'border-red-500/30 opacity-75'
        }`}
      >
        <div className="w-11 h-11 rounded-xl bg-red-500/20 border border-red-500 flex flex-col items-center justify-center font-black font-orbitron text-red-400">
          <span className="text-xs leading-none">RED</span>
          <span className="text-[10px] text-red-200">1P</span>
        </div>
        <div className="flex flex-col flex-1">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase tracking-wider text-red-400">
              PLAYER 1 (赤)
            </span>
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-red-950/90 border border-red-500/40 text-red-300 font-mono font-bold">
              a / w
            </span>
          </div>

          <div className="flex items-baseline justify-between mt-0.5">
            <div className="flex items-baseline space-x-1">
              <span className="text-2xl font-black font-orbitron text-white tracking-wider">
                {redScore}
              </span>
              <span className="text-[10px] text-slate-400 font-bold">pts</span>
            </div>

            {/* Remaining balls dots */}
            <div className="flex space-x-1 items-center">
              {[...Array(6)].map((_, i) => (
                <span
                  key={i}
                  className={`w-2.5 h-2.5 rounded-full border ${
                    i < redBallsLeft
                      ? 'bg-red-500 border-red-300 shadow-sm shadow-red-500/50'
                      : 'bg-slate-800 border-slate-700'
                  }`}
                  title={`残り: ${redBallsLeft}球`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Center Match Status Badge */}
      <div className="glass-panel rounded-2xl px-5 py-2 flex flex-col items-center justify-center border border-white/10 shadow-xl min-w-[240px]">
        <div className="flex items-center space-x-2">
          <span
            className={`text-xs font-black px-2.5 py-1 rounded-lg shadow-md transition-all ${
              isRedTurn
                ? 'bg-red-500 text-white shadow-red-500/40'
                : 'bg-blue-600 text-white shadow-blue-500/40'
            }`}
          >
            {isRedTurn ? '1P 赤組の番 (a / w)' : '2P 青組の番 (↓ / →)'}
          </span>
          <span className="text-[11px] font-mono text-slate-300 bg-slate-800 px-2 py-0.5 rounded border border-white/10">
            投球枠: <strong className="text-amber-300 font-black">{`【 ${selectedBoxNum} 】`}</strong>
          </span>
        </div>

        <div className="mt-1 text-[11px] text-amber-300 font-bold flex items-center space-x-1">
          <span>{getPhaseText()}</span>
        </div>
      </div>

      {/* Blue Team Card (Player 2: ↓ / →) */}
      <div
        className={`glass-panel rounded-2xl p-3 sm:px-4 flex items-center space-x-3.5 border-2 transition-all duration-300 w-full sm:w-auto min-w-[210px] ${
          !isRedTurn ? 'player-active-blue border-blue-500' : 'border-blue-500/30 opacity-75'
        }`}
      >
        <div className="flex flex-col flex-1 items-end">
          <div className="flex items-center justify-between w-full">
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-blue-950/90 border border-blue-500/40 text-blue-300 font-mono font-bold">
              ↓ / →
            </span>
            <span className="text-[11px] font-black uppercase tracking-wider text-blue-400">
              PLAYER 2 (青)
            </span>
          </div>

          <div className="flex items-baseline justify-between w-full mt-0.5">
            {/* Remaining balls dots */}
            <div className="flex space-x-1 items-center">
              {[...Array(6)].map((_, i) => (
                <span
                  key={i}
                  className={`w-2.5 h-2.5 rounded-full border ${
                    i < blueBallsLeft
                      ? 'bg-blue-500 border-blue-300 shadow-sm shadow-blue-500/50'
                      : 'bg-slate-800 border-slate-700'
                  }`}
                  title={`残り: ${blueBallsLeft}球`}
                />
              ))}
            </div>

            <div className="flex items-baseline space-x-1">
              <span className="text-2xl font-black font-orbitron text-white tracking-wider">
                {blueScore}
              </span>
              <span className="text-[10px] text-slate-400 font-bold">pts</span>
            </div>
          </div>
        </div>

        <div className="w-11 h-11 rounded-xl bg-blue-500/20 border border-blue-500 flex flex-col items-center justify-center font-black font-orbitron text-blue-400">
          <span className="text-xs leading-none">BLUE</span>
          <span className="text-[10px] text-blue-200">2P</span>
        </div>
      </div>
    </header>
  );
};
