import React, { useRef, useEffect } from 'react';
import {
  COURT,
  BALL_COLORS,
  getThrowingBoxes,
  pixelDistToMeters,
  calculateRollDistance,
} from '../physics';
import { Ball, ThrowingBoxNumber, Team, BallHoldState } from '../types';

interface CourtCanvasProps {
  balls: Ball[];
  selectedBoxNum: ThrowingBoxNumber;
  currentTeam: Team;
  holdState: BallHoldState;
  aimAngle: number;
  chargeRatio: number;
  jackBall: Ball | null;
  isJackThrow?: boolean;
  onCanvasClick?: (e: React.MouseEvent<HTMLCanvasElement>) => void;
}

export const CourtCanvas: React.FC<CourtCanvasProps> = ({
  balls,
  selectedBoxNum,
  currentTeam,
  holdState,
  aimAngle,
  chargeRatio,
  jackBall,
  isJackThrow = false,
  onCanvasClick,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Keep latest props in refs for continuous 60fps canvas loop
  const propsRef = useRef({
    balls,
    selectedBoxNum,
    currentTeam,
    holdState,
    aimAngle,
    chargeRatio,
    jackBall,
    isJackThrow,
  });
  propsRef.current = {
    balls,
    selectedBoxNum,
    currentTeam,
    holdState,
    aimAngle,
    chargeRatio,
    jackBall,
    isJackThrow,
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    const throwingBoxes = getThrowingBoxes();

    const render = () => {
      const {
        balls: currentBalls,
        selectedBoxNum: currentBoxNum,
        currentTeam: currentActiveTeam,
        holdState: currentHoldState,
        aimAngle: currentAimAngle,
        chargeRatio: currentChargeRatio,
        jackBall: currentJack,
        isJackThrow: currentIsJackThrow,
      } = propsRef.current;

      const activeBox =
        throwingBoxes.find((b) => b.number === currentBoxNum) || throwingBoxes[0];

      ctx.clearRect(0, 0, COURT.CANVAS_WIDTH, COURT.CANVAS_HEIGHT);

      // 1. Background (Arena dark surrounding)
      ctx.fillStyle = '#0b1120';
      ctx.fillRect(0, 0, COURT.CANVAS_WIDTH, COURT.CANVAS_HEIGHT);

      // 2. Court Floor (Warm wooden sand finish matching sam_dc972c91.png)
      const courtW = COURT.RIGHT - COURT.LEFT;
      const courtH = COURT.BOTTOM - COURT.TOP;

      const courtGrad = ctx.createLinearGradient(
        COURT.LEFT,
        COURT.TOP,
        COURT.RIGHT,
        COURT.BOTTOM
      );
      courtGrad.addColorStop(0, '#f5d49e');
      courtGrad.addColorStop(0.5, '#edd198');
      courtGrad.addColorStop(1, '#e2c286');

      ctx.save();
      ctx.fillStyle = courtGrad;
      ctx.fillRect(COURT.LEFT, COURT.TOP, courtW, courtH);

      // Subtle parquet / wood board lines
      ctx.strokeStyle = 'rgba(180, 130, 60, 0.16)';
      ctx.lineWidth = 1;
      const step = 28;
      for (let y = COURT.TOP; y <= COURT.BOTTOM; y += step) {
        ctx.beginPath();
        ctx.moveTo(COURT.LEFT, y);
        ctx.lineTo(COURT.RIGHT, y);
        ctx.stroke();
      }

      // 3. Jack Invalid Area (ジャックボール無効エリア - Green V Zone)
      // The apex at the center points TOWARDS the throwing line (1.5m center, 3.0m sidelines)
      ctx.fillStyle = 'rgba(132, 204, 22, 0.42)'; // lime-green tint
      ctx.beginPath();
      ctx.moveTo(COURT.LEFT, COURT.BOTTOM);
      ctx.lineTo(COURT.LEFT, COURT.V_LEFT_Y);
      ctx.lineTo(COURT.CROSS_X, COURT.V_PEAK_Y);
      ctx.lineTo(COURT.RIGHT, COURT.V_RIGHT_Y);
      ctx.lineTo(COURT.RIGHT, COURT.BOTTOM);
      ctx.closePath();
      ctx.fill();

      // V-Line border (White dashed line)
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 3.5;
      ctx.setLineDash([8, 6]);
      ctx.beginPath();
      ctx.moveTo(COURT.LEFT, COURT.V_LEFT_Y);
      ctx.lineTo(COURT.CROSS_X, COURT.V_PEAK_Y);
      ctx.lineTo(COURT.RIGHT, COURT.V_RIGHT_Y);
      ctx.stroke();
      ctx.setLineDash([]);

      // Center dashed line (from throwing line through V-line apex up to Cross Mark)
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 6]);
      ctx.beginPath();
      ctx.moveTo(COURT.CROSS_X, COURT.BOTTOM);
      ctx.lineTo(COURT.CROSS_X, COURT.CROSS_Y);
      ctx.stroke();
      ctx.setLineDash([]);

      // Dimension annotations matching sam_dc972c91.png
      ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
      ctx.font = '700 11px "M PLUS Rounded 1c", sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('1.5m', COURT.CROSS_X + 8, (COURT.V_PEAK_Y + COURT.BOTTOM) / 2 + 4);

      ctx.fillText('3.0m', COURT.LEFT + 10, (COURT.V_LEFT_Y + COURT.BOTTOM) / 2 + 4);
      ctx.textAlign = 'right';
      ctx.fillText('3.0m', COURT.RIGHT - 10, (COURT.V_RIGHT_Y + COURT.BOTTOM) / 2 + 4);

      // Callout Badge for V-line area
      const badgeText = 'ジャックボール無効エリア (Vライン 頂点1.5m / 両端3.0m)';
      ctx.font = '700 11px "M PLUS Rounded 1c", sans-serif';
      const textMetrics = ctx.measureText(badgeText);
      const badgeW = textMetrics.width + 20;
      const badgeH = 22;
      const badgeX = COURT.CROSS_X - badgeW / 2;
      const badgeY = (COURT.V_PEAK_Y + COURT.BOTTOM) / 2 + 10;

      ctx.fillStyle = 'rgba(15, 23, 42, 0.82)';
      ctx.beginPath();
      if (typeof ctx.roundRect === 'function') {
        ctx.roundRect(badgeX, badgeY - 14, badgeW, badgeH, 6);
      } else {
        ctx.rect(badgeX, badgeY - 14, badgeW, badgeH);
      }
      ctx.fill();
      ctx.strokeStyle = 'rgba(190, 242, 100, 0.85)';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.fillStyle = '#ecfccb';
      ctx.textAlign = 'center';
      ctx.fillText(badgeText, COURT.CROSS_X, badgeY + 1);

      // 4. Center Target Cross (ターゲットボックス / クロスマーク 菱形)
      const cx = COURT.CROSS_X;
      const cy = COURT.CROSS_Y;
      const cSize = COURT.CROSS_SIZE;

      ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(cx, cy - cSize);
      ctx.lineTo(cx + cSize, cy);
      ctx.lineTo(cx, cy + cSize);
      ctx.lineTo(cx - cSize, cy);
      ctx.closePath();
      ctx.stroke();

      // Inner cross lines
      ctx.beginPath();
      ctx.moveTo(cx - 8, cy);
      ctx.lineTo(cx + 8, cy);
      ctx.moveTo(cx, cy - 8);
      ctx.lineTo(cx, cy + 8);
      ctx.stroke();

      ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
      ctx.font = '600 10px "M PLUS Rounded 1c", sans-serif';
      ctx.fillText('クロス (中央)', cx, cy + cSize + 14);

      // 5. Court Boundary Lines (White lines)
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 4;
      ctx.strokeRect(COURT.LEFT, COURT.TOP, courtW, courtH);

      // Boundary line labels
      ctx.fillStyle = '#94a3b8';
      ctx.font = '600 10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('エンドライン (6.0m)', COURT.CROSS_X, COURT.TOP - 12);

      ctx.save();
      ctx.translate(COURT.LEFT - 16, COURT.TOP + courtH / 2);
      ctx.rotate(-Math.PI / 2);
      ctx.fillText('サイドライン (12.5m)', 0, 0);
      ctx.restore();

      ctx.save();
      ctx.translate(COURT.RIGHT + 16, COURT.TOP + courtH / 2);
      ctx.rotate(Math.PI / 2);
      ctx.fillText('サイドライン (12.5m)', 0, 0);
      ctx.restore();

      // 6. Throwing Boxes Area (スローイングボックス ①〜⑥)
      const boxW = courtW / 6;
      const boxH = COURT.BOX_BOTTOM - COURT.BOX_TOP;

      throwingBoxes.forEach((box) => {
        const isCurrentActive = box.number === currentBoxNum;
        const isRedBox = box.team === 'RED';

        // Box background
        if (isCurrentActive) {
          ctx.fillStyle = isRedBox
            ? 'rgba(239, 68, 68, 0.32)'
            : 'rgba(59, 130, 246, 0.32)';
        } else {
          ctx.fillStyle = isRedBox
            ? 'rgba(254, 226, 226, 0.85)'
            : 'rgba(219, 234, 254, 0.85)';
        }
        ctx.fillRect(box.x - boxW / 2, COURT.BOX_TOP, boxW, boxH);

        // Box border
        ctx.strokeStyle = isCurrentActive
          ? isRedBox
            ? '#ef4444'
            : '#3b82f6'
          : '#ffffff';
        ctx.lineWidth = isCurrentActive ? 3.5 : 2;
        ctx.strokeRect(box.x - boxW / 2, COURT.BOX_TOP, boxW, boxH);

        // Active Box highlight halo
        if (isCurrentActive) {
          ctx.save();
          ctx.shadowColor = isRedBox ? '#ef4444' : '#3b82f6';
          ctx.shadowBlur = 18;
          ctx.strokeStyle = isRedBox ? '#f87171' : '#60a5fa';
          ctx.lineWidth = 3;
          ctx.strokeRect(
            box.x - boxW / 2 + 2,
            COURT.BOX_TOP + 2,
            boxW - 4,
            boxH - 4
          );
          ctx.restore();
        }

        // Box number badge
        ctx.beginPath();
        ctx.arc(box.x, COURT.BOX_TOP + 22, 14, 0, Math.PI * 2);
        ctx.fillStyle = isRedBox ? '#dc2626' : '#2563eb';
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.font = '800 13px "M PLUS Rounded 1c", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(box.label, box.x, COURT.BOX_TOP + 22);

        // Team tag
        ctx.fillStyle = isRedBox ? '#991b1b' : '#1e40af';
        ctx.font = '700 9px "M PLUS Rounded 1c", sans-serif';
        ctx.fillText(isRedBox ? '赤組' : '青組', box.x, COURT.BOX_TOP + 44);

        // Wheelchair player in this box (if active)
        if (isCurrentActive) {
          drawWheelchairAthlete(
            ctx,
            box.x,
            box.y + 12,
            isRedBox ? 'RED' : 'BLUE',
            currentHoldState,
            currentIsJackThrow
          );
        }
      });

      // Throwing line (スローイングライン)
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(COURT.LEFT, COURT.BOTTOM);
      ctx.lineTo(COURT.RIGHT, COURT.BOTTOM);
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.font = '700 11px "M PLUS Rounded 1c", sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('スローイングライン', COURT.LEFT + 6, COURT.BOTTOM - 6);

      // 7. Real-time Measurement Tape (if Jack ball exists on court)
      if (currentJack && !currentJack.isOutOfBounds) {
        drawMeasurementGuide(ctx, currentJack, currentBalls);
      }

      // 8. Draw settled and rolling balls on the court
      currentBalls.forEach((ball) => {
        if (!ball.isOutOfBounds) {
          drawBall(ctx, ball);
        }
      });

      // 9. Draw Out-of-bounds dead balls on side benches
      drawDeadBallTray(ctx, currentBalls);

      // 10. Aiming guide & trajectory if in HOLD or CHARGING state
      if (currentHoldState === 'HOLD' || currentHoldState === 'CHARGING') {
        drawAimingGuide(
          ctx,
          activeBox.x,
          COURT.BOTTOM - 6,
          currentAimAngle,
          currentChargeRatio,
          currentActiveTeam,
          currentIsJackThrow
        );
      }

      ctx.restore();

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, []);

  return (
    <div className="relative w-full flex justify-center items-center select-none">
      <canvas
        ref={canvasRef}
        width={COURT.CANVAS_WIDTH}
        height={COURT.CANVAS_HEIGHT}
        onClick={onCanvasClick}
        className="w-full max-w-[1024px] h-auto rounded-2xl shadow-2xl border border-slate-700/60 block bg-slate-950 aspect-[1024/720]"
      />
    </div>
  );
};

function drawWheelchairAthlete(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  team: Team,
  holdState: BallHoldState,
  isJackThrow: boolean
) {
  ctx.save();

  const wheelSpacing = 22;
  const wheelH = 34;
  const wheelW = 6;

  // Left & Right wheels
  [-1, 1].forEach((dir) => {
    const wx = cx + dir * wheelSpacing;
    const wy = cy;

    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.fillRect(wx - wheelW / 2 + 1, wy - wheelH / 2 + 2, wheelW, wheelH);

    ctx.fillStyle = '#1e293b';
    ctx.beginPath();
    ctx.roundRect(wx - wheelW / 2, wy - wheelH / 2, wheelW, wheelH, 3);
    ctx.fill();

    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(wx - wheelW / 2 + 1, wy - wheelH / 2 + 2, wheelW - 2, wheelH - 4);
  });

  // Seat & frame
  ctx.fillStyle = '#334155';
  ctx.beginPath();
  ctx.roundRect(cx - 16, cy - 12, 32, 24, 4);
  ctx.fill();

  // Athlete Torso
  const jerseyColor = team === 'RED' ? '#ef4444' : '#3b82f6';
  ctx.fillStyle = jerseyColor;
  ctx.beginPath();
  ctx.ellipse(cx, cy - 3, 13, 11, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Athlete Head / Cap
  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.arc(cx, cy - 5, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#0f172a';
  ctx.beginPath();
  ctx.arc(cx, cy - 7, 7, Math.PI, Math.PI * 2);
  ctx.fill();

  // Throwing arm extended forward when holding or charging
  if (holdState === 'HOLD' || holdState === 'CHARGING') {
    ctx.strokeStyle = '#fcd34d';
    ctx.lineWidth = 4;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(cx + 6, cy - 4);
    ctx.lineTo(cx + 6, cy - 22);
    ctx.stroke();

    // Held ball in hand: WHITE for Jack ball throw, team color for regular throws
    const heldBallHex = isJackThrow ? BALL_COLORS.JACK.hex : BALL_COLORS[team].hex;

    ctx.beginPath();
    ctx.arc(cx + 6, cy - 25, 7.5, 0, Math.PI * 2);
    ctx.fillStyle = heldBallHex;
    ctx.fill();

    ctx.strokeStyle = isJackThrow ? '#64748b' : '#ffffff';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Subtle 'J' mark when holding the white Jack ball
    if (isJackThrow) {
      ctx.fillStyle = '#334155';
      ctx.font = '900 8px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('J', cx + 6, cy - 25);
    }
  }

  ctx.restore();
}

function drawBall(ctx: CanvasRenderingContext2D, ball: Ball) {
  ctx.save();

  // Drop shadow
  ctx.beginPath();
  ctx.ellipse(ball.x + 2, ball.y + 4, ball.radius * 0.95, ball.radius * 0.55, 0, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
  ctx.fill();

  // Spherical body gradient
  const grad = ctx.createRadialGradient(
    ball.x - ball.radius * 0.35,
    ball.y - ball.radius * 0.35,
    ball.radius * 0.1,
    ball.x,
    ball.y,
    ball.radius
  );
  grad.addColorStop(0, ball.lightHex);
  grad.addColorStop(0.5, ball.colorHex);
  grad.addColorStop(1, ball.darkHex);

  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
  ctx.fillStyle = grad;
  ctx.fill();

  // Boccia panel seam stitching
  ctx.strokeStyle =
    ball.type === 'JACK' ? 'rgba(100, 116, 139, 0.45)' : 'rgba(255, 255, 255, 0.35)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.radius * 0.65, -0.8, 1.2);
  ctx.stroke();

  // Gloss highlight
  ctx.beginPath();
  ctx.arc(
    ball.x - ball.radius * 0.35,
    ball.y - ball.radius * 0.35,
    ball.radius * 0.25,
    0,
    Math.PI * 2
  );
  ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
  ctx.fill();

  // Ball number or "J"
  if (ball.type !== 'JACK' && ball.ballNumber) {
    ctx.fillStyle = '#ffffff';
    ctx.font = '900 9px "Orbitron", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`${ball.ballNumber}`, ball.x, ball.y + 1);
  } else if (ball.type === 'JACK') {
    ctx.fillStyle = '#475569';
    ctx.font = '900 8px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('J', ball.x, ball.y + 1);
  }

  ctx.restore();
}

function drawMeasurementGuide(
  ctx: CanvasRenderingContext2D,
  jack: Ball,
  balls: Ball[]
) {
  const settledBalls = balls.filter(
    (b) => b.type !== 'JACK' && !b.isOutOfBounds && b.isSettled
  );
  if (settledBalls.length === 0) return;

  let closestRed: Ball | null = null;
  let minRedDist = Infinity;
  let closestBlue: Ball | null = null;
  let minBlueDist = Infinity;

  settledBalls.forEach((b) => {
    const d = Math.hypot(b.x - jack.x, b.y - jack.y);
    if (b.type === 'RED' && d < minRedDist) {
      minRedDist = d;
      closestRed = b;
    } else if (b.type === 'BLUE' && d < minBlueDist) {
      minBlueDist = d;
      closestBlue = b;
    }
  });

  ctx.save();

  const minOverallDist = Math.min(minRedDist, minBlueDist);
  if (minOverallDist < Infinity && minOverallDist < 260) {
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.arc(jack.x, jack.y, minOverallDist, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  if (closestRed) {
    const cr = closestRed as Ball;
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.7)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(jack.x, jack.y);
    ctx.lineTo(cr.x, cr.y);
    ctx.stroke();

    const midX = (jack.x + cr.x) / 2;
    const midY = (jack.y + cr.y) / 2;
    drawDistBadge(ctx, midX, midY - 6, `赤: ${pixelDistToMeters(minRedDist)}m`, '#ef4444');
  }

  if (closestBlue) {
    const cb = closestBlue as Ball;
    ctx.strokeStyle = 'rgba(59, 130, 246, 0.7)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(jack.x, jack.y);
    ctx.lineTo(cb.x, cb.y);
    ctx.stroke();

    const midX = (jack.x + cb.x) / 2;
    const midY = (jack.y + cb.y) / 2;
    drawDistBadge(ctx, midX, midY + 12, `青: ${pixelDistToMeters(minBlueDist)}m`, '#3b82f6');
  }

  ctx.restore();
}

function drawDistBadge(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  text: string,
  color: string
) {
  ctx.save();
  ctx.setLineDash([]);
  ctx.font = '700 9px "M PLUS Rounded 1c", sans-serif';
  const textW = ctx.measureText(text).width;
  ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
  ctx.beginPath();
  ctx.roundRect(x - textW / 2 - 4, y - 6, textW + 8, 14, 4);
  ctx.fill();
  ctx.strokeStyle = color;
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, x, y + 1);
  ctx.restore();
}

/**
 * Draw aiming line and calibrated charging power gauge with predicted distance
 */
function drawAimingGuide(
  ctx: CanvasRenderingContext2D,
  startX: number,
  startY: number,
  angle: number,
  chargeRatio: number,
  team: Team,
  isJackThrow: boolean
) {
  ctx.save();

  // White for Jack ball aiming guide, team color for regular balls
  const themeColor = isJackThrow
    ? '#ffffff'
    : team === 'RED'
    ? '#ef4444'
    : '#3b82f6';

  // Calculate predicted distance using the non-linear power curve
  const powerCurve = Math.pow(Math.max(0.04, chargeRatio), 1.55);
  const estimatedSpeed =
    COURT.MIN_LAUNCH_SPEED +
    powerCurve * (COURT.MAX_LAUNCH_SPEED - COURT.MIN_LAUNCH_SPEED);
  const predictedDist = Math.max(90, Math.min(500, calculateRollDistance(estimatedSpeed)));

  const guideLength = chargeRatio > 0.02 ? predictedDist : 140;

  const endX = startX + Math.cos(angle) * guideLength;
  const endY = startY + Math.sin(angle) * guideLength;

  ctx.strokeStyle = themeColor;
  ctx.lineWidth = 2.5;
  ctx.setLineDash([6, 6]);
  ctx.beginPath();
  ctx.moveTo(startX, startY);
  ctx.lineTo(endX, endY);
  ctx.stroke();
  ctx.setLineDash([]);

  // Target reticle
  ctx.strokeStyle = themeColor;
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.arc(endX, endY, 7 + chargeRatio * 5, 0, Math.PI * 2);
  ctx.stroke();

  // Label above reticle if Jack ball throw
  if (isJackThrow) {
    ctx.fillStyle = '#ffffff';
    ctx.font = '800 10px "M PLUS Rounded 1c", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('⚪ ジャック目標 (白)', endX, endY - 14);
  }

  // Dynamic Power Gauge
  if (chargeRatio > 0.02) {
    const barW = 86;
    const barH = 9;
    const barX = startX - barW / 2;
    const barY = startY - 28;

    ctx.fillStyle = 'rgba(15, 23, 42, 0.94)';
    ctx.beginPath();
    ctx.roundRect(barX - 2, barY - 2, barW + 4, barH + 4, 4);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
    ctx.lineWidth = 1;
    ctx.stroke();

    const fillW = barW * Math.min(1.0, chargeRatio);
    const grad = ctx.createLinearGradient(barX, barY, barX + barW, barY);
    grad.addColorStop(0, '#22c55e');
    grad.addColorStop(0.5, '#eab308');
    grad.addColorStop(1, '#ef4444');

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.roundRect(barX, barY, fillW, barH, 3);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = '800 9px "Orbitron", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(
      `POWER ${Math.round(chargeRatio * 100)}% (${pixelDistToMeters(predictedDist)}m)`,
      startX,
      barY - 6
    );
  }

  ctx.restore();
}

function drawDeadBallTray(ctx: CanvasRenderingContext2D, balls: Ball[]) {
  const outRed = balls.filter((b) => b.type === 'RED' && b.isOutOfBounds);
  const outBlue = balls.filter((b) => b.type === 'BLUE' && b.isOutOfBounds);

  if (outRed.length === 0 && outBlue.length === 0) return;

  ctx.save();
  if (outRed.length > 0) {
    ctx.fillStyle = 'rgba(239, 68, 68, 0.15)';
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.4)';
    ctx.lineWidth = 1;
    ctx.strokeRect(20, COURT.TOP, 90, 180);
    ctx.fillStyle = '#f87171';
    ctx.font = '700 10px "M PLUS Rounded 1c", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('無効球 (赤)', 65, COURT.TOP + 16);

    outRed.forEach((b, idx) => {
      drawBall(ctx, { ...b, x: 65, y: COURT.TOP + 40 + idx * 24, radius: 10 });
    });
  }

  if (outBlue.length > 0) {
    ctx.fillStyle = 'rgba(59, 130, 246, 0.15)';
    ctx.strokeStyle = 'rgba(59, 130, 246, 0.4)';
    ctx.lineWidth = 1;
    ctx.strokeRect(COURT.CANVAS_WIDTH - 110, COURT.TOP, 90, 180);
    ctx.fillStyle = '#60a5fa';
    ctx.font = '700 10px "M PLUS Rounded 1c", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('無効球 (青)', COURT.CANVAS_WIDTH - 65, COURT.TOP + 16);

    outBlue.forEach((b, idx) => {
      drawBall(ctx, { ...b, x: COURT.CANVAS_WIDTH - 65, y: COURT.TOP + 40 + idx * 24, radius: 10 });
    });
  }
  ctx.restore();
}
