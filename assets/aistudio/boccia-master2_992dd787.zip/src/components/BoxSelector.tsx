import React from 'react';
import { ThrowingBoxNumber, Team, BallHoldState, BoxThrowsRecord, MatchType, MATCH_CONFIGS } from '../types';

interface BoxSelectorProps {
  selectedBoxNum: ThrowingBoxNumber;
  currentTeam: Team;
  holdState: BallHoldState;
  boxThrowsCount: BoxThrowsRecord;
  matchType: MatchType;
  onSelectBox: (boxNum: ThrowingBoxNumber) => void;
}

export const BoxSelector: React.FC<BoxSelectorProps> = ({
  selectedBoxNum,
  currentTeam,
  holdState,
  boxThrowsCount,
  matchType,
  onSelectBox,
}) => {
  const isRedTurn = currentTeam === 'RED';
  const matchConfig = MATCH_CONFIGS[matchType];
  const allowedBoxes: ThrowingBoxNumber[] = isRedTurn
    ? matchConfig.redBoxes
    : matchConfig.blueBoxes;

  const allBoxes: { num: ThrowingBoxNumber; label: string; team: Team }[] = [
    { num: 1, label: '①', team: 'RED' },
    { num: 2, label: '②', team: matchType === 'PAIRS' ? 'RED' : 'BLUE' },
    { num: 3, label: '③', team: matchType === 'PAIRS' ? 'BLUE' : 'RED' },
    { num: 4, label: '④', team: matchType === 'PAIRS' ? 'RED' : 'BLUE' },
    { num: 5, label: '⑤', team: matchType === 'PAIRS' ? 'BLUE' : 'RED' },
    { num: 6, label: '⑥', team: 'BLUE' },
  ];

  const maxThrows = matchConfig.throwsPerBox;
  const keyHint = isRedTurn ? 'a / w' : '↓ / →';

  return (
    <div className="glass-panel rounded-2xl px-4 py-2 flex flex-col items-center gap-1.5 border border-white/10 shadow-2xl pointer-events-auto">
      <div className="flex items-center justify-between w-full text-[10px] font-extrabold uppercase tracking-widest text-slate-400">
        <span className="flex items-center gap-1.5">
          <span>スローイングボックス選択</span>
          <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold normal-case">
            {matchConfig.shortName}：各枠 {maxThrows}投制限
          </span>
        </span>
        <span className="text-[9px] text-amber-300 font-mono">
          {isRedTurn
            ? `赤(1P): ${matchConfig.redBoxes.map((b) => `【${b}】`).join(' ')}`
            : `青(2P): ${matchConfig.blueBoxes.map((b) => `【${b}】`).join(' ')}`}
        </span>
      </div>

      <div className="flex items-center space-x-1.5 sm:space-x-2">
        {allBoxes.map((box) => {
          const isSelected = selectedBoxNum === box.num;
          const isActiveInMode = matchConfig.boxesUsed.includes(box.num);
          const isAllowedTeam = allowedBoxes.includes(box.num);
          const isRed = box.team === 'RED';
          const throws = boxThrowsCount[box.num] || 0;
          const isLimitReached = throws >= maxThrows;
          const canSelect = isActiveInMode && isAllowedTeam && !isLimitReached && holdState !== 'ROLLING';

          return (
            <button
              key={box.num}
              type="button"
              disabled={!canSelect}
              onClick={() => onSelectBox(box.num)}
              className={`box-btn w-10 sm:w-12 h-12 sm:h-13 rounded-xl font-black font-orbitron relative flex flex-col items-center justify-center border-2 transition-all cursor-pointer ${
                isSelected
                  ? isRed
                    ? 'active bg-red-600 text-white border-white shadow-lg shadow-red-500/60 scale-105'
                    : 'active bg-blue-600 text-white border-white shadow-lg shadow-blue-500/60 scale-105'
                  : !isActiveInMode
                  ? 'bg-slate-950/80 border-slate-900 text-slate-700 opacity-25 cursor-not-allowed'
                  : isLimitReached
                  ? 'bg-slate-900/80 border-slate-700/60 text-slate-500 opacity-50 cursor-not-allowed'
                  : isAllowedTeam
                  ? isRed
                    ? 'bg-red-950/70 border-red-500/60 text-red-200 hover:bg-red-900/80 hover:border-red-400'
                    : 'bg-blue-950/70 border-blue-500/60 text-blue-200 hover:bg-blue-900/80 hover:border-blue-400'
                  : 'bg-slate-900/60 border-slate-800 text-slate-600 opacity-30 cursor-not-allowed'
              }`}
              title={
                !isActiveInMode
                  ? `ボックス ${box.label} (${matchConfig.shortName}では未使用)`
                  : `ボックス ${box.label} (${box.team === 'RED' ? '赤' : '青'}) - 投球: ${throws}/${maxThrows}球`
              }
            >
              <span className="text-sm sm:text-base leading-none">{box.label}</span>
              <span className="text-[7.5px] font-sans text-slate-300 leading-tight">
                {!isActiveInMode ? '休止' : isRed ? '赤' : '青'}
              </span>
              {/* Thrown count pill */}
              <span
                className={`text-[8px] font-mono font-bold px-1 rounded -mb-0.5 ${
                  !isActiveInMode
                    ? 'bg-slate-900 text-slate-600'
                    : isLimitReached
                    ? 'bg-red-950 text-red-400 border border-red-700/50'
                    : throws > 0
                    ? 'bg-amber-950 text-amber-300 border border-amber-600/40'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                {!isActiveInMode ? '未使用' : isLimitReached ? `完${maxThrows}/${maxThrows}` : `${throws}/${maxThrows}`}
              </span>
            </button>
          );
        })}
      </div>

      <div className="text-[9px] text-slate-400 flex items-center space-x-1.5">
        <span className="bg-slate-800 px-1 py-0.5 rounded text-amber-300 font-mono font-bold">
          {keyHint}
        </span>
        <span>
          キーでも{matchConfig.shortName}の有効ボックス（各{maxThrows}球制限）を順次切替可能
        </span>
      </div>
    </div>
  );
};
