import React, { useRef, useEffect } from 'react';
import {
  COURT,
  BALL_COLORS,
  getThrowingBoxes,
  pixelDistToMeters,
  calculateRollDistance,
} from '../physics';
import {
  Ball,
  ThrowingBoxNumber,
  Team,
  BallHoldState,
  BoxThrowsRecord,
  GamePhase,
  MatchScore,
  MatchType,
  MATCH_CONFIGS,
} from '../types';

interface CourtCanvasProps {
  balls: Ball[];
  selectedBoxNum: ThrowingBoxNumber;
  currentTeam: Team;
  holdState: BallHoldState;
  aimAngle: number;
  chargeRatio: number;
  jackBall: Ball | null;
  isJackThrow?: boolean;
  boxThrowsCount: BoxThrowsRecord;
  jackStarterTeam: Team;
  gamePhase: GamePhase;
  matchScoreResult: MatchScore | null;
  matchType: MatchType;
  onSelectBox: (boxNum: ThrowingBoxNumber) => void;
  onCanvasClick?: (e: React.MouseEvent<HTMLCanvasElement>) => void;
}

export const CourtCanvas: React.FC<CourtCanvasProps> = ({
  balls,
  selectedBoxNum,
  currentTeam,
  holdState,
  aimAngle,
  chargeRatio,
  jackBall,
  isJackThrow = false,
  boxThrowsCount,
  jackStarterTeam,
  gamePhase,
  matchScoreResult,
  matchType,
  onSelectBox,
  onCanvasClick,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Keep latest props in refs for continuous 60fps canvas loop
  const propsRef = useRef({
    balls,
    selectedBoxNum,
    currentTeam,
    holdState,
    aimAngle,
    chargeRatio,
    jackBall,
    isJackThrow,
    boxThrowsCount,
    jackStarterTeam,
    gamePhase,
    matchScoreResult,
    matchType,
  });
  propsRef.current = {
    balls,
    selectedBoxNum,
    currentTeam,
    holdState,
    aimAngle,
    chargeRatio,
    jackBall,
    isJackThrow,
    boxThrowsCount,
    jackStarterTeam,
    gamePhase,
    matchScoreResult,
    matchType,
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = COURT.CANVAS_WIDTH / rect.width;
    const scaleY = COURT.CANVAS_HEIGHT / rect.height;
    const clickX = (e.clientX - rect.left) * scaleX;
    const clickY = (e.clientY - rect.top) * scaleY;

    const currentMode = propsRef.current.matchType;
    const config = MATCH_CONFIGS[currentMode];

    // Check left panel (Red team boxes)
    if (clickX >= 8 && clickX <= 144) {
      if (currentMode === 'INDIVIDUAL') {
        if (clickY >= 126 && clickY <= 660) onSelectBox(3);
      } else if (currentMode === 'PAIRS') {
        if (clickY >= 126 && clickY <= 380) onSelectBox(2);
        else if (clickY >= 390 && clickY <= 660) onSelectBox(4);
      } else {
        if (clickY >= 126 && clickY <= 300) onSelectBox(1);
        else if (clickY >= 308 && clickY <= 482) onSelectBox(3);
        else if (clickY >= 490 && clickY <= 664) onSelectBox(5);
      }
    }
    // Check right panel (Blue team boxes)
    else if (clickX >= 880 && clickX <= 1016) {
      if (currentMode === 'INDIVIDUAL') {
        if (clickY >= 126 && clickY <= 660) onSelectBox(4);
      } else if (currentMode === 'PAIRS') {
        if (clickY >= 126 && clickY <= 380) onSelectBox(3);
        else if (clickY >= 390 && clickY <= 660) onSelectBox(5);
      } else {
        if (clickY >= 126 && clickY <= 300) onSelectBox(2);
        else if (clickY >= 308 && clickY <= 482) onSelectBox(4);
        else if (clickY >= 490 && clickY <= 664) onSelectBox(6);
      }
    }
    // Check bottom court boxes
    else if (clickY >= COURT.BOX_TOP && clickY <= COURT.BOX_BOTTOM) {
      const boxW = (COURT.RIGHT - COURT.LEFT) / 6;
      for (let i = 1; i <= 6; i++) {
        const left = COURT.LEFT + (i - 1) * boxW;
        if (clickX >= left && clickX <= left + boxW) {
          if (config.boxesUsed.includes(i as ThrowingBoxNumber)) {
            onSelectBox(i as ThrowingBoxNumber);
          }
          break;
        }
      }
    }

    onCanvasClick?.(e);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      const {
        balls: currentBalls,
        selectedBoxNum: currentBoxNum,
        currentTeam: currentActiveTeam,
        holdState: currentHoldState,
        aimAngle: currentAimAngle,
        chargeRatio: currentChargeRatio,
        jackBall: currentJack,
        isJackThrow: currentIsJackThrow,
        boxThrowsCount: currentBoxThrows,
        jackStarterTeam: currentJackStarterTeam,
        gamePhase: currentPhase,
        matchScoreResult: currentScore,
        matchType: currentMode,
      } = propsRef.current;

      const throwingBoxes = getThrowingBoxes(currentMode);
      const matchConfig = MATCH_CONFIGS[currentMode];
      const maxThrows = matchConfig.throwsPerBox;

      const activeBox =
        throwingBoxes.find((b) => b.number === currentBoxNum) || throwingBoxes[0];

      ctx.clearRect(0, 0, COURT.CANVAS_WIDTH, COURT.CANVAS_HEIGHT);

      // 1. Background
      ctx.fillStyle = '#080d1a';
      ctx.fillRect(0, 0, COURT.CANVAS_WIDTH, COURT.CANVAS_HEIGHT);

      // 2. Vertical Box Status Panels (Left: Red, Right: Blue)
      drawVerticalBoxPanels(
        ctx,
        currentBalls,
        currentBoxThrows,
        currentBoxNum,
        currentActiveTeam,
        currentJackStarterTeam,
        currentJack,
        currentScore?.scoringBallIds || [],
        currentMode
      );

      // 3. Court Floor
      const courtW = COURT.RIGHT - COURT.LEFT;
      const courtH = COURT.BOTTOM - COURT.TOP;

      const courtGrad = ctx.createLinearGradient(
        COURT.LEFT,
        COURT.TOP,
        COURT.RIGHT,
        COURT.BOTTOM
      );
      courtGrad.addColorStop(0, '#f5d49e');
      courtGrad.addColorStop(0.5, '#edd198');
      courtGrad.addColorStop(1, '#e2c286');

      ctx.save();
      ctx.fillStyle = courtGrad;
      ctx.fillRect(COURT.LEFT, COURT.TOP, courtW, courtH);

      // Parquet lines
      ctx.strokeStyle = 'rgba(180, 130, 60, 0.16)';
      ctx.lineWidth = 1;
      const step = 28;
      for (let y = COURT.TOP; y <= COURT.BOTTOM; y += step) {
        ctx.beginPath();
        ctx.moveTo(COURT.LEFT, y);
        ctx.lineTo(COURT.RIGHT, y);
        ctx.stroke();
      }

      // 4. Jack Invalid Area (V-Line)
      ctx.fillStyle = 'rgba(132, 204, 22, 0.42)';
      ctx.beginPath();
      ctx.moveTo(COURT.LEFT, COURT.BOTTOM);
      ctx.lineTo(COURT.LEFT, COURT.V_LEFT_Y);
      ctx.lineTo(COURT.CROSS_X, COURT.V_PEAK_Y);
      ctx.lineTo(COURT.RIGHT, COURT.V_RIGHT_Y);
      ctx.lineTo(COURT.RIGHT, COURT.BOTTOM);
      ctx.closePath();
      ctx.fill();

      // V-Line border
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 3.5;
      ctx.setLineDash([8, 6]);
      ctx.beginPath();
      ctx.moveTo(COURT.LEFT, COURT.V_LEFT_Y);
      ctx.lineTo(COURT.CROSS_X, COURT.V_PEAK_Y);
      ctx.lineTo(COURT.RIGHT, COURT.V_RIGHT_Y);
      ctx.stroke();
      ctx.setLineDash([]);

      // Center dashed line
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 6]);
      ctx.beginPath();
      ctx.moveTo(COURT.CROSS_X, COURT.BOTTOM);
      ctx.lineTo(COURT.CROSS_X, COURT.CROSS_Y);
      ctx.stroke();
      ctx.setLineDash([]);

      // Dimensions
      ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
      ctx.font = '700 11px "M PLUS Rounded 1c", sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('1.5m', COURT.CROSS_X + 8, (COURT.V_PEAK_Y + COURT.BOTTOM) / 2 + 4);
      ctx.fillText('3.0m', COURT.LEFT + 10, (COURT.V_LEFT_Y + COURT.BOTTOM) / 2 + 4);
      ctx.textAlign = 'right';
      ctx.fillText('3.0m', COURT.RIGHT - 10, (COURT.V_RIGHT_Y + COURT.BOTTOM) / 2 + 4);

      // Callout Badge for V-line area
      const badgeText = 'ジャック無効エリア (Vライン 頂点1.5m / 両端3.0m)';
      ctx.font = '700 11px "M PLUS Rounded 1c", sans-serif';
      const textMetrics = ctx.measureText(badgeText);
      const badgeW = textMetrics.width + 20;
      const badgeH = 22;
      const badgeX = COURT.CROSS_X - badgeW / 2;
      const badgeY = (COURT.V_PEAK_Y + COURT.BOTTOM) / 2 + 10;

      ctx.fillStyle = 'rgba(15, 23, 42, 0.82)';
      drawRoundedRect(ctx, badgeX, badgeY - 14, badgeW, badgeH, 6);
      ctx.fill();
      ctx.strokeStyle = 'rgba(190, 242, 100, 0.85)';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.fillStyle = '#ecfccb';
      ctx.textAlign = 'center';
      ctx.fillText(badgeText, COURT.CROSS_X, badgeY + 1);

      // 5. Center Target Cross
      const cx = COURT.CROSS_X;
      const cy = COURT.CROSS_Y;
      const cSize = COURT.CROSS_SIZE;

      ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(cx, cy - cSize);
      ctx.lineTo(cx + cSize, cy);
      ctx.lineTo(cx, cy + cSize);
      ctx.lineTo(cx - cSize, cy);
      ctx.closePath();
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(cx - 8, cy);
      ctx.lineTo(cx + 8, cy);
      ctx.moveTo(cx, cy - 8);
      ctx.lineTo(cx, cy + 8);
      ctx.stroke();

      ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
      ctx.font = '600 10px "M PLUS Rounded 1c", sans-serif';
      ctx.fillText('クロス印 (無効時再配置)', cx, cy + cSize + 14);

      // 6. Court Boundary Lines
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 4;
      ctx.strokeRect(COURT.LEFT, COURT.TOP, courtW, courtH);

      ctx.fillStyle = '#94a3b8';
      ctx.font = '600 10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('エンドライン (6.0m)', COURT.CROSS_X, COURT.TOP - 12);

      ctx.save();
      ctx.translate(COURT.LEFT - 16, COURT.TOP + courtH / 2);
      ctx.rotate(-Math.PI / 2);
      ctx.fillText('サイドライン (12.5m)', 0, 0);
      ctx.restore();

      ctx.save();
      ctx.translate(COURT.RIGHT + 16, COURT.TOP + courtH / 2);
      ctx.rotate(Math.PI / 2);
      ctx.fillText('サイドライン (12.5m)', 0, 0);
      ctx.restore();

      // 7. Throwing Boxes Area (スローイングボックス 1〜6)
      const boxW = courtW / 6;
      const boxH = COURT.BOX_BOTTOM - COURT.BOX_TOP;

      throwingBoxes.forEach((box) => {
        const isCurrentActive = box.number === currentBoxNum;
        const isActiveInMode = box.isActiveInMode;
        const isRedBox = box.team === 'RED';
        const boxCount = currentBoxThrows[box.number] || 0;
        const isLimitReached = boxCount >= maxThrows;

        // Box background
        if (!isActiveInMode) {
          ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
        } else if (isCurrentActive) {
          ctx.fillStyle = isRedBox
            ? 'rgba(239, 68, 68, 0.35)'
            : 'rgba(59, 130, 246, 0.35)';
        } else if (isLimitReached) {
          ctx.fillStyle = 'rgba(51, 65, 85, 0.5)';
        } else {
          ctx.fillStyle = isRedBox
            ? 'rgba(254, 226, 226, 0.85)'
            : 'rgba(219, 234, 254, 0.85)';
        }
        ctx.fillRect(box.x - boxW / 2, COURT.BOX_TOP, boxW, boxH);

        // Box border
        ctx.strokeStyle = !isActiveInMode
          ? 'rgba(100, 116, 139, 0.25)'
          : isCurrentActive
          ? isRedBox
            ? '#ef4444'
            : '#3b82f6'
          : isLimitReached
          ? '#64748b'
          : '#ffffff';
        ctx.lineWidth = isCurrentActive ? 3.5 : 2;
        ctx.strokeRect(box.x - boxW / 2, COURT.BOX_TOP, boxW, boxH);

        if (isCurrentActive && isActiveInMode) {
          ctx.save();
          ctx.shadowColor = isRedBox ? '#ef4444' : '#3b82f6';
          ctx.shadowBlur = 18;
          ctx.strokeStyle = isRedBox ? '#f87171' : '#60a5fa';
          ctx.lineWidth = 3;
          ctx.strokeRect(
            box.x - boxW / 2 + 2,
            COURT.BOX_TOP + 2,
            boxW - 4,
            boxH - 4
          );
          ctx.restore();
        }

        // Box number badge
        ctx.beginPath();
        ctx.arc(box.x, COURT.BOX_TOP + 20, 13, 0, Math.PI * 2);
        ctx.fillStyle = !isActiveInMode
          ? '#334155'
          : isRedBox
          ? '#dc2626'
          : '#2563eb';
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        ctx.fillStyle = !isActiveInMode ? '#94a3b8' : '#ffffff';
        ctx.font = '800 12px "M PLUS Rounded 1c", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(box.label, box.x, COURT.BOX_TOP + 20);

        // Team tag / Inactive notice
        ctx.fillStyle = !isActiveInMode
          ? '#64748b'
          : isLimitReached
          ? '#64748b'
          : isRedBox
          ? '#991b1b'
          : '#1e40af';
        ctx.font = '700 9px "M PLUS Rounded 1c", sans-serif';
        ctx.fillText(
          !isActiveInMode ? '休止' : box.playerTitle || (isRedBox ? '赤チーム' : '青チーム'),
          box.x,
          COURT.BOX_TOP + 40
        );

        // Limit count badge
        ctx.fillStyle = !isActiveInMode
          ? '#475569'
          : isLimitReached
          ? '#94a3b8'
          : isRedBox
          ? '#ef4444'
          : '#3b82f6';
        ctx.font = '800 10px "Orbitron", sans-serif';
        ctx.fillText(
          !isActiveInMode
            ? '未使用'
            : `${boxCount}/${maxThrows}球${isLimitReached ? ' (完)' : ''}`,
          box.x,
          COURT.BOX_TOP + 56
        );

        if (isCurrentActive && isActiveInMode) {
          drawWheelchairAthlete(
            ctx,
            box.x,
            box.y + 14,
            isRedBox ? 'RED' : 'BLUE',
            currentHoldState,
            currentIsJackThrow
          );
        }
      });

      // Throwing line
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(COURT.LEFT, COURT.BOTTOM);
      ctx.lineTo(COURT.RIGHT, COURT.BOTTOM);
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.font = '700 11px "M PLUS Rounded 1c", sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('スローイングライン', COURT.LEFT + 6, COURT.BOTTOM - 6);

      // 8. SCORING ZONE CIRCLE & JUDGMENT DISPLAY
      const isEndPhase = currentPhase === 'END_RESULT' || currentPhase === 'MEASURING';
      if (isEndPhase && currentJack && !currentJack.isOutOfBounds) {
        drawScoringZoneAndJudgment(ctx, currentJack, currentBalls, currentScore);
      } else if (currentJack && !currentJack.isOutOfBounds) {
        drawMeasurementGuide(ctx, currentJack, currentBalls);
      }

      // 9. Draw balls
      currentBalls.forEach((ball) => {
        if (!ball.isOutOfBounds) {
          const isScoringBall = isEndPhase && currentScore?.scoringBallIds?.includes(ball.id);
          drawBall(ctx, ball, isScoringBall);
        }
      });

      // 10. Aiming guide
      if (currentHoldState === 'HOLD' || currentHoldState === 'CHARGING') {
        drawAimingGuide(
          ctx,
          activeBox.x,
          COURT.BOTTOM - 6,
          currentAimAngle,
          currentChargeRatio,
          currentActiveTeam,
          currentIsJackThrow
        );
      }

      ctx.restore();

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, []);

  return (
    <div className="relative w-full flex justify-center items-center select-none">
      <canvas
        ref={canvasRef}
        width={COURT.CANVAS_WIDTH}
        height={COURT.CANVAS_HEIGHT}
        onClick={handleCanvasClick}
        className="w-full max-w-[1024px] h-auto rounded-2xl shadow-2xl border border-slate-700/60 block bg-slate-950 aspect-[1024/720] cursor-pointer"
        title="クリックでスローイングボックスを選択できます"
      />
    </div>
  );
};

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  if (typeof ctx.roundRect === 'function') {
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, r);
  } else {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }
}

/**
 * Draws vertical dashboards adapted to the current match format (Individual, Pairs, Team)
 */
function drawVerticalBoxPanels(
  ctx: CanvasRenderingContext2D,
  balls: Ball[],
  boxThrowsCount: BoxThrowsRecord,
  selectedBoxNum: ThrowingBoxNumber,
  currentTeam: Team,
  jackStarterTeam: Team,
  jackBall: Ball | null,
  scoringBallIds: string[] = [],
  matchType: MatchType = 'TEAM'
) {
  ctx.save();
  const config = MATCH_CONFIGS[matchType];

  // LEFT PANEL: Red Team
  renderTeamBoxColumn(
    ctx,
    8,
    COURT.TOP,
    134,
    COURT.BOX_BOTTOM - COURT.TOP,
    'RED',
    config.redBoxes,
    balls,
    boxThrowsCount,
    selectedBoxNum,
    currentTeam,
    jackStarterTeam === 'RED',
    jackBall,
    scoringBallIds,
    matchType
  );

  // RIGHT PANEL: Blue Team
  renderTeamBoxColumn(
    ctx,
    COURT.RIGHT + 8,
    COURT.TOP,
    134,
    COURT.BOX_BOTTOM - COURT.TOP,
    'BLUE',
    config.blueBoxes,
    balls,
    boxThrowsCount,
    selectedBoxNum,
    currentTeam,
    jackStarterTeam === 'BLUE',
    jackBall,
    scoringBallIds,
    matchType
  );

  ctx.restore();
}

function renderTeamBoxColumn(
  ctx: CanvasRenderingContext2D,
  panelX: number,
  panelY: number,
  panelW: number,
  panelH: number,
  team: Team,
  boxes: ThrowingBoxNumber[],
  balls: Ball[],
  boxThrowsCount: BoxThrowsRecord,
  selectedBoxNum: ThrowingBoxNumber,
  currentActiveTeam: Team,
  isJackStarter: boolean,
  jackBall: Ball | null,
  scoringBallIds: string[],
  matchType: MatchType
) {
  const isRed = team === 'RED';
  const config = MATCH_CONFIGS[matchType];
  const maxThrows = config.throwsPerBox;

  const bgGlass = isRed ? 'rgba(30, 15, 20, 0.92)' : 'rgba(15, 23, 42, 0.92)';
  const borderHex = isRed ? 'rgba(239, 68, 68, 0.35)' : 'rgba(59, 130, 246, 0.35)';

  ctx.fillStyle = bgGlass;
  drawRoundedRect(ctx, panelX, panelY, panelW, panelH, 12);
  ctx.fill();
  ctx.strokeStyle = borderHex;
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Header
  const totalThrows = boxes.reduce((sum, b) => sum + (boxThrowsCount[b] || 0), 0);
  ctx.fillStyle = isRed ? '#fca5a5' : '#93c5fd';
  ctx.font = '800 12px "M PLUS Rounded 1c", sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(isRed ? '🔴 赤チーム' : '🔵 青チーム', panelX + panelW / 2, panelY + 18);

  ctx.fillStyle = '#94a3b8';
  ctx.font = '700 8.5px "M PLUS Rounded 1c", sans-serif';
  ctx.fillText(
    matchType === 'INDIVIDUAL'
      ? '個人戦 (枠各6投)'
      : matchType === 'PAIRS'
      ? 'ペア戦 (枠各3投)'
      : '団体戦 (枠各2投)',
    panelX + panelW / 2,
    panelY + 31
  );

  ctx.fillStyle = '#f8fafc';
  ctx.font = '800 10px "Orbitron", sans-serif';
  ctx.fillText(`計 ${totalThrows} / 6 球`, panelX + panelW / 2, panelY + 44);

  if (isJackStarter) {
    ctx.fillStyle = '#fef08a';
    ctx.font = '700 8.5px "M PLUS Rounded 1c", sans-serif';
    ctx.fillText('⭐ ジャック先攻枠', panelX + panelW / 2, panelY + 56);
  }

  // Divider
  ctx.strokeStyle = isRed ? 'rgba(239, 68, 68, 0.25)' : 'rgba(59, 130, 246, 0.25)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(panelX + 8, panelY + 61);
  ctx.lineTo(panelX + panelW - 8, panelY + 61);
  ctx.stroke();

  // Cards layout adapts to box count (1 box in Individual, 2 in Pairs, 3 in Team)
  const startBoxY = panelY + 66;
  const availableH = panelH - 72;
  const numCards = boxes.length;
  const cardH = (availableH - (numCards - 1) * 8) / numCards;

  boxes.forEach((boxNum, idx) => {
    const cardY = startBoxY + idx * (cardH + 8);
    renderBoxCardVertical(
      ctx,
      panelX + 4,
      cardY,
      panelW - 8,
      cardH,
      boxNum,
      team,
      balls,
      boxThrowsCount[boxNum] || 0,
      maxThrows,
      selectedBoxNum === boxNum,
      currentActiveTeam === team,
      jackBall,
      scoringBallIds,
      matchType
    );
  });
}

function renderBoxCardVertical(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  boxNum: ThrowingBoxNumber,
  team: Team,
  balls: Ball[],
  thrownCount: number,
  maxThrows: number,
  isSelected: boolean,
  isActiveTeam: boolean,
  jackBall: Ball | null,
  scoringBallIds: string[],
  matchType: MatchType
) {
  const isRed = team === 'RED';
  const isLimitReached = thrownCount >= maxThrows;

  if (isSelected) {
    ctx.fillStyle = isRed ? 'rgba(239, 68, 68, 0.24)' : 'rgba(59, 130, 246, 0.24)';
  } else if (isLimitReached) {
    ctx.fillStyle = 'rgba(30, 41, 59, 0.45)';
  } else {
    ctx.fillStyle = 'rgba(15, 23, 42, 0.65)';
  }
  drawRoundedRect(ctx, x, y, w, h, 8);
  ctx.fill();

  if (isSelected) {
    ctx.save();
    ctx.shadowColor = isRed ? '#ef4444' : '#3b82f6';
    ctx.shadowBlur = 10;
    ctx.strokeStyle = isRed ? '#f87171' : '#60a5fa';
    ctx.lineWidth = 2.5;
    drawRoundedRect(ctx, x, y, w, h, 8);
    ctx.stroke();
    ctx.restore();
  } else {
    ctx.strokeStyle = isLimitReached ? 'rgba(100, 116, 139, 0.3)' : 'rgba(255, 255, 255, 0.12)';
    ctx.lineWidth = 1;
    drawRoundedRect(ctx, x, y, w, h, 8);
    ctx.stroke();
  }

  const boxLabels = ['①', '②', '③', '④', '⑤', '⑥'];
  const boxLabel = boxLabels[boxNum - 1];

  ctx.beginPath();
  ctx.arc(x + 14, y + 16, 9, 0, Math.PI * 2);
  ctx.fillStyle = isRed ? '#dc2626' : '#2563eb';
  ctx.fill();
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.fillStyle = '#ffffff';
  ctx.font = '800 10px "M PLUS Rounded 1c", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(boxLabel, x + 14, y + 16);

  ctx.fillStyle = isSelected ? '#ffffff' : '#cbd5e1';
  ctx.font = '800 10.5px "M PLUS Rounded 1c", sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(`ボックス ${boxNum}`, x + 28, y + 16);

  const statusText = isLimitReached
    ? `完 ${maxThrows}/${maxThrows}`
    : `${thrownCount}/${maxThrows}球`;
  const statusColor = isLimitReached ? '#94a3b8' : thrownCount > 0 ? '#fbbf24' : '#38bdf8';

  ctx.font = '800 9px "Orbitron", sans-serif';
  ctx.textAlign = 'right';
  ctx.fillStyle = statusColor;
  ctx.fillText(statusText, x + w - 6, y + 16);

  if (isSelected && isActiveTeam) {
    ctx.fillStyle = isRed ? '#fca5a5' : '#93c5fd';
    ctx.font = '700 8px "M PLUS Rounded 1c", sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText('👉 現在の投球枠', x + 6, y + 31);
  } else if (isLimitReached) {
    ctx.fillStyle = '#ef4444';
    ctx.font = '700 8px "M PLUS Rounded 1c", sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(`⚠️ 上限到達 (${maxThrows}球済)`, x + 6, y + 31);
  }

  const boxBalls = balls.filter(
    (b) => b.type === team && b.boxNumber === boxNum
  );

  // Render slots for balls: maxThrows count (2, 3, or 6)
  const slotStartY = y + 36;
  const slotAvailableH = h - 42;
  const singleSlotH = Math.min(50, (slotAvailableH - (maxThrows - 1) * 3) / maxThrows);

  for (let s = 1; s <= maxThrows; s++) {
    const ballObj = boxBalls[s - 1] || null;
    const sy = slotStartY + (s - 1) * (singleSlotH + 3);
    renderBallSlotCompact(
      ctx,
      x + 4,
      sy,
      w - 8,
      singleSlotH,
      s,
      ballObj,
      team,
      jackBall,
      ballObj ? scoringBallIds.includes(ballObj.id) : false
    );
  }
}

function renderBallSlotCompact(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  slotIndex: number,
  ball: Ball | null,
  team: Team,
  jackBall: Ball | null,
  isScoringBall: boolean
) {
  const isRed = team === 'RED';

  ctx.fillStyle = isScoringBall
    ? 'rgba(245, 158, 11, 0.22)'
    : ball
    ? 'rgba(15, 23, 42, 0.7)'
    : 'rgba(15, 23, 42, 0.35)';
  drawRoundedRect(ctx, x, y, w, h, 5);
  ctx.fill();

  ctx.strokeStyle = isScoringBall
    ? '#f59e0b'
    : ball
    ? isRed
      ? 'rgba(239, 68, 68, 0.4)'
      : 'rgba(59, 130, 246, 0.4)'
    : 'rgba(148, 163, 184, 0.15)';
  ctx.lineWidth = isScoringBall ? 2 : 1;
  drawRoundedRect(ctx, x, y, w, h, 5);
  ctx.stroke();

  const circleR = Math.min(8.5, h * 0.32);
  const circleX = x + 14;
  const circleY = y + h / 2;

  if (ball) {
    const ballColors = BALL_COLORS[team];
    const grad = ctx.createRadialGradient(
      circleX - circleR * 0.35,
      circleY - circleR * 0.35,
      circleR * 0.1,
      circleX,
      circleY,
      circleR
    );
    grad.addColorStop(0, ballColors.light);
    grad.addColorStop(0.5, ballColors.hex);
    grad.addColorStop(1, ballColors.dark);

    ctx.beginPath();
    ctx.arc(circleX, circleY, circleR, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();

    ctx.strokeStyle = isScoringBall ? '#f59e0b' : '#ffffff';
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.font = '900 8px "Orbitron", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`${ball.ballNumber || slotIndex}`, circleX, circleY + 0.5);

    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';

    if (ball.isOutOfBounds) {
      ctx.fillStyle = '#f87171';
      ctx.font = '700 8.5px "M PLUS Rounded 1c", sans-serif';
      ctx.fillText(`${slotIndex}球目: アウト`, circleX + 11, y + h * 0.55);
    } else if (!ball.isSettled) {
      ctx.fillStyle = '#fbbf24';
      ctx.font = '800 8.5px "M PLUS Rounded 1c", sans-serif';
      ctx.fillText(`${slotIndex}球目: 投球中`, circleX + 11, y + h * 0.55);
    } else {
      let distText = 'コート内';
      if (jackBall && !jackBall.isOutOfBounds) {
        const d = Math.hypot(ball.x - jackBall.x, ball.y - jackBall.y);
        distText = `${pixelDistToMeters(d)}m`;
      }

      if (isScoringBall) {
        ctx.fillStyle = '#fde047';
        ctx.font = '800 8.5px "M PLUS Rounded 1c", sans-serif';
        ctx.fillText(`★ 得点 (+1pt)`, circleX + 11, y + h * 0.45);
        ctx.fillStyle = '#fef08a';
        ctx.font = '700 8px "Orbitron", sans-serif';
        ctx.fillText(`Jまで ${distText}`, circleX + 11, y + h * 0.82);
      } else {
        ctx.fillStyle = '#4ade80';
        ctx.font = '800 8.5px "M PLUS Rounded 1c", sans-serif';
        ctx.fillText(`${slotIndex}球目 (${distText})`, circleX + 11, y + h * 0.6);
      }
    }
  } else {
    ctx.setLineDash([2, 2]);
    ctx.beginPath();
    ctx.arc(circleX, circleY, circleR, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.4)';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.fillStyle = '#64748b';
    ctx.font = '700 8.5px "M PLUS Rounded 1c", sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(`${slotIndex}球目: 待機`, circleX + 11, y + h / 2);
  }
}

function drawWheelchairAthlete(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  team: Team,
  holdState: BallHoldState,
  isJackThrow: boolean
) {
  ctx.save();

  const wheelSpacing = 22;
  const wheelH = 34;
  const wheelW = 6;

  [-1, 1].forEach((dir) => {
    const wx = cx + dir * wheelSpacing;
    const wy = cy;

    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.fillRect(wx - wheelW / 2 + 1, wy - wheelH / 2 + 2, wheelW, wheelH);

    ctx.fillStyle = '#1e293b';
    drawRoundedRect(ctx, wx - wheelW / 2, wy - wheelH / 2, wheelW, wheelH, 3);
    ctx.fill();

    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(wx - wheelW / 2 + 1, wy - wheelH / 2 + 2, wheelW - 2, wheelH - 4);
  });

  ctx.fillStyle = '#334155';
  drawRoundedRect(ctx, cx - 16, cy - 12, 32, 24, 4);
  ctx.fill();

  const jerseyColor = team === 'RED' ? '#ef4444' : '#3b82f6';
  ctx.fillStyle = jerseyColor;
  ctx.beginPath();
  ctx.ellipse(cx, cy - 3, 13, 11, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.arc(cx, cy - 5, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#0f172a';
  ctx.beginPath();
  ctx.arc(cx, cy - 7, 7, Math.PI, Math.PI * 2);
  ctx.fill();

  if (holdState === 'HOLD' || holdState === 'CHARGING') {
    ctx.strokeStyle = '#fcd34d';
    ctx.lineWidth = 4;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(cx + 6, cy - 4);
    ctx.lineTo(cx + 6, cy - 22);
    ctx.stroke();

    const heldBallHex = isJackThrow ? BALL_COLORS.JACK.hex : BALL_COLORS[team].hex;

    ctx.beginPath();
    ctx.arc(cx + 6, cy - 25, 7.5, 0, Math.PI * 2);
    ctx.fillStyle = heldBallHex;
    ctx.fill();
    ctx.strokeStyle = isJackThrow ? '#64748b' : '#ffffff';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    if (isJackThrow) {
      ctx.fillStyle = '#334155';
      ctx.font = '900 8px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('J', cx + 6, cy - 25);
    }
  }

  ctx.restore();
}

function drawBall(ctx: CanvasRenderingContext2D, ball: Ball, isScoring = false) {
  ctx.save();

  if (isScoring) {
    ctx.save();
    ctx.shadowColor = '#f59e0b';
    ctx.shadowBlur = 16;
    ctx.strokeStyle = '#fbbf24';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(ball.x, ball.y, ball.radius + 6, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  ctx.beginPath();
  ctx.ellipse(ball.x + 2, ball.y + 4, ball.radius * 0.95, ball.radius * 0.55, 0, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
  ctx.fill();

  const grad = ctx.createRadialGradient(
    ball.x - ball.radius * 0.35,
    ball.y - ball.radius * 0.35,
    ball.radius * 0.1,
    ball.x,
    ball.y,
    ball.radius
  );
  grad.addColorStop(0, ball.lightHex);
  grad.addColorStop(0.5, ball.colorHex);
  grad.addColorStop(1, ball.darkHex);

  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
  ctx.fillStyle = grad;
  ctx.fill();

  ctx.strokeStyle =
    ball.type === 'JACK' ? 'rgba(100, 116, 139, 0.45)' : 'rgba(255, 255, 255, 0.35)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.radius * 0.65, -0.8, 1.2);
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(
    ball.x - ball.radius * 0.35,
    ball.y - ball.radius * 0.35,
    ball.radius * 0.25,
    0,
    Math.PI * 2
  );
  ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
  ctx.fill();

  if (ball.type !== 'JACK' && ball.ballNumber) {
    ctx.fillStyle = '#ffffff';
    ctx.font = '900 9px "Orbitron", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`${ball.ballNumber}`, ball.x, ball.y + 1);
  } else if (ball.type === 'JACK') {
    ctx.fillStyle = '#475569';
    ctx.font = '900 8px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('J', ball.x, ball.y + 1);
  }

  if (isScoring) {
    ctx.font = '900 10px "M PLUS Rounded 1c", sans-serif';
    const tagText = '★ +1pt';
    const tw = ctx.measureText(tagText).width;
    ctx.fillStyle = 'rgba(15, 23, 42, 0.92)';
    drawRoundedRect(ctx, ball.x - tw / 2 - 4, ball.y - ball.radius - 18, tw + 8, 15, 4);
    ctx.fill();
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.fillStyle = '#fef08a';
    ctx.textAlign = 'center';
    ctx.fillText(tagText, ball.x, ball.y - ball.radius - 7);
  }

  ctx.restore();
}

function drawScoringZoneAndJudgment(
  ctx: CanvasRenderingContext2D,
  jack: Ball,
  balls: Ball[],
  scoreResult: MatchScore | null
) {
  const settledBalls = balls.filter(
    (b) => b.type !== 'JACK' && !b.isOutOfBounds && b.isSettled
  );
  if (settledBalls.length === 0) return;

  const redItems = settledBalls
    .filter((b) => b.type === 'RED')
    .map((b) => ({ ball: b, dist: Math.hypot(b.x - jack.x, b.y - jack.y) }))
    .sort((a, b) => a.dist - b.dist);

  const blueItems = settledBalls
    .filter((b) => b.type === 'BLUE')
    .map((b) => ({ ball: b, dist: Math.hypot(b.x - jack.x, b.y - jack.y) }))
    .sort((a, b) => a.dist - b.dist);

  const minRed = redItems[0]?.dist ?? Infinity;
  const minBlue = blueItems[0]?.dist ?? Infinity;

  let winner: Team | 'DRAW' = 'DRAW';
  let scoringRadius = 0;
  let scoringItems: { ball: Ball; dist: number }[] = [];
  let opponentClosest: { ball: Ball; dist: number } | null = null;

  if (minRed < minBlue) {
    winner = 'RED';
    opponentClosest = blueItems[0] || null;
    scoringRadius = minBlue < Infinity ? minBlue : (redItems[redItems.length - 1]?.dist || 120) + 20;
    scoringItems = redItems.filter((item) => item.dist < scoringRadius);
  } else if (minBlue < minRed) {
    winner = 'BLUE';
    opponentClosest = redItems[0] || null;
    scoringRadius = minRed < Infinity ? minRed : (blueItems[blueItems.length - 1]?.dist || 120) + 20;
    scoringItems = blueItems.filter((item) => item.dist < scoringRadius);
  }

  ctx.save();

  // 1. Scoring Zone Circle
  if (scoringRadius > 0) {
    const zoneGrad = ctx.createRadialGradient(
      jack.x, jack.y, 6,
      jack.x, jack.y, scoringRadius
    );
    if (winner === 'RED') {
      zoneGrad.addColorStop(0, 'rgba(239, 68, 68, 0.28)');
      zoneGrad.addColorStop(0.7, 'rgba(239, 68, 68, 0.16)');
      zoneGrad.addColorStop(1, 'rgba(239, 68, 68, 0.04)');
    } else if (winner === 'BLUE') {
      zoneGrad.addColorStop(0, 'rgba(59, 130, 246, 0.28)');
      zoneGrad.addColorStop(0.7, 'rgba(59, 130, 246, 0.16)');
      zoneGrad.addColorStop(1, 'rgba(59, 130, 246, 0.04)');
    } else {
      zoneGrad.addColorStop(0, 'rgba(251, 191, 36, 0.2)');
      zoneGrad.addColorStop(1, 'rgba(251, 191, 36, 0.03)');
    }

    ctx.fillStyle = zoneGrad;
    ctx.beginPath();
    ctx.arc(jack.x, jack.y, scoringRadius, 0, Math.PI * 2);
    ctx.fill();

    ctx.save();
    ctx.shadowColor = '#f59e0b';
    ctx.shadowBlur = 14;
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 3;
    ctx.setLineDash([8, 6]);
    ctx.beginPath();
    ctx.arc(jack.x, jack.y, scoringRadius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();

    const circleLabel = `🎯 得点圏内サークル (相手最近球まで: ${pixelDistToMeters(scoringRadius)}m)`;
    ctx.font = '800 10.5px "M PLUS Rounded 1c", sans-serif';
    const clW = ctx.measureText(circleLabel).width;
    const tagY = Math.max(COURT.TOP + 20, jack.y - scoringRadius - 10);

    ctx.fillStyle = 'rgba(15, 23, 42, 0.94)';
    drawRoundedRect(ctx, jack.x - clW / 2 - 8, tagY - 12, clW + 16, 22, 6);
    ctx.fill();
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.fillStyle = '#fef08a';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(circleLabel, jack.x, tagY - 1);
  }

  // 2. Lines to scoring balls
  scoringItems.forEach((item, idx) => {
    ctx.strokeStyle = winner === 'RED' ? '#ef4444' : '#3b82f6';
    ctx.lineWidth = 2;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(jack.x, jack.y);
    ctx.lineTo(item.ball.x, item.ball.y);
    ctx.stroke();
    ctx.setLineDash([]);

    const mx = (jack.x + item.ball.x) / 2;
    const my = (jack.y + item.ball.y) / 2;
    drawDistBadge(
      ctx,
      mx,
      my - 8 - idx * 4,
      `★ ${winner === 'RED' ? '赤' : '青'}: ${pixelDistToMeters(item.dist)}m`,
      '#f59e0b'
    );
  });

  // 3. Opponent closest ball line
  if (opponentClosest) {
    const opp = opponentClosest;
    const oppTeam = winner === 'RED' ? '青' : '赤';
    const oppColor = winner === 'RED' ? '#3b82f6' : '#ef4444';

    ctx.strokeStyle = oppColor;
    ctx.lineWidth = 2;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(jack.x, jack.y);
    ctx.lineTo(opp.ball.x, opp.ball.y);
    ctx.stroke();
    ctx.setLineDash([]);

    const mx = (jack.x + opp.ball.x) / 2;
    const my = (jack.y + opp.ball.y) / 2;
    drawDistBadge(
      ctx,
      mx,
      my + 14,
      `相手最近球 (${oppTeam}: ${pixelDistToMeters(opp.dist)}m)`,
      oppColor
    );

    ctx.strokeStyle = oppColor;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(opp.ball.x, opp.ball.y, opp.ball.radius + 4, 0, Math.PI * 2);
    ctx.stroke();
  }

  // 4. On-Court Verdict Top Ribbon (placed above COURT.TOP at y: 18)
  const ribbonText =
    winner === 'DRAW'
      ? '🏁 エンド判定結果：同点！ 引き分け (DRAW)'
      : `🏁 エンド判定結果：【${winner === 'RED' ? '🔴 赤チーム' : '🔵 青チーム'} +${scoringItems.length}点獲得！】 (得点圏内: ${scoringItems.length}球)`;

  ctx.font = '800 12px "M PLUS Rounded 1c", sans-serif';
  const rw = ctx.measureText(ribbonText).width;
  const rx = COURT.CROSS_X - rw / 2 - 12;
  const ry = 18;

  ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
  drawRoundedRect(ctx, rx, ry, rw + 24, 28, 6);
  ctx.fill();
  ctx.strokeStyle = winner === 'RED' ? '#ef4444' : winner === 'BLUE' ? '#3b82f6' : '#f59e0b';
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.fillStyle = winner === 'RED' ? '#fca5a5' : winner === 'BLUE' ? '#93c5fd' : '#fef08a';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(ribbonText, COURT.CROSS_X, ry + 14);

  ctx.restore();
}

function drawMeasurementGuide(
  ctx: CanvasRenderingContext2D,
  jack: Ball,
  balls: Ball[]
) {
  const settledBalls = balls.filter(
    (b) => b.type !== 'JACK' && !b.isOutOfBounds && b.isSettled
  );
  if (settledBalls.length === 0) return;

  let closestRed: Ball | null = null;
  let minRedDist = Infinity;
  let closestBlue: Ball | null = null;
  let minBlueDist = Infinity;

  settledBalls.forEach((b) => {
    const d = Math.hypot(b.x - jack.x, b.y - jack.y);
    if (b.type === 'RED' && d < minRedDist) {
      minRedDist = d;
      closestRed = b;
    } else if (b.type === 'BLUE' && d < minBlueDist) {
      minBlueDist = d;
      closestBlue = b;
    }
  });

  ctx.save();

  const minOverallDist = Math.min(minRedDist, minBlueDist);
  if (minOverallDist < Infinity && minOverallDist < 260) {
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.arc(jack.x, jack.y, minOverallDist, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  if (closestRed) {
    const cr = closestRed as Ball;
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.7)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(jack.x, jack.y);
    ctx.lineTo(cr.x, cr.y);
    ctx.stroke();

    const midX = (jack.x + cr.x) / 2;
    const midY = (jack.y + cr.y) / 2;
    drawDistBadge(ctx, midX, midY - 6, `赤: ${pixelDistToMeters(minRedDist)}m`, '#ef4444');
  }

  if (closestBlue) {
    const cb = closestBlue as Ball;
    ctx.strokeStyle = 'rgba(59, 130, 246, 0.7)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(jack.x, jack.y);
    ctx.lineTo(cb.x, cb.y);
    ctx.stroke();

    const midX = (jack.x + cb.x) / 2;
    const midY = (jack.y + cb.y) / 2;
    drawDistBadge(ctx, midX, midY + 12, `青: ${pixelDistToMeters(minBlueDist)}m`, '#3b82f6');
  }

  ctx.restore();
}

function drawDistBadge(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  text: string,
  color: string
) {
  ctx.save();
  ctx.setLineDash([]);
  ctx.font = '700 9px "M PLUS Rounded 1c", sans-serif';
  const textW = ctx.measureText(text).width;

  ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
  drawRoundedRect(ctx, x - textW / 2 - 4, y - 6, textW + 8, 14, 4);
  ctx.fill();

  ctx.strokeStyle = color;
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, x, y + 1);

  ctx.restore();
}

function drawAimingGuide(
  ctx: CanvasRenderingContext2D,
  startX: number,
  startY: number,
  angle: number,
  chargeRatio: number,
  team: Team,
  isJackThrow: boolean
) {
  ctx.save();

  const themeColor = isJackThrow
    ? '#ffffff'
    : team === 'RED'
    ? '#ef4444'
    : '#3b82f6';

  const powerCurve = Math.pow(Math.max(0.04, chargeRatio), 1.55);
  const estimatedSpeed =
    COURT.MIN_LAUNCH_SPEED +
    powerCurve * (COURT.MAX_LAUNCH_SPEED - COURT.MIN_LAUNCH_SPEED);
  const predictedDist = Math.max(90, Math.min(500, calculateRollDistance(estimatedSpeed)));

  const guideLength = chargeRatio > 0.02 ? predictedDist : 140;
  const endX = startX + Math.cos(angle) * guideLength;
  const endY = startY + Math.sin(angle) * guideLength;

  ctx.strokeStyle = themeColor;
  ctx.lineWidth = 2.5;
  ctx.setLineDash([6, 6]);
  ctx.beginPath();
  ctx.moveTo(startX, startY);
  ctx.lineTo(endX, endY);
  ctx.stroke();
  ctx.setLineDash([]);

  ctx.strokeStyle = themeColor;
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.arc(endX, endY, 7 + chargeRatio * 5, 0, Math.PI * 2);
  ctx.stroke();

  if (isJackThrow) {
    ctx.fillStyle = '#ffffff';
    ctx.font = '800 10px "M PLUS Rounded 1c", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('ジャック目標 (白球)', endX, endY - 14);
  }

  if (chargeRatio > 0.02) {
    const barW = 86;
    const barH = 9;
    const barX = startX - barW / 2;
    const barY = startY - 28;

    ctx.fillStyle = 'rgba(15, 23, 42, 0.94)';
    drawRoundedRect(ctx, barX - 2, barY - 2, barW + 4, barH + 4, 4);
    ctx.fill();

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
    ctx.lineWidth = 1;
    ctx.stroke();

    const fillW = barW * Math.min(1.0, chargeRatio);
    const grad = ctx.createLinearGradient(barX, barY, barX + barW, barY);
    grad.addColorStop(0, '#22c55e');
    grad.addColorStop(0.5, '#eab308');
    grad.addColorStop(1, '#ef4444');

    ctx.fillStyle = grad;
    drawRoundedRect(ctx, barX, barY, fillW, barH, 3);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = '800 9px "Orbitron", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(
      `POWER ${Math.round(chargeRatio * 100)}% (${pixelDistToMeters(predictedDist)}m)`,
      startX,
      barY - 6
    );
  }

  ctx.restore();
}
