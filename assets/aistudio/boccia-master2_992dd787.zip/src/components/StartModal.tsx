import React from 'react';
import { Team, MatchType, MATCH_CONFIGS } from '../types';

interface StartModalProps {
  onStart: () => void;
  jackStarterTeam?: Team;
  matchType: MatchType;
  onChangeMatchType: (type: MatchType) => void;
}

export const StartModal: React.FC<StartModalProps> = ({
  onStart,
  jackStarterTeam = 'RED',
  matchType,
  onChangeMatchType,
}) => {
  const currentConfig = MATCH_CONFIGS[matchType];
  const starterBoxNum = currentConfig.jackStarterBoxes[jackStarterTeam];
  const starterBoxLabel = `ボックス${['①', '②', '③', '④', '⑤', '⑥'][starterBoxNum - 1]}`;

  const modes: { type: MatchType; label: string; icon: string; detail: string }[] = [
    {
      type: 'TEAM',
      label: '団体戦 (3人制)',
      icon: '👥',
      detail: 'スローイングボックス①〜⑥使用・各枠2投',
    },
    {
      type: 'PAIRS',
      label: 'ペア戦 (2人制)',
      icon: '🤝',
      detail: 'スローイングボックス②〜⑤使用・各枠3投',
    },
    {
      type: 'INDIVIDUAL',
      label: '個人戦 (1人制)',
      icon: '👤',
      detail: 'スローイングボックス③・④使用・各枠6投',
    },
  ];

  return (
    <div className="absolute inset-0 bg-slate-950/94 backdrop-blur-md flex flex-col justify-center items-center text-center p-3 sm:p-5 z-50 overflow-y-auto max-h-full">
      <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mb-2 shadow-lg shadow-amber-500/10 animate-bounce">
        <span className="text-3xl">⚪</span>
      </div>

      <h1 className="text-2xl sm:text-3xl font-black font-orbitron text-white mb-1.5 tracking-wide">
        Boccia Master <span className="text-amber-400">ボッチャ対戦</span>
      </h1>
      <p className="text-xs sm:text-sm text-slate-300 max-w-lg mb-3 leading-relaxed">
        パラリンピック正式種目「ボッチャ」のリアル物理シミュレーションゲーム。<br />
        白いジャックボールに自分の色のボールをどれだけ近づけられるかを競う頭脳戦です！
      </p>

      {/* Mode Switcher Tabs */}
      <div className="w-full max-w-xl bg-slate-900/90 p-1.5 rounded-2xl border border-slate-700/80 mb-3 shadow-xl">
        <div className="text-[11px] font-bold text-amber-300 mb-1.5 flex items-center justify-center space-x-1">
          <span>🏆</span>
          <span>競技種目を選択 (プレイ中も画面上で切替可能)</span>
        </div>
        <div className="grid grid-cols-3 gap-1.5">
          {modes.map((m) => {
            const isSelected = matchType === m.type;
            return (
              <button
                key={m.type}
                type="button"
                onClick={() => onChangeMatchType(m.type)}
                className={`flex flex-col items-center justify-center py-2 px-2 rounded-xl transition-all cursor-pointer border ${
                  isSelected
                    ? 'bg-amber-500/20 border-amber-400 text-white font-bold shadow-md shadow-amber-500/10 ring-1 ring-amber-400/50'
                    : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                <span className="text-base sm:text-lg mb-0.5">{m.icon}</span>
                <span className="text-xs font-bold leading-tight">{m.label}</span>
                <span className="text-[10px] text-slate-400 mt-0.5 hidden sm:block">
                  {m.type === 'TEAM' && '各枠2投'}
                  {m.type === 'PAIRS' && '各枠3投'}
                  {m.type === 'INDIVIDUAL' && '各枠6投'}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Rules & Throwing box breakdown based on selected mode */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-w-xl w-full mb-3 text-left">
        {/* Red Team Info */}
        <div className="glass-panel rounded-xl p-3 border border-red-500/40 bg-red-950/20">
          <div className="flex items-center space-x-2 mb-1.5">
            <span className="w-6 h-6 rounded bg-red-600 text-white text-xs font-black flex items-center justify-center font-orbitron">
              1P
            </span>
            <strong className="text-xs text-red-300">赤チーム (Player 1)</strong>
          </div>
          <ul className="text-[11px] text-slate-300 space-y-1">
            <li>
              ・操作キー：<code className="bg-red-950 px-1 py-0.5 rounded text-red-300 font-bold font-mono">a / w</code>
            </li>
            <li>
              ・使用ボックス：
              <code className="bg-red-950 px-1.5 py-0.5 rounded text-red-300 font-bold">
                {currentConfig.redBoxes.map((b) => `ボックス${['①', '②', '③', '④', '⑤', '⑥'][b - 1]}`).join(' ')}
              </code>
            </li>
            <li>
              ・ボックス制限：<strong className="text-amber-300">各枠 {currentConfig.throwsPerBox}球まで</strong> (計6球)
            </li>
            <li>
              ・先攻時投球：<span className="text-amber-300 font-bold">ボックス{['①', '②', '③', '④', '⑤', '⑥'][currentConfig.jackStarterBoxes.RED - 1]}</span> からジャック投球
            </li>
          </ul>
        </div>

        {/* Blue Team Info */}
        <div className="glass-panel rounded-xl p-3 border border-blue-500/40 bg-blue-950/20">
          <div className="flex items-center space-x-2 mb-1.5">
            <span className="w-6 h-6 rounded bg-blue-600 text-white text-xs font-black flex items-center justify-center font-orbitron">
              2P
            </span>
            <strong className="text-xs text-blue-300">青チーム (Player 2)</strong>
          </div>
          <ul className="text-[11px] text-slate-300 space-y-1">
            <li>
              ・操作キー：<code className="bg-blue-950 px-1 py-0.5 rounded text-blue-300 font-bold font-mono">↓ / →</code>
            </li>
            <li>
              ・使用ボックス：
              <code className="bg-blue-950 px-1.5 py-0.5 rounded text-blue-300 font-bold">
                {currentConfig.blueBoxes.map((b) => `ボックス${['①', '②', '③', '④', '⑤', '⑥'][b - 1]}`).join(' ')}
              </code>
            </li>
            <li>
              ・ボックス制限：<strong className="text-amber-300">各枠 {currentConfig.throwsPerBox}球まで</strong> (計6球)
            </li>
            <li>
              ・先攻時投球：<span className="text-amber-300 font-bold">ボックス{['①', '②', '③', '④', '⑤', '⑥'][currentConfig.jackStarterBoxes.BLUE - 1]}</span> からジャック投球
            </li>
          </ul>
        </div>
      </div>

      {/* Feature Notices: Alternating Starter & Box Limit */}
      <div className="glass-panel rounded-xl p-2.5 max-w-xl w-full mb-3 border border-emerald-500/30 text-left bg-emerald-950/20 text-[11px] text-slate-200 space-y-1">
        <div className="font-bold text-emerald-300 flex items-center space-x-1.5">
          <span>🔄</span>
          <span>【最新機能】種目切替・リセット交代・コート外縦型メーター</span>
        </div>
        <p className="text-slate-300">
          ・「リセット」ボタンで得点リセット＆ジャック投球者が<strong className="text-amber-300">先攻交互交代</strong>（現在: {jackStarterTeam === 'RED' ? '赤' : '青'}{starterBoxLabel}）。
        </p>
        <p className="text-slate-300">
          ・プレイコート左外側に赤チーム、右外側に青チームの投球状況を<strong className="text-emerald-300">縦向きメーター</strong>で常時表示。コート内のボール配置も遮りません！
        </p>
      </div>

      {/* Control Instructions */}
      <div className="glass-panel rounded-xl p-2.5 max-w-xl w-full mb-3.5 border border-amber-500/30 text-left">
        <div className="text-xs font-extrabold text-amber-300 mb-1 flex items-center space-x-1.5">
          <span>🎯</span>
          <span>操作方法 (キーボード または 画面下部のボタン)</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] text-slate-200">
          <div className="bg-slate-900/80 p-1.5 rounded-lg border border-white/5">
            <div className="text-cyan-300 font-bold mb-0.5">1. 構え / 離す</div>
            <code className="bg-slate-800 px-1 rounded text-amber-300 font-mono text-[10px]">短く同時押し / ボタン</code>
            <p className="text-[10px] text-slate-400 mt-0.5">
              1P: <kbd className="text-slate-200">a+w</kbd> / 2P: <kbd className="text-slate-200">↓+→</kbd>
            </p>
          </div>
          <div className="bg-slate-900/80 p-1.5 rounded-lg border border-white/5">
            <div className="text-cyan-300 font-bold mb-0.5">2. 方向調整 / 枠切替</div>
            <code className="bg-slate-800 px-1 rounded text-cyan-300 font-mono text-[10px]">片方のキー / ◀▶ボタン</code>
            <p className="text-[10px] text-slate-400 mt-0.5">
              非構え時は枠切替、構え時は方向調整
            </p>
          </div>
          <div className="bg-slate-900/80 p-1.5 rounded-lg border border-white/5">
            <div className="text-cyan-300 font-bold mb-0.5">3. スローイング</div>
            <code className="bg-slate-800 px-1 rounded text-emerald-400 font-mono text-[10px]">長押し保持 / 投球ボタン</code>
            <p className="text-[10px] text-slate-400 mt-0.5">
              画面下部のスローボタンで直接投球も可
            </p>
          </div>
        </div>
      </div>

      {/* Start Button */}
      <button
        type="button"
        onClick={onStart}
        className="px-8 py-3 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-400 text-slate-950 font-black text-sm tracking-wider shadow-lg shadow-emerald-500/30 hover:brightness-110 active:scale-95 transition-all cursor-pointer flex items-center space-x-2 border-2 border-transparent"
      >
        <span>⚪</span>
        <span>{currentConfig.shortName}で対戦スタート！</span>
      </button>
    </div>
  );
};
