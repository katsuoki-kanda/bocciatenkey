/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Ball,
  Team,
  ThrowingBoxNumber,
  BallHoldState,
  GamePhase,
  MatchScore,
  BoxThrowsRecord,
  MatchType,
  MATCH_CONFIGS,
} from './types';
import {
  COURT,
  BALL_COLORS,
  getThrowingBoxes,
  isInJackInvalidArea,
  pixelDistToMeters,
  updateBallPhysics,
} from './physics';
import { sound } from './sound';
import { CourtCanvas } from './components/CourtCanvas';
import { ScoreHeader } from './components/ScoreHeader';
import { BoxSelector } from './components/BoxSelector';
import { ControlsGuide } from './components/ControlsGuide';
import { StartModal } from './components/StartModal';
import { GameOverModal } from './components/GameOverModal';

// Threshold to distinguish a short keyboard press (toggle hold) from long press (charge power)
const SHORT_PRESS_THRESHOLD_MS = 320;

export default function App() {
  // Match Type (Team: 3人制 各枠2投 / Pairs: 2人制 各枠3投 / Individual: 1人制 各枠6投)
  const [matchType, setMatchType] = useState<MatchType>('TEAM');
  const matchTypeRef = useRef<MatchType>('TEAM');
  matchTypeRef.current = matchType;

  // Game phase & teams
  const [gamePhase, setGamePhase] = useState<GamePhase>('READY');
  const [currentTeam, setCurrentTeam] = useState<Team>('RED');
  const [jackStarterTeam, setJackStarterTeam] = useState<Team>('RED');
  const [selectedBoxNum, setSelectedBoxNum] = useState<ThrowingBoxNumber>(1);
  const [holdState, setHoldState] = useState<BallHoldState>('IDLE');

  // Box throws record (tracks throws made per box)
  const [boxThrowsCount, setBoxThrowsCount] = useState<BoxThrowsRecord>({
    1: 0,
    2: 0,
    3: 0,
    4: 0,
    5: 0,
    6: 0,
  });

  // Aiming angle & power charge
  const [aimAngle, setAimAngle] = useState<number>(-Math.PI / 2); // straight forward
  const [chargeRatio, setChargeRatio] = useState<number>(0);

  // Balls on court
  const [balls, setBalls] = useState<Ball[]>([]);
  const [jackBall, setJackBall] = useState<Ball | null>(null);

  // Remaining balls (6 each team across all match formats)
  const [redBallsLeft, setRedBallsLeft] = useState<number>(6);
  const [blueBallsLeft, setBlueBallsLeft] = useState<number>(6);

  // Scores
  const [redScore, setRedScore] = useState<number>(0);
  const [blueScore, setBlueScore] = useState<number>(0);
  const [matchScoreResult, setMatchScoreResult] = useState<MatchScore | null>(null);

  // Referee announcement banner
  const [refereeNotice, setRefereeNotice] = useState<string>(
    '【準備完了】「対戦スタート」または「種目切替」で試合を開始できます。'
  );

  // Refs for real-time 60fps physics & keyboard handling
  const ballsRef = useRef<Ball[]>([]);
  ballsRef.current = balls;
  const jackBallRef = useRef<Ball | null>(null);
  jackBallRef.current = jackBall;
  const currentTeamRef = useRef<Team>('RED');
  currentTeamRef.current = currentTeam;
  const jackStarterTeamRef = useRef<Team>('RED');
  jackStarterTeamRef.current = jackStarterTeam;
  const selectedBoxRef = useRef<ThrowingBoxNumber>(1);
  selectedBoxRef.current = selectedBoxNum;
  const holdStateRef = useRef<BallHoldState>('IDLE');
  holdStateRef.current = holdState;
  const aimAngleRef = useRef<number>(-Math.PI / 2);
  aimAngleRef.current = aimAngle;
  const chargeRatioRef = useRef<number>(0);
  chargeRatioRef.current = chargeRatio;
  const gamePhaseRef = useRef<GamePhase>('READY');
  gamePhaseRef.current = gamePhase;
  const redBallsLeftRef = useRef<number>(6);
  redBallsLeftRef.current = redBallsLeft;
  const blueBallsLeftRef = useRef<number>(6);
  blueBallsLeftRef.current = blueBallsLeft;
  const boxThrowsRef = useRef<BoxThrowsRecord>(boxThrowsCount);
  boxThrowsRef.current = boxThrowsCount;

  // Cumulative score refs
  const totalRedScoreRef = useRef<number>(0);
  const totalBlueScoreRef = useRef<number>(0);

  // Guard flags
  const isEndEvaluatedRef = useRef<boolean>(false);
  const measuringTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Key tracking & chords buffer
  const rawKeysDownRef = useRef<Set<string>>(new Set());
  const isBothPressedRef = useRef<boolean>(false);
  const bothPressStartRef = useRef<number | null>(null);
  const chargeStartRef = useRef<number | null>(null);

  // Precision aim locking & grace window refs
  const singleKeyDownTimeRef = useRef<number | null>(null);
  const angleSnapshotBeforeChordRef = useRef<number | null>(null);
  const lockedAimAngleRef = useRef<number | null>(null);

  // Pending timer for single key box movement in IDLE state
  const pendingBoxTimerRef = useRef<{ timer: NodeJS.Timeout; dir: 1 | -1 } | null>(null);

  const ensureAudio = useCallback(() => {
    sound.init();
  }, []);

  // Select Throwing Box (verifies match mode specific throws limit and active boxes)
  const handleSelectBox = useCallback((boxNum: ThrowingBoxNumber) => {
    ensureAudio();
    const config = MATCH_CONFIGS[matchTypeRef.current];
    const isRed = currentTeamRef.current === 'RED';
    const allowed: ThrowingBoxNumber[] = isRed ? config.redBoxes : config.blueBoxes;

    if (!allowed.includes(boxNum)) return;

    const thrown = boxThrowsRef.current[boxNum] || 0;
    if (thrown >= config.throwsPerBox && gamePhaseRef.current !== 'JACK_THROW') {
      sound.playOutOfBounds();
      setRefereeNotice(
        `【投球制限】ボックス ${boxNum} は既に制限の${config.throwsPerBox}球を投げ終えています。他のボックスを選んでください。`
      );
      return;
    }

    setSelectedBoxNum(boxNum);
    selectedBoxRef.current = boxNum;
    sound.playBoxSelect();
  }, [ensureAudio]);

  // Cycle Box for active player among boxes with throws remaining under match limit
  const cycleBox = useCallback((direction: 1 | -1) => {
    const config = MATCH_CONFIGS[matchTypeRef.current];
    const isRed = currentTeamRef.current === 'RED';
    const allAllowed: ThrowingBoxNumber[] = isRed ? config.redBoxes : config.blueBoxes;

    // Filter to boxes that haven't reached throws limit
    const available = allAllowed.filter(
      (b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox
    );
    if (available.length === 0) return;

    const currIdx = available.indexOf(selectedBoxRef.current);
    let nextIdx: number;
    if (currIdx === -1) {
      nextIdx = 0;
    } else {
      nextIdx = currIdx + direction;
      if (nextIdx < 0) nextIdx = available.length - 1;
      if (nextIdx >= available.length) nextIdx = 0;
    }

    handleSelectBox(available[nextIdx]);
  }, [handleSelectBox]);

  // Explicit Prev / Next box buttons
  const handlePrevBox = useCallback(() => {
    cycleBox(-1);
  }, [cycleBox]);

  const handleNextBox = useCallback(() => {
    cycleBox(1);
  }, [cycleBox]);

  // Cancel any pending single-key box movement
  const cancelPendingBoxTimer = useCallback(() => {
    if (pendingBoxTimerRef.current) {
      clearTimeout(pendingBoxTimerRef.current.timer);
      pendingBoxTimerRef.current = null;
    }
  }, []);

  // Toggle Ball Hold / Release
  const toggleBallHold = useCallback(() => {
    ensureAudio();
    cancelPendingBoxTimer();
    if (holdStateRef.current === 'ROLLING') return;

    const isRed = currentTeamRef.current === 'RED';
    const phase = gamePhaseRef.current;
    const isJack = phase === 'JACK_THROW';

    if (holdStateRef.current === 'HOLD' || holdStateRef.current === 'CHARGING') {
      // Release ball back to IDLE
      setHoldState('IDLE');
      holdStateRef.current = 'IDLE';
      setChargeRatio(0);
      chargeRatioRef.current = 0;
      chargeStartRef.current = null;
      singleKeyDownTimeRef.current = null;
      angleSnapshotBeforeChordRef.current = null;
      lockedAimAngleRef.current = null;
      sound.stopChargingSound();
      sound.playHoldToggle(false);
      setRefereeNotice(
        isJack
          ? '【構え解除】ボックス変更可能。構えるには「ボールを構える」、投球はスローイングボタン！'
          : `【構え解除】${isRed ? '赤チーム' : '青チーム'} ボックス選択中。◀/▶で枠を変更できます。`
      );
    } else {
      // Hold ball
      setHoldState('HOLD');
      holdStateRef.current = 'HOLD';
      sound.playHoldToggle(true);
      setRefereeNotice(
        isJack
          ? '【白ジャック球 構え中】◀/▶で方向調整、長押しまたは投球ボタンでスロー！'
          : `【${isRed ? '赤' : '青'}ボール 構え中】◀/▶で狙い調整、スローイングボタンで投球！`
      );
    }
  }, [ensureAudio, cancelPendingBoxTimer]);

  // Aim adjustments (strictly adjusts angle without forcing HOLD state)
  const handleAimLeft = useCallback(() => {
    ensureAudio();
    setAimAngle((prev) => Math.max(-Math.PI * 0.95, prev - 0.035));
  }, [ensureAudio]);

  const handleAimRight = useCallback(() => {
    ensureAudio();
    setAimAngle((prev) => Math.min(-Math.PI * 0.05, prev + 0.035));
  }, [ensureAudio]);

  // Start Charging Power (usable from both mouse/touch and keyboard)
  const startCharging = useCallback(() => {
    ensureAudio();
    cancelPendingBoxTimer();
    if (holdStateRef.current === 'ROLLING') return;

    setHoldState('CHARGING');
    holdStateRef.current = 'CHARGING';
    lockedAimAngleRef.current = aimAngleRef.current;
    chargeStartRef.current = performance.now();
    sound.startChargingSound();
  }, [ensureAudio, cancelPendingBoxTimer]);

  // Release and Throw Ball with calibrated non-linear power curve
  const releaseAndThrow = useCallback(() => {
    ensureAudio();
    cancelPendingBoxTimer();
    sound.stopChargingSound();

    if (holdStateRef.current === 'ROLLING') return;

    let ratio = chargeRatioRef.current;
    if (ratio < 0.06) {
      ratio = 0.45; // Default reliable toss for quick clicks
    }

    const powerCurve = Math.pow(Math.min(1.0, ratio), 1.55);
    const speed =
      COURT.MIN_LAUNCH_SPEED +
      powerCurve * (COURT.MAX_LAUNCH_SPEED - COURT.MIN_LAUNCH_SPEED);

    const angle = lockedAimAngleRef.current ?? aimAngleRef.current;
    sound.playThrow(powerCurve);

    // Launch position: front edge of the active throwing box
    const throwingBoxes = getThrowingBoxes(matchTypeRef.current);
    const activeBox =
      throwingBoxes.find((b) => b.number === selectedBoxRef.current) ||
      throwingBoxes[0];
    const startX = activeBox.x;
    const startY = COURT.BOTTOM - COURT.BALL_RADIUS - 4;

    const phase = gamePhaseRef.current;
    let thrownBall: Ball;

    if (phase === 'JACK_THROW') {
      // Jack ball (White)
      thrownBall = {
        id: `jack-${Date.now()}`,
        type: 'JACK',
        boxNumber: selectedBoxRef.current,
        x: startX,
        y: startY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: COURT.BALL_RADIUS,
        mass: 0.95,
        isSettled: false,
        isOutOfBounds: false,
        colorHex: BALL_COLORS.JACK.hex,
        lightHex: BALL_COLORS.JACK.light,
        darkHex: BALL_COLORS.JACK.dark,
      };

      setJackBall(thrownBall);
      jackBallRef.current = thrownBall;
      ballsRef.current = [...ballsRef.current, thrownBall];
      setBalls([...ballsRef.current]);
    } else {
      // Regular ball (Red or Blue)
      const config = MATCH_CONFIGS[matchTypeRef.current];
      const team = currentTeamRef.current;
      const num =
        team === 'RED'
          ? 7 - redBallsLeftRef.current
          : 7 - blueBallsLeftRef.current;
      const ballColors = BALL_COLORS[team];
      const boxUsed = selectedBoxRef.current;

      thrownBall = {
        id: `${team}-${num}-${Date.now()}`,
        type: team,
        ballNumber: num,
        boxNumber: boxUsed,
        x: startX,
        y: startY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: COURT.BALL_RADIUS,
        mass: 1.0,
        isSettled: false,
        isOutOfBounds: false,
        colorHex: ballColors.hex,
        lightHex: ballColors.light,
        darkHex: ballColors.dark,
      };

      // Decrement team balls remaining
      if (team === 'RED') {
        setRedBallsLeft((prev) => Math.max(0, prev - 1));
        redBallsLeftRef.current = Math.max(0, redBallsLeftRef.current - 1);
      } else {
        setBlueBallsLeft((prev) => Math.max(0, prev - 1));
        blueBallsLeftRef.current = Math.max(0, blueBallsLeftRef.current - 1);
      }

      // Record this box throw (enforcing match throws limit)
      const currentBoxCount = (boxThrowsRef.current[boxUsed] || 0) + 1;
      const updatedBoxThrows = {
        ...boxThrowsRef.current,
        [boxUsed]: currentBoxCount,
      };
      setBoxThrowsCount(updatedBoxThrows);
      boxThrowsRef.current = updatedBoxThrows;

      ballsRef.current = [...ballsRef.current, thrownBall];
      setBalls([...ballsRef.current]);

      // If current box reached the throws limit, auto-switch to next available box for this team
      if (currentBoxCount >= config.throwsPerBox) {
        const teamBoxes = team === 'RED' ? config.redBoxes : config.blueBoxes;
        const nextAvail = teamBoxes.find((b) => (updatedBoxThrows[b] || 0) < config.throwsPerBox);
        if (nextAvail) {
          setSelectedBoxNum(nextAvail);
          selectedBoxRef.current = nextAvail;
        }
      }
    }

    setHoldState('ROLLING');
    holdStateRef.current = 'ROLLING';
    setChargeRatio(0);
    chargeRatioRef.current = 0;
    chargeStartRef.current = null;
    bothPressStartRef.current = null;
    isBothPressedRef.current = false;
    singleKeyDownTimeRef.current = null;
    angleSnapshotBeforeChordRef.current = null;
    lockedAimAngleRef.current = null;
  }, [ensureAudio, cancelPendingBoxTimer]);

  // Throw with preset direct power
  const throwWithDirectPower = useCallback(
    (presetPower: number) => {
      ensureAudio();
      cancelPendingBoxTimer();
      chargeRatioRef.current = presetPower;
      setChargeRatio(presetPower);
      releaseAndThrow();
    },
    [ensureAudio, cancelPendingBoxTimer, releaseAndThrow]
  );

  // Evaluate scores at end of Boccia end and calculate scoring zone radius & ball IDs
  const evaluateEndResult = useCallback(() => {
    if (isEndEvaluatedRef.current) return;
    isEndEvaluatedRef.current = true;

    if (measuringTimerRef.current) {
      clearTimeout(measuringTimerRef.current);
      measuringTimerRef.current = null;
    }

    setHoldState('IDLE');
    holdStateRef.current = 'IDLE';

    const currentJack = jackBallRef.current;
    const currentBalls = ballsRef.current.filter(
      (b) => b.type !== 'JACK' && !b.isOutOfBounds
    );

    const prevRed = totalRedScoreRef.current;
    const prevBlue = totalBlueScoreRef.current;

    if (!currentJack || currentBalls.length === 0) {
      setMatchScoreResult({
        redPoints: 0,
        bluePoints: 0,
        totalRedScore: prevRed,
        totalBlueScore: prevBlue,
        winningTeam: 'DRAW',
        scoringBallsCount: 0,
        closestRedDist: null,
        closestBlueDist: null,
        scoringRadius: null,
        scoringBallIds: [],
      });
      setGamePhase('END_RESULT');
      gamePhaseRef.current = 'END_RESULT';
      sound.playFanfare();
      return;
    }

    const redDists: { ball: Ball; dist: number }[] = [];
    const blueDists: { ball: Ball; dist: number }[] = [];

    currentBalls.forEach((b) => {
      const d = Math.hypot(b.x - currentJack.x, b.y - currentJack.y);
      if (b.type === 'RED') redDists.push({ ball: b, dist: d });
      else if (b.type === 'BLUE') blueDists.push({ ball: b, dist: d });
    });

    redDists.sort((a, b) => a.dist - b.dist);
    blueDists.sort((a, b) => a.dist - b.dist);

    const minRed = redDists.length > 0 ? redDists[0].dist : Infinity;
    const minBlue = blueDists.length > 0 ? blueDists[0].dist : Infinity;

    let redPts = 0;
    let bluePts = 0;
    let winner: Team | 'DRAW' = 'DRAW';
    let scoringRadius: number | null = null;
    const scoringBallIds: string[] = [];

    if (minRed < minBlue) {
      winner = 'RED';
      const scoringBalls = redDists.filter((r) => r.dist < minBlue);
      redPts = scoringBalls.length;
      scoringBalls.forEach((r) => scoringBallIds.push(r.ball.id));
      scoringRadius = minBlue !== Infinity ? minBlue : (scoringBalls[scoringBalls.length - 1]?.dist ?? minRed) + 12;
    } else if (minBlue < minRed) {
      winner = 'BLUE';
      const scoringBalls = blueDists.filter((b) => b.dist < minRed);
      bluePts = scoringBalls.length;
      scoringBalls.forEach((b) => scoringBallIds.push(b.ball.id));
      scoringRadius = minRed !== Infinity ? minRed : (scoringBalls[scoringBalls.length - 1]?.dist ?? minBlue) + 12;
    } else {
      winner = 'DRAW';
      redPts = 0;
      bluePts = 0;
      scoringRadius = minRed !== Infinity ? minRed : null;
    }

    totalRedScoreRef.current += redPts;
    totalBlueScoreRef.current += bluePts;
    setRedScore(totalRedScoreRef.current);
    setBlueScore(totalBlueScoreRef.current);

    setMatchScoreResult({
      redPoints: redPts,
      bluePoints: bluePts,
      totalRedScore: totalRedScoreRef.current,
      totalBlueScore: totalBlueScoreRef.current,
      winningTeam: winner,
      scoringBallsCount: redPts + bluePts,
      closestRedDist: minRed !== Infinity ? pixelDistToMeters(minRed) : null,
      closestBlueDist: minBlue !== Infinity ? pixelDistToMeters(minBlue) : null,
      scoringRadius,
      scoringBallIds,
    });

    setGamePhase('END_RESULT');
    gamePhaseRef.current = 'END_RESULT';
    sound.playFanfare();
  }, []);

  // Post-roll phase & turn switching
  const checkTurnAfterRoll = useCallback(() => {
    const phase = gamePhaseRef.current;
    const starterTeam = jackStarterTeamRef.current;
    const jack = jackBallRef.current;
    const config = MATCH_CONFIGS[matchTypeRef.current];

    // 1. Jack Ball throw resolution
    if (phase === 'JACK_THROW') {
      if (jack) {
        if (isInJackInvalidArea(jack.x, jack.y)) {
          // BISFed rule: out of bounds or V-line invalid -> Jack placed on Jack Cross
          jack.x = COURT.CROSS_X;
          jack.y = COURT.CROSS_Y;
          jack.vx = 0;
          jack.vy = 0;
          jack.isOutOfBounds = false;
          jack.invalidNotice = 'ジャック無効エリアのためクロスへ再配置';
          sound.playOutOfBounds();
          setRefereeNotice(
            '【審判判定】ジャックボールが無効エリアのため、センタークロスに再配置しました。'
          );
        } else {
          setRefereeNotice(
            '【審判判定】ジャックボール有効！第1投の投球を開始してください。'
          );
        }
      }

      if (starterTeam === 'RED') {
        setGamePhase('INITIAL_RED');
        gamePhaseRef.current = 'INITIAL_RED';
        setCurrentTeam('RED');
        currentTeamRef.current = 'RED';
        const avail = config.redBoxes.find((b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox) || config.redBoxes[0];
        setSelectedBoxNum(avail);
        selectedBoxRef.current = avail;
      } else {
        setGamePhase('INITIAL_BLUE');
        gamePhaseRef.current = 'INITIAL_BLUE';
        setCurrentTeam('BLUE');
        currentTeamRef.current = 'BLUE';
        const avail = config.blueBoxes.find((b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox) || config.blueBoxes[0];
        setSelectedBoxNum(avail);
        selectedBoxRef.current = avail;
      }
      sound.playTurnSwitch();
      return;
    }

    // 2. Initial Colored Ball throws
    if (phase === 'INITIAL_RED') {
      if (starterTeam === 'RED') {
        setGamePhase('INITIAL_BLUE');
        gamePhaseRef.current = 'INITIAL_BLUE';
        setCurrentTeam('BLUE');
        currentTeamRef.current = 'BLUE';
        const avail = config.blueBoxes.find((b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox) || config.blueBoxes[0];
        setSelectedBoxNum(avail);
        selectedBoxRef.current = avail;
        setRefereeNotice('🔵 青チーム 第1投を投球してください！');
        sound.playTurnSwitch();
        return;
      }
    }

    if (phase === 'INITIAL_BLUE') {
      if (starterTeam === 'BLUE') {
        setGamePhase('INITIAL_RED');
        gamePhaseRef.current = 'INITIAL_RED';
        setCurrentTeam('RED');
        currentTeamRef.current = 'RED';
        const avail = config.redBoxes.find((b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox) || config.redBoxes[0];
        setSelectedBoxNum(avail);
        selectedBoxRef.current = avail;
        setRefereeNotice('🔴 赤チーム 第1投を投球してください！');
        sound.playTurnSwitch();
        return;
      }
    }

    // 3. Subsequent Boccia turns: team FURTHEST from Jack throws next
    const rLeft = redBallsLeftRef.current;
    const bLeft = blueBallsLeftRef.current;

    if (rLeft === 0 && bLeft === 0) {
      if (measuringTimerRef.current || isEndEvaluatedRef.current) return;
      setRefereeNotice('【全投球終了】審判員がジャックボールとの距離を精密計測中...');
      setGamePhase('MEASURING');
      gamePhaseRef.current = 'MEASURING';
      measuringTimerRef.current = setTimeout(() => {
        evaluateEndResult();
      }, 1100);
      return;
    }

    if (rLeft === 0) {
      setCurrentTeam('BLUE');
      currentTeamRef.current = 'BLUE';
      const avail = config.blueBoxes.find((b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox) || config.blueBoxes[0];
      setSelectedBoxNum(avail);
      selectedBoxRef.current = avail;
      setGamePhase('IN_PLAY');
      gamePhaseRef.current = 'IN_PLAY';
      setRefereeNotice(`🔵 青組の番 (赤組全球終了 / 青組残球: ${bLeft})`);
      sound.playTurnSwitch();
      return;
    }

    if (bLeft === 0) {
      setCurrentTeam('RED');
      currentTeamRef.current = 'RED';
      const avail = config.redBoxes.find((b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox) || config.redBoxes[0];
      setSelectedBoxNum(avail);
      selectedBoxRef.current = avail;
      setGamePhase('IN_PLAY');
      gamePhaseRef.current = 'IN_PLAY';
      setRefereeNotice(`🔴 赤組の番 (青組全球終了 / 赤組残球: ${rLeft})`);
      sound.playTurnSwitch();
      return;
    }

    if (jack) {
      const activeBalls = ballsRef.current.filter(
        (b) => b.type !== 'JACK' && !b.isOutOfBounds
      );

      let minRedDist = Infinity;
      let minBlueDist = Infinity;

      activeBalls.forEach((b) => {
        const d = Math.hypot(b.x - jack.x, b.y - jack.y);
        if (b.type === 'RED' && d < minRedDist) minRedDist = d;
        if (b.type === 'BLUE' && d < minBlueDist) minBlueDist = d;
      });

      let nextTeam: Team = 'RED';
      if (minRedDist < minBlueDist) {
        nextTeam = 'BLUE';
        setRefereeNotice(
          `🔵 青組の番 (距離: ${pixelDistToMeters(minBlueDist)}m ＞ 赤: ${pixelDistToMeters(minRedDist)}m)`
        );
      } else {
        nextTeam = 'RED';
        setRefereeNotice(
          `🔴 赤組の番 (距離: ${pixelDistToMeters(minRedDist)}m ＞ 青: ${pixelDistToMeters(minBlueDist)}m)`
        );
      }

      setCurrentTeam(nextTeam);
      currentTeamRef.current = nextTeam;

      const allowed: ThrowingBoxNumber[] =
        nextTeam === 'RED' ? config.redBoxes : config.blueBoxes;
      const curr = selectedBoxRef.current;
      const currAllowedAndHasRemaining =
        allowed.includes(curr) && (boxThrowsRef.current[curr] || 0) < config.throwsPerBox;

      const targetBox = currAllowedAndHasRemaining
        ? curr
        : allowed.find((b) => (boxThrowsRef.current[b] || 0) < config.throwsPerBox) || allowed[0];

      setSelectedBoxNum(targetBox);
      selectedBoxRef.current = targetBox;
      setGamePhase('IN_PLAY');
      gamePhaseRef.current = 'IN_PLAY';
      sound.playTurnSwitch();
    }
  }, [evaluateEndResult]);

  // Start new game with specified Jack starter and match mode
  const startNewGameWithStarter = useCallback(
    (starter: Team, mode: MatchType = matchTypeRef.current) => {
      ensureAudio();
      cancelPendingBoxTimer();

      if (measuringTimerRef.current) {
        clearTimeout(measuringTimerRef.current);
        measuringTimerRef.current = null;
      }
      isEndEvaluatedRef.current = false;

      sound.playWhistle();

      const config = MATCH_CONFIGS[mode];
      const startBox: ThrowingBoxNumber = config.jackStarterBoxes[starter];
      setJackStarterTeam(starter);
      jackStarterTeamRef.current = starter;

      setGamePhase('JACK_THROW');
      gamePhaseRef.current = 'JACK_THROW';
      setCurrentTeam(starter);
      currentTeamRef.current = starter;
      setSelectedBoxNum(startBox);
      selectedBoxRef.current = startBox;

      setHoldState('IDLE');
      holdStateRef.current = 'IDLE';
      setAimAngle(-Math.PI / 2);
      aimAngleRef.current = -Math.PI / 2;
      setChargeRatio(0);
      chargeRatioRef.current = 0;

      singleKeyDownTimeRef.current = null;
      angleSnapshotBeforeChordRef.current = null;
      lockedAimAngleRef.current = null;

      ballsRef.current = [];
      setBalls([]);
      setJackBall(null);
      jackBallRef.current = null;
      setRedBallsLeft(6);
      redBallsLeftRef.current = 6;
      setBlueBallsLeft(6);
      blueBallsLeftRef.current = 6;

      const cleanBoxRecord: BoxThrowsRecord = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0 };
      setBoxThrowsCount(cleanBoxRecord);
      boxThrowsRef.current = cleanBoxRecord;

      setMatchScoreResult(null);

      const starterBoxLabel = `ボックス${['①', '②', '③', '④', '⑤', '⑥'][startBox - 1]}`;
      setRefereeNotice(
        starter === 'RED'
          ? `【第1投・${config.shortName}】赤チーム(${starterBoxLabel})からジャックボール(白)を投球してください！`
          : `【第1投・${config.shortName}】青チーム(${starterBoxLabel})からジャックボール(白)を投球してください！`
      );
    },
    [ensureAudio, cancelPendingBoxTimer]
  );

  const handleStartGame = useCallback(() => {
    startNewGameWithStarter(jackStarterTeamRef.current, matchTypeRef.current);
  }, [startNewGameWithStarter]);

  // Reset entire match: resets score AND alternates Jack starter between designated starting boxes
  const handleResetGame = useCallback(() => {
    ensureAudio();
    totalRedScoreRef.current = 0;
    totalBlueScoreRef.current = 0;
    setRedScore(0);
    setBlueScore(0);

    const currentStarter = jackStarterTeamRef.current;
    const nextStarter: Team = currentStarter === 'RED' ? 'BLUE' : 'RED';
    const config = MATCH_CONFIGS[matchTypeRef.current];

    startNewGameWithStarter(nextStarter, matchTypeRef.current);

    const starterBoxNum = config.jackStarterBoxes[nextStarter];
    const starterBoxLabel = `ボックス${['①', '②', '③', '④', '⑤', '⑥'][starterBoxNum - 1]}`;
    setRefereeNotice(
      nextStarter === 'RED'
        ? `【リセット・${config.shortName}】得点リセット完了。ジャック先攻は【赤チーム (${starterBoxLabel})】です！`
        : `【リセット・${config.shortName}】得点リセット完了。ジャック先攻は【青チーム (${starterBoxLabel})】です！`
    );
  }, [ensureAudio, startNewGameWithStarter]);

  // Change Match Type: 団体戦 ⇄ ペア戦 ⇄ 個人戦
  const handleChangeMatchType = useCallback(
    (newType: MatchType) => {
      ensureAudio();
      setMatchType(newType);
      matchTypeRef.current = newType;
      totalRedScoreRef.current = 0;
      totalBlueScoreRef.current = 0;
      setRedScore(0);
      setBlueScore(0);

      // Start new game with Red as default starter for the new mode
      startNewGameWithStarter('RED', newType);

      const config = MATCH_CONFIGS[newType];
      const starterBoxLabel = `ボックス${['①', '②', '③', '④', '⑤', '⑥'][config.jackStarterBoxes.RED - 1]}`;
      setRefereeNotice(
        `【種目切替: ${config.name}】得点をリセットしました。各枠${config.throwsPerBox}投制限。先攻は赤チーム(${starterBoxLabel})です！`
      );
    },
    [ensureAudio, startNewGameWithStarter]
  );

  // Manual end match button
  const handleFinishMatch = useCallback(() => {
    ensureAudio();
    if (gamePhaseRef.current === 'END_RESULT') return;
    setHoldState('IDLE');
    holdStateRef.current = 'IDLE';
    evaluateEndResult();
  }, [ensureAudio, evaluateEndResult]);

  // Main 60 FPS Physics loop & charge ramp
  useEffect(() => {
    let animId: number;

    const loop = () => {
      // 1. Charge ramp when in CHARGING state
      if (holdStateRef.current === 'CHARGING' && chargeStartRef.current !== null) {
        const elapsed = performance.now() - chargeStartRef.current;
        const CHARGE_CYCLE_MS = 1400; // time to reach 100%
        const normalized = (elapsed % (CHARGE_CYCLE_MS * 2)) / CHARGE_CYCLE_MS;
        const ratio = normalized <= 1.0 ? normalized : 2.0 - normalized;
        const clamped = Math.max(0.05, Math.min(1.0, ratio));
        setChargeRatio(clamped);
        chargeRatioRef.current = clamped;
      }

      // 2. Physics simulation when ball is ROLLING
      if (holdStateRef.current === 'ROLLING') {
        updateBallPhysics(ballsRef.current);
        const nextBalls = ballsRef.current;
        const currentJack = nextBalls.find((b) => b.type === 'JACK') || null;
        jackBallRef.current = currentJack;

        const anyRolling = nextBalls.some((b) => !b.isSettled && !b.isOutOfBounds);

        setBalls([...nextBalls]);
        setJackBall(currentJack ? { ...currentJack } : null);

        if (!anyRolling) {
          // All balls settled!
          setHoldState('IDLE');
          holdStateRef.current = 'IDLE';
          checkTurnAfterRoll();
        }
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [checkTurnAfterRoll]);

  // Keyboard Event Handlers (2-Key Simplex & Aim Locking)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore text input fields
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) return;

      ensureAudio();
      const key = e.key;

      if (key === 'Enter' || key === ' ') {
        if (gamePhaseRef.current === 'READY') {
          handleStartGame();
          e.preventDefault();
          return;
        }
      }

      const isRed = currentTeamRef.current === 'RED';
      const k1 = isRed ? 'a' : 'ArrowDown';
      const k2 = isRed ? 'w' : 'ArrowRight';

      const isKey1 = key === k1 || key.toLowerCase() === k1.toLowerCase();
      const isKey2 = key === k2 || key.toLowerCase() === k2.toLowerCase();

      if (!isKey1 && !isKey2) return;
      e.preventDefault();

      if (e.repeat) {
        // Continuous aim adjustment if held
        if (holdStateRef.current === 'HOLD') {
          if (isKey1) setAimAngle((prev) => Math.max(-Math.PI * 0.95, prev - 0.025));
          if (isKey2) setAimAngle((prev) => Math.min(-Math.PI * 0.05, prev + 0.025));
        }
        return;
      }

      const activeKeys = rawKeysDownRef.current;
      activeKeys.add(key);

      const hasK1 = activeKeys.has(k1) || (isRed && activeKeys.has('A'));
      const hasK2 = activeKeys.has(k2) || (isRed && activeKeys.has('W'));
      const isChord = hasK1 && hasK2;

      if (isChord) {
        // BOTH keys pressed simultaneously
        cancelPendingBoxTimer();

        if (singleKeyDownTimeRef.current !== null) {
          const delta = performance.now() - singleKeyDownTimeRef.current;
          if (delta < 200 && angleSnapshotBeforeChordRef.current !== null) {
            setAimAngle(angleSnapshotBeforeChordRef.current);
            aimAngleRef.current = angleSnapshotBeforeChordRef.current;
          }
        }

        if (!isBothPressedRef.current) {
          isBothPressedRef.current = true;
          bothPressStartRef.current = performance.now();

          if (holdStateRef.current === 'HOLD') {
            setHoldState('CHARGING');
            holdStateRef.current = 'CHARGING';
            lockedAimAngleRef.current = aimAngleRef.current;
            chargeStartRef.current = performance.now();
            sound.startChargingSound();
          }
        }
      } else {
        // Single key pressed
        singleKeyDownTimeRef.current = performance.now();
        angleSnapshotBeforeChordRef.current = aimAngleRef.current;

        if (holdStateRef.current === 'IDLE') {
          // Schedule box movement if chord doesn't form
          cancelPendingBoxTimer();
          const dir: 1 | -1 = isKey1 ? -1 : 1;
          const timer = setTimeout(() => {
            if (!isBothPressedRef.current && holdStateRef.current === 'IDLE') {
              cycleBox(dir);
            }
            pendingBoxTimerRef.current = null;
          }, 120);
          pendingBoxTimerRef.current = { timer, dir };
        } else if (holdStateRef.current === 'HOLD') {
          if (isKey1) setAimAngle((prev) => Math.max(-Math.PI * 0.95, prev - 0.02));
          if (isKey2) setAimAngle((prev) => Math.min(-Math.PI * 0.05, prev + 0.02));
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.key;
      const isRed = currentTeamRef.current === 'RED';
      const k1 = isRed ? 'a' : 'ArrowDown';
      const k2 = isRed ? 'w' : 'ArrowRight';

      const isCurrentKey1 = key === k1 || key.toLowerCase() === k1.toLowerCase();
      const isCurrentKey2 = key === k2 || key.toLowerCase() === k2.toLowerCase();

      if (!isCurrentKey1 && !isCurrentKey2) return;

      const activeKeys = rawKeysDownRef.current;
      activeKeys.delete(key);
      if (isRed) {
        if (key === 'a' || key === 'A') { activeKeys.delete('a'); activeKeys.delete('A'); }
        if (key === 'w' || key === 'W') { activeKeys.delete('w'); activeKeys.delete('W'); }
      }

      const wasBothPressed = isBothPressedRef.current;

      if (wasBothPressed) {
        const pressDuration = bothPressStartRef.current
          ? performance.now() - bothPressStartRef.current
          : 0;

        cancelPendingBoxTimer();
        isBothPressedRef.current = false;
        bothPressStartRef.current = null;
        singleKeyDownTimeRef.current = null;

        if (holdStateRef.current === 'CHARGING') {
          releaseAndThrow();
        } else if (pressDuration < SHORT_PRESS_THRESHOLD_MS) {
          toggleBallHold();
        } else {
          releaseAndThrow();
        }
      } else {
        // Single key was released
        if (holdStateRef.current === 'HOLD' && singleKeyDownTimeRef.current !== null) {
          const duration = performance.now() - singleKeyDownTimeRef.current;
          if (duration < 120 && !isBothPressedRef.current) {
            if (isCurrentKey1) setAimAngle((prev) => Math.max(-Math.PI * 0.95, prev - 0.015));
            if (isCurrentKey2) setAimAngle((prev) => Math.min(-Math.PI * 0.05, prev + 0.015));
          }
          singleKeyDownTimeRef.current = null;
        }

        if (pendingBoxTimerRef.current && holdStateRef.current === 'IDLE') {
          const dir = pendingBoxTimerRef.current.dir;
          cancelPendingBoxTimer();
          cycleBox(dir);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      cancelPendingBoxTimer();
    };
  }, [
    ensureAudio,
    handleStartGame,
    cycleBox,
    cancelPendingBoxTimer,
    toggleBallHold,
    releaseAndThrow,
  ]);

  const currentMatchConfig = MATCH_CONFIGS[matchType];
  const nextStarterTeam = jackStarterTeam === 'RED' ? 'BLUE' : 'RED';
  const nextStarterBox = currentMatchConfig.jackStarterBoxes[nextStarterTeam];
  const nextStarterLabel = `${nextStarterTeam === 'RED' ? '赤' : '青'}${['①', '②', '③', '④', '⑤', '⑥'][nextStarterBox - 1]}`;

  return (
    <div className="w-screen min-h-screen flex flex-col justify-between items-center bg-slate-950 text-slate-100 overflow-x-hidden p-1 sm:p-3 select-none">
      {/* Top Header with Mode Tabs, Live Score & Controls */}
      <ScoreHeader
        currentTeam={currentTeam}
        gamePhase={gamePhase}
        redScore={redScore}
        blueScore={blueScore}
        redBallsLeft={redBallsLeft}
        blueBallsLeft={blueBallsLeft}
        selectedBoxNum={selectedBoxNum}
        jackStarterTeam={jackStarterTeam}
        matchType={matchType}
        onChangeMatchType={handleChangeMatchType}
        onFinishMatch={handleFinishMatch}
        onResetGame={handleResetGame}
      />

      {/* Main Game Court Container */}
      <main className="relative w-full max-w-[1024px] my-1 flex flex-col items-center">
        {/* Referee Notice Banner */}
        <div className="w-full flex flex-col sm:flex-row justify-between items-center px-4 py-1.5 mb-1 bg-slate-900/95 rounded-xl border border-slate-800 text-xs shadow-md gap-1">
          <div className="flex items-center space-x-2">
            <span className="text-amber-400">📢</span>
            <span className="font-semibold text-slate-200">{refereeNotice}</span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={handleResetGame}
              className="text-[11px] font-bold px-3 py-1 rounded-lg bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-600/50 transition-all cursor-pointer shadow-sm flex items-center space-x-1"
              title="得点をリセットし、ジャックボール投球者を先攻交互に切り替えます"
            >
              <span>🔄</span>
              <span>リセット (先攻交代: 次は{nextStarterLabel})</span>
            </button>
            <button
              type="button"
              onClick={handleFinishMatch}
              className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 transition-all cursor-pointer"
            >
              試合終了 (判定)
            </button>
          </div>
        </div>

        {/* Court Canvas with Scoring Zone Circle & live vertical meters on outer sides */}
        <CourtCanvas
          balls={balls}
          selectedBoxNum={selectedBoxNum}
          currentTeam={currentTeam}
          holdState={holdState}
          aimAngle={aimAngle}
          chargeRatio={chargeRatio}
          jackBall={jackBall}
          isJackThrow={gamePhase === 'JACK_THROW'}
          boxThrowsCount={boxThrowsCount}
          jackStarterTeam={jackStarterTeam}
          gamePhase={gamePhase}
          matchScoreResult={matchScoreResult}
          matchType={matchType}
          onSelectBox={handleSelectBox}
        />

        {/* Start Modal with 3 Game Mode Selector */}
        {gamePhase === 'READY' && (
          <StartModal
            onStart={handleStartGame}
            jackStarterTeam={jackStarterTeam}
            matchType={matchType}
            onChangeMatchType={handleChangeMatchType}
          />
        )}
      </main>

      {/* End Result Score Display (Positioned BELOW the court so it NEVER hides court balls!) */}
      {gamePhase === 'END_RESULT' && matchScoreResult && (
        <GameOverModal score={matchScoreResult} onRestart={handleResetGame} />
      )}

      {/* Bottom Controls & Box Selector Area (Active during play) */}
      {gamePhase !== 'END_RESULT' && (
        <footer className="w-full max-w-[1024px] flex flex-col lg:flex-row items-center justify-between gap-2 z-10">
          {/* Throwing Box Selector with match-specific throw limits & active boxes */}
          <BoxSelector
            selectedBoxNum={selectedBoxNum}
            currentTeam={currentTeam}
            holdState={holdState}
            boxThrowsCount={boxThrowsCount}
            matchType={matchType}
            onSelectBox={handleSelectBox}
          />

          {/* Operations Guide Banner & Context-Sensitive Throwing Deck */}
          <ControlsGuide
            currentTeam={currentTeam}
            holdState={holdState}
            chargeRatio={chargeRatio}
            selectedBoxNum={selectedBoxNum}
            boxThrowsCount={boxThrowsCount}
            aimAngle={aimAngle}
            matchType={matchType}
            isJackThrow={gamePhase === 'JACK_THROW'}
            onToggleHold={toggleBallHold}
            onPrevBox={handlePrevBox}
            onNextBox={handleNextBox}
            onAimLeft={handleAimLeft}
            onAimRight={handleAimRight}
            onStartCharge={startCharging}
            onReleaseCharge={releaseAndThrow}
            onDirectThrow={throwWithDirectPower}
          />
        </footer>
      )}
    </div>
  );
}
